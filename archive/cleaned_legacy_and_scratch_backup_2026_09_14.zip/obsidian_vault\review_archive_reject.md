# Code Review: Archive / Reject Task Feature

> Контекст: фича добавляет CLIENT-у возможность отказаться от задачи (LOST + lossReason) и отправить завершённую задачу в архив. Разбор ведётся по фактическому коду из архивов, а не по диффу из документа.

---

## 1. Что сделано правильно

### 1.1 Бэкенд — структура в целом корректна

- `TaskStageUpdateRequest` расширен `lossReason: String` — nullable, без `@NotNull`. Правильно: поле опциональное.
- `updateTaskStage(Long, Long, String, User)` — новая сигнатура принята везде (контроллер, сервис). Дублирования старой сигнатуры в production-коде нет.
- `archiveTask` корректно проверяет `StageType.WON || LOST` перед установкой флага. Guard-clause на месте.
- `task.isArchived()` пробрасывается через `TaskMapper → TaskDto → JSON`. Фронтенд получает поле.
- Миграция `V37__Add_Archived_And_Loss_Reason.sql` создаёт оба столбца. Поле `loss_reason` — `TEXT`, что правильно.
- `CrmAccessService.canUpdateTaskStage` явно разрешает CLIENT переходить только в LOST (или WON при условии «На проверке»). Scope ограничен.
- Уведомление сотруднику при смене стадии CLIENT-ом — отправляется.

### 1.2 Фронтенд — UX новой страницы

- `ClientTaskDetailsPage` — самостоятельная страница вместо модала. Правильное решение для сложного контента.
- Stepper показывает прогресс стадий, LOST отображается отдельно с `lostReason`. Логика корректна.
- `TaskRejectModal` — предустановленные причины + свободное поле, комбинируются. Удобно.
- `useArchiveTaskMutation` и `useUpdateTaskStage` — `useMutation` с инвалидацией кэша. Паттерн правильный.
- Кнопка архивирования появляется только при `isFinished && !isArchived`. Guard корректен.

---

## 2. Дефекты — по приоритету

### P0 — Сломает runtime

#### 2.1 `archived`-задачи не фильтруются ни в одном `@Query`

Все JPQL-запросы в `TaskRepository` (`findAllWithDetails`, `findAllByClientWithDetails`, `findAllByEmployeeWithDetails`, `findAll(Specification)`) не содержат `AND t.archived = false`. Архивированные задачи продолжают возвращаться в:
- Канбан-доске (`AdminTasksPage`, `EmployeeTasksPage`)
- `ClientOverviewPage` (список задач клиента)
- Поиске (`searchTasks`)
- Статистике дашборда (`countTasksByStatus`, `sumWonAmount`, etc.)

Фича архива семантически бессмысленна, пока задача не исчезает из основного потока.

**Fix — бэкенд:** добавить `AND t.archived = false` в каждый `@Query` за исключением специализированных архивных выборок.

```java
// TaskRepository.java
@Query("select t from Task t join fetch t.client c " +
       "left join fetch c.assignedEmployee left join fetch t.assignedTo " +
       "left join fetch t.createdBy left join fetch t.stage s " +
       "where t.archived = false")
List<Task> findAllWithDetails();

@Query("select t from Task t join fetch t.client c " +
       "left join fetch c.assignedEmployee left join fetch t.assignedTo " +
       "left join fetch t.createdBy left join fetch t.stage s " +
       "where (t.client.id = :clientId or t.createdBy.id = :clientId) " +
       "and t.archived = false")
List<Task> findAllByClientWithDetails(@Param("clientId") Long clientId);

// То же для findAllByEmployeeWithDetails
```

Добавить отдельный метод для архивных выборок (для AdminArchive-страниц):

```java
@Query("select t from Task t join fetch t.client c " +
       "left join fetch c.assignedEmployee left join fetch t.assignedTo " +
       "left join fetch t.createdBy left join fetch t.stage s " +
       "where t.archived = true and s.type = :stageType")
List<Task> findArchivedByStageType(@Param("stageType") StageType stageType);
```

**Fix — фронтенд:** `AdminArchiveDonePage` и `AdminArchiveCancelledPage` фильтруют по `stage.type`, но не по `archived`. После фикса бэкенда они должны вызывать специализированный endpoint или передавать `archived=true` как query-параметр.

---

#### 2.2 `navigate('/dashboard/client')` — абсолютный путь нарушает basename

`BrowserRouter` использует `basename = import.meta.env.BASE_URL.replace(/\/$/, '')`. При деплое на Fly.io с `BASE_URL=/dashboard` router считает `/dashboard` своим корнем. Внутри роутера правильный путь — `ROUTES.CLIENT = '/client'`.

`navigate('/dashboard/client')` интерпретируется как абсолютный путь, что даёт `/dashboard/dashboard/client` или 404 в зависимости от конфигурации сервера.

Затронутые места:
- `ClientTaskDetailsPage.tsx`, строки с кнопками «Вернуться назад» — 2 вхождения
- `ClientOverviewPage.tsx` — `navigate(`/dashboard/client/tasks/${task.id}`)` вместо relative path

**Fix:**

```tsx
// ClientTaskDetailsPage.tsx
onClick={() => navigate(ROUTES.CLIENT)}  // '/client', не '/dashboard/client'

// ClientOverviewPage.tsx
onClick={() => navigate(`/client/tasks/${task.id}`)}
// или добавить CLIENT_TASK_DETAILS в ROUTES:
// CLIENT_TASK_DETAILS: '/client/tasks/:id'
```

---

### P1 — Логическая ошибка / UX-провал

#### 2.3 `lossReason` не сохраняется при повторном переходе в LOST

Условие записи:

```java
if (newStage.getType() == StageType.LOST && lossReason != null && !lossReason.isBlank()) {
    task.setLostReason(lossReason);
}
```

Это срабатывает только если `task.getStage() != newStage` (внешний if). Если задача уже в LOST и кто-то вызывает endpoint повторно с другой причиной — причина не обновится. Ок для happy-path. Но нет защиты от перезаписи уже существующей причины при случайном повторном вызове. Рекомендуется:

```java
// Устанавливать lossReason безусловно при LOST, если передана
if (newStage.getType() == StageType.LOST) {
    if (lossReason != null && !lossReason.isBlank()) {
        task.setLostReason(lossReason);
        logActivity(task, user, "Причина отказа: " + lossReason);
    }
    task.setClosedAt(java.time.LocalDate.now()); // <- этого тоже нет (см. 2.5)
}
```

---

#### 2.4 `archiveTask` не проверяет `task.isArchived()` — двойная архивация

```java
public TaskDto archiveTask(Long taskId, User user) {
    Task task = getTaskEntity(taskId);
    if (task.getStage() == null || ...) throw ...;
    accessService.assertCanUpdateTaskDetails(user, task);
    task.setArchived(true); // нет проверки: уже архивирована?
    ...
}
```

Повторный POST на `/{id}/archive` для уже архивированной задачи молча выполняется, пишет лишний `ActivityLog` «Задача архивирована» и делает лишний `@CacheEvict`. Идемпотентность нарушена.

**Fix:**

```java
if (task.isArchived()) {
    return taskMapper.mapToDto(task); // idempotent — уже архивирована
}
```

---

#### 2.5 `closedAt` не устанавливается при переходе в WON/LOST

`Task` имеет поле `closedAt LocalDate`. Оно используется в `getAverageCompletionDays()` нативным SQL. При переходе в WON/LOST `closedAt` не выставляется ни в `updateTaskStage`, ни в `batchUpdateTasks` — аналитика всегда считает `null` и возвращает `null` из агрегата.

**Fix в `updateTaskStage`:**

```java
if (newStage.getType() == StageType.WON || newStage.getType() == StageType.LOST) {
    task.setClosedAt(java.time.LocalDate.now());
}
```

---

#### 2.6 Мёртвый код в `ClientOverviewPage` не удалён

После рефакторинга (click → navigate вместо `setSelectedTask`) в файле остались:

```tsx
import { TaskDetailsModal } from '@/entities/task/ui/TaskDetailsModal'; // не используется
const [selectedTask, setSelectedTask] = useState<TaskDto | null>(null);
const handleUpdateTask = ...  // dead
```

`TaskDetailsModal` не рендерится нигде в JSX страницы — import мёртвый. Tree-shaking уберёт компонент из бандла, но `useState` и `handleUpdateTask` добавляют когнитивный шум и являются признаком незаконченного рефакторинга.

**Fix:** удалить три блока целиком.

---

### P2 — Качество кода / технический долг

#### 2.7 `canUpdateTaskStage` содержит hardcoded строку «На проверке»

```java
if (newStage.getType() == StageType.WON) {
    return task.getStage() != null && "На проверке".equals(task.getStage().getName());
}
```

Это магическая строка, привязанная к данным сидера. Переименование стадии в базе или смена языка интерфейса ломает логику без компиляционной ошибки.

**Fix:** ввести `isPreFinal: boolean` на `Stage`, выставлять через сидер, проверять по флагу:

```java
if (newStage.getType() == StageType.WON) {
    return task.getStage() != null && task.getStage().isPreFinal();
}
```

Миграция: `ALTER TABLE stages ADD COLUMN is_pre_final BOOLEAN DEFAULT FALSE;`

---

#### 2.8 `TaskStageUpdateRequest` — поле называется `lossReason` на фронтенде, `lostReason` в entity

| Слой | Имя поля |
|------|----------|
| `TaskStageUpdateRequest.java` (DTO) | `lossReason` |
| `Task.java` (entity) | `lostReason` |
| `TaskDto.java` | `lostReason` |
| `taskApi.ts` | `lossReason` |
| `TaskDto` (TS) | `lostReason` |

Хаотичное смешение `loss` / `lost`. Нужно выбрать одно и унифицировать. Рекомендуется `lostReason` как более точное семантически (состояние задачи, не процесс).

---

#### 2.9 `ROUTES` не содержит `CLIENT_TASK_DETAILS`

В `App.tsx`:
```tsx
<Route path={`${ROUTES.CLIENT}/tasks/:id`} element={<ClientTaskDetailsPage />} />
```

Путь сконкатенирован руками. При изменении `ROUTES.CLIENT` путь в `App.tsx` автоматически обновится, но `navigate()` вызовы в компонентах — нет (нет единой точки истины).

**Fix:**

```ts
// routes.ts
CLIENT_TASK_DETAILS: '/client/tasks/:id',
```

```tsx
// App.tsx
<Route path={ROUTES.CLIENT_TASK_DETAILS} element={<ClientTaskDetailsPage />} />

// ClientOverviewPage.tsx
navigate(ROUTES.CLIENT_TASK_DETAILS.replace(':id', String(task.id)))
```

---

#### 2.10 `AdminArchiveDonePage` и `AdminArchiveCancelledPage` не фильтруют по `archived`

Обе страницы фильтруют задачи только по `stage.type`, игнорируя `archived`. Логика «архив» и «завершённые» смешана. После внедрения `archived`-фильтрации в репозитории (п. 2.1) страницы архива должны получать только `archived=true` задачи — иначе семантика раздела теряется.

---

## 3. Итоговая карта дефектов

| # | Приоритет | Компонент | Описание |
|---|-----------|-----------|----------|
| 2.1 | **P0** | `TaskRepository` | `archived=false` не фильтруется ни в одном query |
| 2.2 | **P0** | `ClientTaskDetailsPage`, `ClientOverviewPage` | `navigate('/dashboard/client')` — абсолютный путь конфликтует с basename |
| 2.3 | P1 | `TaskService.updateTaskStage` | `lossReason` не пишется вне блока изменения стадии; нет `closedAt` при LOST |
| 2.4 | P1 | `TaskService.archiveTask` | нет idempotency guard — двойная архивация пишет лишний лог |
| 2.5 | P1 | `TaskService.updateTaskStage` | `closedAt` не выставляется → `getAverageCompletionDays()` всегда null |
| 2.6 | P1 | `ClientOverviewPage` | мёртвый import, state и handler после рефакторинга |
| 2.7 | P2 | `CrmAccessService` | hardcoded `"На проверке"` — хрупкая data-coupling |
| 2.8 | P2 | везде | несогласованность `lossReason` vs `lostReason` |
| 2.9 | P2 | `routes.ts` | отсутствует `CLIENT_TASK_DETAILS` — нет единой точки истины |
| 2.10 | P2 | `AdminArchive*Page` | не фильтруют `archived=true`, смешивают семантику |

---

## 4. Порядок исправления

1. **Сначала** — `TaskRepository`: добавить `AND t.archived = false` во все активные queries, создать `findArchivedByStageType`. Без этого фича архива не работает семантически.
2. **Параллельно** — `navigate()` пути: заменить на `ROUTES.*`, добавить `CLIENT_TASK_DETAILS` в `routes.ts`.
3. **Затем** — `closedAt` в `updateTaskStage` при WON/LOST: одна строка, но влияет на аналитику.
4. **Затем** — idempotency в `archiveTask`.
5. **Потом** — мёртвый код в `ClientOverviewPage`.
6. **Техдолг** — `isPreFinal` на Stage, унификация `lossReason/lostReason`, `CLIENT_TASK_DETAILS` в routes.
