# Zhan Finance — список исправлений (с кодом)

Собрано по скриншотам, логам и разбору кода (`src_backend.zip`, `src_frontend.zip`).
Для каждого пункта: **Проблема** → **Причина в коде** → **Исправление (код)**.

Второй проход — доп. ревью кода на баги/неправильную логику — см. раздел **11**.

---

## 1. Уведомление админу о новой регистрации (клиент/сотрудник)

**Причина:** в `AuthService.register()` и `GoogleAuthService.loginWithGoogle()` нет вызова
`notificationService.notifyAdmins(...)` после сохранения пользователя.

### `modules/auth/service/AuthService.java`

```java
// было
User savedUser = userRepository.save(user);

// Создаём CRM-карточку клиента при регистрации
clientService.ensureProfile(savedUser, request.companyName(), request.phone());
RefreshToken refreshToken = refreshTokenService.create(savedUser);
return response(savedUser, refreshToken.getToken());
```

```java
// стало
User savedUser = userRepository.save(user);

// Создаём CRM-карточку клиента при регистрации
clientService.ensureProfile(savedUser, request.companyName(), request.phone());

notificationService.notifyAdmins(
        "Новая регистрация",
        savedUser.getFullName() + " (" + savedUser.getEmail() + ") зарегистрировался как "
                + (assignedRole == Role.EMPLOYEE ? "сотрудник" : "клиент"),
        "/admin/employees"
);

RefreshToken refreshToken = refreshTokenService.create(savedUser);
return response(savedUser, refreshToken.getToken());
```

Добавить зависимость в конструктор:
```java
private final com.example.zhanfinancebackend.modules.notifications.service.NotificationService notificationService;

public AuthService(
        UserRepository userRepository,
        PasswordEncoder passwordEncoder,
        AuthenticationManager authenticationManager,
        JwtService jwtService,
        RefreshTokenService refreshTokenService,
        ClientService clientService,
        com.example.zhanfinancebackend.modules.notifications.service.NotificationService notificationService // + новое
) {
    ...
    this.notificationService = notificationService;
}
```

### `modules/auth/service/GoogleAuthService.java`

```java
// было
user = userRepository.save(user);

if (isEmployee) {
    return null; // pending approval
}

// New Client: create empty profile (phone/company filled later via onboarding)
clientService.ensureProfile(user);
isNewUser = true;
```

```java
// стало
user = userRepository.save(user);

if (isEmployee) {
    notificationService.notifyAdmins(
            "Новая регистрация сотрудника",
            user.getFullName() + " (" + user.getEmail() + ") запросил доступ как сотрудник — требуется подтверждение",
            "/admin/employees"
    );
    return null; // pending approval
}

// New Client: create empty profile (phone/company filled later via onboarding)
clientService.ensureProfile(user);

notificationService.notifyAdmins(
        "Новая регистрация",
        user.getFullName() + " (" + user.getEmail() + ") зарегистрировался как клиент (Google)",
        "/admin/employees"
);
emailNotificationService.sendWelcomeEmail(user); // см. пункт 2

isNewUser = true;
```

Добавить `NotificationService` и `EmailNotificationService` в конструктор `GoogleAuthService` (по аналогии с `AuthService` выше).

---

## 2. Приветственное письмо при регистрации через Gmail

**Причина:** в `EmailNotificationService` нет метода welcome-письма.

### `modules/notifications/service/EmailNotificationService.java` — новый метод

```java
public void sendWelcomeEmail(com.example.zhanfinancebackend.modules.auth.entity.User user) {
    String subject = "Добро пожаловать в Zhan Finance";
    String html = """
            <div style="font-family:sans-serif">
              <h2>Добро пожаловать, %s!</h2>
              <p>Вы успешно зарегистрировались в системе Zhan Finance через Google-аккаунт.</p>
              <p>Вы можете войти в личный кабинет и начать работу прямо сейчас.</p>
            </div>
            """.formatted(user.getFullName());

    sendHtmlEmail(user.getEmail(), subject, html);
}
```

Вызывается из `GoogleAuthService.loginWithGoogle()` (см. пункт 1, ветка `isNewUser`).

---

## 3. Уведомление "Новый документ от клиента" ведёт не туда

**Причина:** `relativeLink` принимается, но никогда не сохраняется и не доходит до фронта.

### 3.1 `modules/notifications/entity/Notification.java` — добавить поле `link`

```java
@Column(name = "link")
private String link;

public Notification(User user, String title, String message, String link) {
    this.user = user;
    this.title = title;
    this.message = message;
    this.link = link;
    this.isRead = false;
}

// оставить старый конструктор для обратной совместимости
public Notification(User user, String title, String message) {
    this(user, title, message, null);
}

public String getLink() { return link; }
```

Плюс миграция БД (Flyway/Liquibase, посмотреть, что используется в проекте):
```sql
ALTER TABLE notifications ADD COLUMN link VARCHAR(255);
```

### 3.2 `modules/notifications/service/NotificationService.java`

```java
// было
@Transactional
public void createNotification(User user, String title, String message, String relativeLink) {
    if (user == null) return;
    Notification notification = new Notification(user, title, message);
    notificationRepository.save(notification);
}
```

```java
// стало
@Transactional
public void createNotification(User user, String title, String message, String relativeLink) {
    if (user == null) return;
    Notification notification = new Notification(user, title, message, relativeLink);
    notificationRepository.save(notification);
}
```

### 3.3 `modules/notifications/dto/NotificationDto.java`

```java
public class NotificationDto {
    private Long id;
    private String title;
    private String message;
    private String link;              // + новое поле
    private boolean isRead;
    private LocalDateTime createdAt;

    public NotificationDto(Long id, String title, String message, String link, boolean isRead, LocalDateTime createdAt) {
        this.id = id;
        this.title = title;
        this.message = message;
        this.link = link;
        this.isRead = isRead;
        this.createdAt = createdAt;
    }

    public String getLink() { return link; }
    // остальные геттеры без изменений
}
```

И маппинг в `NotificationService.mapToDto`:
```java
private NotificationDto mapToDto(Notification notification) {
    return new NotificationDto(
            notification.getId(),
            notification.getTitle(),
            notification.getMessage(),
            notification.getLink(),
            notification.isRead(),
            notification.getCreatedAt()
    );
}
```

### 3.4 `modules/documents/service/DocumentService.java` — передавать реальную ссылку на задачу

Нужно смотреть точный код вокруг строк 100–125, но по смыслу:
```java
// было (пример)
notificationService.notifyAdmins(
        "Новый документ от клиента",
        actor.getFullName() + " загрузил файл: " + document.getFileName(),
        null // либо вообще без 3-го аргумента / с "заглушкой"
);
```

```java
// стало
String taskLink = document.getTask() != null
        ? "/admin/tasks/" + document.getTask().getId()
        : "/admin/documents";

notificationService.notifyAdmins(
        "Новый документ от клиента",
        actor.getFullName() + " загрузил файл: " + document.getFileName(),
        taskLink
);
```
Аналогично поправить остальные вызовы `createNotification(...)`/`notifyAdmins(...)` в этом файле —
везде, где документ привязан к задаче, слать ссылку на задачу, а не на общий список.

### 3.5 Фронтенд

`frontend/src/entities/notification/model/types.ts`
```ts
// было
export interface NotificationDto {
  id: number;
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
}
```
```ts
// стало
export interface NotificationDto {
  id: number;
  title: string;
  message: string;
  link: string | null;   // + новое поле
  read: boolean;
  createdAt: string;
}
```

`frontend/src/pages/dashboard/shared/NotificationsPage.tsx`
```ts
// было
onClick={(e) => {
  ...
  navigate(getNotificationLink(notification));
}}
```
```ts
// стало
onClick={(e) => {
  ...
  navigate(notification.link ?? getNotificationLink(notification)); // link из бэка в приоритете,
                                                                      // getNotificationLink — фолбэк
                                                                      // для старых уведомлений без link
}}
```
То же самое поправить в `widgets/dashboard-shell/NotificationBell.tsx`, если там тоже есть переход по клику.

---

## 4. i18n логин-страницы (ошибки с бэка захардкожены на RU/EN вперемешку)

**Причина:** сообщения исключений уходят на фронт как есть и не переводятся.

### 4.1 Завести коды ошибок вместо текста

`modules/auth/service/AuthService.java`
```java
// было
if (isEmployee) {
    throw new com.example.zhanfinancebackend.common.exception.BadRequestException(
            "Сотрудники могут регистрироваться только через Google-аккаунт.");
}
```
```java
// стало — вместо строки передаём код ошибки
if (isEmployee) {
    throw new com.example.zhanfinancebackend.common.exception.BadRequestException(
            ErrorCode.EMPLOYEE_MUST_USE_GOOGLE.name()); // либо через конструктор с ErrorCode, смотря
                                                          // как устроен common/exception/ErrorCode.java
}
```
Аналогично для `ConflictException("Email is already registered")`,
`"Аккаунт ещё не активирован администратором"`, `"Invalid Google token"` и т.д. — завести
`ErrorCode.EMAIL_ALREADY_REGISTERED`, `ErrorCode.ACCOUNT_NOT_ACTIVATED`, `ErrorCode.INVALID_GOOGLE_TOKEN`.

### 4.2 На фронте — маппинг кода в перевод

`frontend/src/shared/i18n/locales/ru/auth.json` / `.../en/auth.json`
```json
{
  "errors": {
    "EMPLOYEE_MUST_USE_GOOGLE": "Сотрудники могут регистрироваться только через Google-аккаунт",
    "EMAIL_ALREADY_REGISTERED": "Этот email уже зарегистрирован",
    "ACCOUNT_NOT_ACTIVATED": "Аккаунт ещё не подтверждён администратором",
    "INVALID_GOOGLE_TOKEN": "Не удалось войти через Google, попробуйте ещё раз"
  }
}
```
```ts
// там, где сейчас показывают error.message напрямую, например в LoginPage.tsx / RegisterPage.tsx
const code = error?.response?.data?.errorCode; // смотря как ApiException сериализуется в теле ответа
toast.error(t(`auth:errors.${code}`, { defaultValue: t('auth:errors.UNKNOWN') }));
```

---

## 5. Чат "You don't have access" + сотрудник не видит клиента после взятия задачи

**Причина:** `Task.assignedTo` и `User.assignedEmployee` (у клиента) — два независимых поля,
`TaskService.assignTask()` синхронизирует только первое.

### `modules/crm/service/TaskService.java`

```java
// было
public TaskDto assignTask(Long taskId, Long assigneeId, User user) {
    Task task = getTaskEntity(taskId);
    User assignee = null;
    if (assigneeId != null) {
        assignee = userRepository.findById(assigneeId)
                .orElseThrow(() -> new com.example.zhanfinancebackend.common.exception.ResourceNotFoundException("Assignee not found"));
    }
    if (task.getAssignedTo() != assignee) {
        ...
    }
    task.setAssignedTo(assignee);
    Task savedTask = taskRepository.save(task);
    ...
```

```java
// стало
public TaskDto assignTask(Long taskId, Long assigneeId, User user) {
    Task task = getTaskEntity(taskId);
    User assignee = null;
    if (assigneeId != null) {
        assignee = userRepository.findById(assigneeId)
                .orElseThrow(() -> new com.example.zhanfinancebackend.common.exception.ResourceNotFoundException("Assignee not found"));
    }

    Long oldAssigneeId = task.getAssignedTo() != null ? task.getAssignedTo().getId() : null;
    Long newAssigneeId = assignee != null ? assignee.getId() : null;

    if (!java.util.Objects.equals(oldAssigneeId, newAssigneeId)) {   // fix #11.1: сравнение по id, а не по ссылке
        String oldAssigneeName = task.getAssignedTo() != null ? task.getAssignedTo().getFullName() : "None";
        String assigneeName = assignee != null ? assignee.getFullName() : "Не назначен";
        logActivity(task, user, "Назначил исполнителя: " + assigneeName);
        auditService.logAction("UPDATE_ASSIGNEE", "Task", task.getId(), "Assignee changed from " + oldAssigneeName + " to " + assigneeName);
    }

    task.setAssignedTo(assignee);

    // fix #5: синхронизируем "закреплённого сотрудника" клиента, иначе сотрудник
    // не увидит клиента в чате / списке клиентов / счетах после назначения задачи
    if (assignee != null && task.getClient() != null) {
        clientService.assignEmployeeToClient(task.getClient().getId(), assignee.getId());
    }

    Task savedTask = taskRepository.save(task);
    ...
```

Добавить `ClientService` в конструктор `TaskService` (сейчас его там нет):
```java
private final ClientService clientService; // + новое поле

public TaskService(
        TaskRepository taskRepository,
        UserRepository userRepository,
        CrmAccessService accessService,
        com.example.zhanfinancebackend.modules.notifications.service.NotificationService notificationService,
        com.example.zhanfinancebackend.modules.notifications.service.EmailNotificationService emailNotificationService,
        AuditService auditService,
        com.example.zhanfinancebackend.modules.services.repository.ServiceRepository serviceRepository,
        StageRepository stageRepository,
        PipelineRepository pipelineRepository,
        com.example.zhanfinancebackend.modules.crm.mapper.TaskMapper taskMapper,
        com.example.zhanfinancebackend.modules.documents.repository.DocumentRepository documentRepository,
        com.example.zhanfinancebackend.modules.documents.service.StorageService storageService,
        ClientService clientService // + новое
) {
    ...
    this.clientService = clientService;
}
```

> ⚠️ `ClientService` сейчас не имеет циклической зависимости на `TaskService`, так что это
> безопасно добавить. Если позже `ClientService` тоже начнёт зависеть от `TaskService` — вынести
> синхронизацию в отдельный `ClientAssignmentService`, чтобы не ловить circular dependency у Spring.

---

## 6. Отказ сотрудника от задачи → подтверждение админом

Флоу отсутствует полностью, нужен новый статус + два эндпоинта.

### 6.1 `modules/crm/entity/Task.java` — новое поле

```java
@Column(name = "reassignment_requested", nullable = false)
private boolean reassignmentRequested = false;

public boolean isReassignmentRequested() { return reassignmentRequested; }
public void setReassignmentRequested(boolean reassignmentRequested) {
    this.reassignmentRequested = reassignmentRequested;
}
```
Миграция:
```sql
ALTER TABLE tasks ADD COLUMN reassignment_requested BOOLEAN NOT NULL DEFAULT FALSE;
```

### 6.2 `modules/crm/service/TaskService.java` — новые методы

```java
@Transactional
public TaskDto requestDecline(Long taskId, User employee) {
    Task task = getTaskEntity(taskId);

    if (task.getAssignedTo() == null || !task.getAssignedTo().getId().equals(employee.getId())) {
        throw new org.springframework.security.access.AccessDeniedException(
                "Только текущий исполнитель может отказаться от задачи");
    }
    if (task.isReassignmentRequested()) {
        return taskMapper.mapToDto(task); // уже отправлено на подтверждение — повторно не шлём
    }

    task.setReassignmentRequested(true);
    logActivity(task, employee, "Запросил отказ от задачи, ожидает подтверждения админа");
    Task saved = taskRepository.save(task);

    notificationService.notifyAdmins(
            "Запрос на отказ от задачи",
            employee.getFullName() + " хочет отказаться от задачи '" + task.getTitle() + "'",
            "/admin/tasks/" + task.getId()
    );

    return taskMapper.mapToDto(saved);
}

@Transactional
public TaskDto resolveDeclineRequest(Long taskId, boolean approve, User admin) {
    Task task = getTaskEntity(taskId);

    if (!task.isReassignmentRequested()) {
        throw new com.example.zhanfinancebackend.common.exception.BadRequestException(
                "По этой задаче нет активного запроса на отказ");
    }

    task.setReassignmentRequested(false);

    if (approve) {
        User previousAssignee = task.getAssignedTo();
        task.setAssignedTo(null);
        logActivity(task, admin, "Подтвердил отказ, задача возвращена в пул");
        if (previousAssignee != null) {
            notificationService.createNotification(previousAssignee,
                    "Отказ подтверждён",
                    "Админ подтвердил ваш отказ от задачи '" + task.getTitle() + "'",
                    "/dashboard/tasks");
        }
    } else {
        logActivity(task, admin, "Отклонил запрос на отказ, задача остаётся у исполнителя");
        if (task.getAssignedTo() != null) {
            notificationService.createNotification(task.getAssignedTo(),
                    "Отказ отклонён",
                    "Админ отклонил ваш запрос на отказ от задачи '" + task.getTitle() + "'",
                    "/dashboard/tasks");
        }
    }

    return taskMapper.mapToDto(taskRepository.save(task));
}
```

### 6.3 `modules/crm/controller/TaskController.java` — новые эндпоинты

```java
@PostMapping("/{id}/decline")
@PreAuthorize("hasRole('EMPLOYEE')")
public ApiResponse<TaskDto> declineTask(
        @PathVariable Long id,
        @AuthenticationPrincipal UserPrincipal principal) {
    return ApiResponse.success(taskService.requestDecline(id, principal.getUser()));
}

@PostMapping("/{id}/decline/resolve")
@PreAuthorize("hasRole('ADMIN')")
public ApiResponse<TaskDto> resolveDecline(
        @PathVariable Long id,
        @RequestParam boolean approve,
        @AuthenticationPrincipal UserPrincipal principal) {
    return ApiResponse.success(taskService.resolveDeclineRequest(id, approve, principal.getUser()));
}
```

### 6.4 Фронтенд — бейдж + кнопки

В карточке задачи (`entities/task/ui`, конкретный компонент нужно смотреть по месту):
```tsx
{task.reassignmentRequested ? (
  <span className="text-amber-600 text-sm font-medium">
    Ожидает подтверждения отказа
  </span>
) : isMyTask && (
  <button onClick={() => declineTask(task.id)}>Отказаться от задачи</button>
)}

{isAdmin && task.reassignmentRequested && (
  <div className="flex gap-2">
    <button onClick={() => resolveDecline(task.id, true)}>Подтвердить отказ</button>
    <button onClick={() => resolveDecline(task.id, false)}>Отклонить</button>
  </div>
)}
```
(+ добавить `reassignmentRequested: boolean` в `TaskDto` на бэке и в `entities/task/model` на фронте.)

---

## 7. "Пул задач" и "Список задач" не совпадают

**Причина:** список сотрудника матчит `c.assignedEmployee = :employee OR t.assignedTo = :employee`,
а пул — только `t.assignedTo IS NULL`. Задача с назначенным клиентом, но пустым `assignedTo`,
попадает в оба места одновременно.

### `modules/crm/repository/TaskRepository.java`

```java
// было
@Query("select t from Task t join fetch t.client c left join fetch c.assignedEmployee left join fetch t.assignedTo left join fetch t.createdBy left join fetch t.stage s where (c.assignedEmployee = :employee or t.assignedTo = :employee) and t.archived = false")
List<Task> findAllByEmployeeWithDetails(@Param("employee") User employee);
```

```java
// стало — источник правды один: t.assignedTo.
// "Закреплённый за клиентом сотрудник" (c.assignedEmployee) — это про доступ к чату/CRM-карточке
// клиента, а не про "мои задачи". После фикса п.5 assignedTo и assignedEmployee синхронизированы
// в момент назначения, так что условие через client больше не нужно и только плодит дубли.
@Query("select t from Task t join fetch t.client c left join fetch c.assignedEmployee left join fetch t.assignedTo left join fetch t.createdBy left join fetch t.stage s where t.assignedTo = :employee and t.archived = false")
List<Task> findAllByEmployeeWithDetails(@Param("employee") User employee);
```

Если по бизнес-логике сотрудник всё же должен видеть в "Списке задач" все задачи всех своих
закреплённых клиентов (не только те, что назначены лично ему) — тогда наоборот нужно убрать
`assignedTo IS NULL` в пуле и заменить на "нет ни `assignedTo`, ни `assignedEmployee` у клиента",
но это уже отдельное решение по продукту, а не баг-фикс. Рекомендую первый вариант — он
однозначно убирает дублирование.

---

## 8–10. См. предыдущую версию файла (регистрация/уведомления/пул vs список) — код уже приведён выше в 1–7.

---

## 11. Дополнительно найденные баги при ревью кода

### 11.1 Сравнение entity по ссылке вместо ID (`TaskService.assignTask`)

```java
// modules/crm/service/TaskService.java, было
if (task.getAssignedTo() != assignee) {
```
Сравнение JPA-сущностей через `!=` — сравнение ссылок, а не значений. `assignee` всегда получен
свежим вызовом `userRepository.findById(assigneeId)`, и хотя в рамках одной Hibernate-сессии
identity map обычно возвращает тот же объект для того же ID, полагаться на это нельзя (легко
сломается при добавлении кэша второго уровня, detached-сущностей, смене стратегии фетча). На
практике из-за этого в лог активности/аудит может писаться "Назначил исполнителя" даже когда
исполнитель не менялся. Исправление — сравнивать по ID, см. код в пункте 5 (`Objects.equals(oldAssigneeId, newAssigneeId)`).

### 11.2 Слабая проверка типа файла при загрузке документов

`modules/documents/service/DocumentService.java`:
```java
if (contentType.contains("exe") || contentType.contains("javascript")) {
    throw new BadRequestException("Executable files are not allowed");
}
```
Это блок-лист по подстроке в `Content-Type`, который клиент присылает сам (заголовок легко
подделать) — не проверяется ни расширение файла, ни реальное содержимое. `text/html`,
`.svg` (может содержать `<script>`), `.html`-файл под безобидным `Content-Type` — всё пройдёт.
Скачивание отдаётся с `Content-Disposition: attachment`, что снижает риск прямого XSS в браузере,
но полагаться только на это не стоит.

**Что сделать:** перейти на allow-list вместо block-list (разрешить только конкретные типы:
pdf, docx, xlsx, png, jpg и т.п.), и по возможности определять реальный MIME по содержимому файла
(например, Apache Tika — в коде уже есть комментарий `// For production, maybe use a more robust
detection like Apache Tika`, то есть авторы сами знали про этот недостаток).

```java
private static final java.util.Set<String> ALLOWED_CONTENT_TYPES = java.util.Set.of(
        "application/pdf", "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "image/png", "image/jpeg"
);

if (!ALLOWED_CONTENT_TYPES.contains(contentType)) {
    throw new BadRequestException("Недопустимый тип файла: " + contentType);
}
```

### 11.3 `DatePicker.tsx` — `required` на скрытом инпуте не работает

Файл, который был прислан в чате (`shared/ui/.../DatePicker.tsx` или аналог):
```tsx
<input type="hidden" value={value} required={required} />
```
По спецификации HTML5, элементы `<input type="hidden">` **исключены из constraint validation** —
атрибут `required` на них браузер полностью игнорирует. Если форма полагается на нативную
валидацию (`<form onSubmit>` без ручной проверки), поле даты можно оставить пустым, и форма всё
равно отправится.

**Что сделать** — валидировать значение вручную при сабмите, а не полагаться на HTML5:
```tsx
// в компоненте формы, где используется DatePicker
const handleSubmit = (e: React.FormEvent) => {
  e.preventDefault();
  if (required && !dateValue) {
    setDateError('Укажите дату');
    return;
  }
  ...
};
```
Либо заменить `<input type="hidden" required>` на видимый, но визуально спрятанный (`sr-only`)
`<input type="text">` с `required` — такие поля **участвуют** в constraint validation в отличие
от `type="hidden"`.

### 11.4 Побочный эффект бага из п.5 — счета (`InvoiceAccessService`) тоже страдают

`modules/billing/service/InvoiceAccessService.java` и
`modules/documents/service/DocumentAccessService.java` проверяют доступ сотрудника к счетам и
документам клиента через тот же `assignedToEmployee(actor, client)`, то есть через
`client.getAssignedEmployee()`. `DocumentAccessService` частично подстраховался — для документов,
привязанных к задаче, есть доп. проверка `sameUser(actor, document.getTask().getAssignedTo())`,
а вот `InvoiceAccessService` такого фолбэка не имеет вообще. Значит, тот же баг "сотрудник назначен
на задачу, но не видит клиента" бил и по счетам клиента, не только по чату. Фикс в пункте 5
(синхронизация `assignedEmployee` при `assignTask`) закрывает и это — отдельного кода не требуется,
но стоит добавить тест на `InvoiceAccessServiceTest`, проверяющий доступ сотрудника к счёту сразу
после `TaskService.assignTask(...)`.

---

## 12. Требует дополнительной проверки (не хватило данных)

- В логе есть `POST /api/auth/register` → `400`, и отдельно `GET /api/auth/register` →
  `405`. Тело 400-ответа в присланных логах нет — нужно посмотреть Network-таб браузера
  (Response body), возможно там просто "email already registered" без понятного вывода в UI.
  GET, скорее всего, левый запрос (browser prefetch/расширение), но стоит проверить, что фронт
  нигде явно не делает `GET` вместо `POST` при регистрации.
- Google Sign-In origin error (`The given origin is not allowed for the given client ID`) — это
  конфигурация в Google Cloud Console (Authorized JavaScript origins), не код. Нужно добавить
  туда `https://mrsgemaseny.github.io`.
