# JF-1C — Multi-Tenancy Plan

> Самое важное архитектурное изменение перед вторым клиентом.  
> Без этого — нельзя пускать чужие данные в систему.

---

## Почему это нельзя откладывать

Сейчас все данные в одной схеме без разделения по организациям.  
Если второй клиент (бухгалтерия) зарегистрируется — их бухгалтеры будут видеть задачи первого клиента.  
Это не баг — это архитектурное отсутствие изоляции.

Исправить после того как данные накопились — в 10 раз сложнее.

---

## Выбор стратегии

Три распространённых подхода:

| Подход | Как работает | Когда использовать |
|--------|-------------|-------------------|
| Schema per tenant | Каждый клиент в отдельной PostgreSQL-схеме | 10+ клиентов, строгие требования к изоляции, разные миграции |
| Row-level isolation | Поле `organization_id` на каждой таблице + RLS | До 50 клиентов, один кодовая база, простые миграции |
| Separate database | Каждый клиент в отдельной БД | Enterprise, очень строгий compliance |

**Для JF-1C сейчас:** Row-level isolation (`organization_id` + PostgreSQL RLS).

**Почему:**
- Проще мигрировать существующие данные
- Одна Flyway-миграция для всех
- Fly.io + один PostgreSQL инстанс — не нужен оркестратор схем
- При необходимости можно мигрировать на schema-per-tenant позже

---

## Шаг 1 — Создание `organizations` таблицы

```sql
-- V110__Add_Organizations.sql
CREATE TABLE organizations (
    id          BIGSERIAL PRIMARY KEY,
    name        VARCHAR(256) NOT NULL,
    slug        VARCHAR(64) UNIQUE NOT NULL,  -- для URL, например "romashka-buh"
    logo_url    VARCHAR(512),
    plan_tier   VARCHAR(32) NOT NULL DEFAULT 'TRIAL',
    plan_expires_at TIMESTAMPTZ,
    max_employees   INT NOT NULL DEFAULT 3,
    max_clients     INT NOT NULL DEFAULT 20,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Создать организацию для текущих данных (ваша фирма)
INSERT INTO organizations (name, slug, plan_tier, max_employees, max_clients)
VALUES ('ZhanFinance', 'zhanfinance', 'CORPORATE', 999, 9999);
```

---

## Шаг 2 — Добавить `organization_id` к ключевым таблицам

Не все таблицы нуждаются в `organization_id`. Только те, которые содержат бизнес-данные конкретной фирмы.

```sql
-- V111__Add_Organization_Id_To_Tables.sql

-- Пользователи принадлежат организации
ALTER TABLE users ADD COLUMN organization_id BIGINT REFERENCES organizations(id);
UPDATE users SET organization_id = 1; -- привязать к первой орг
ALTER TABLE users ALTER COLUMN organization_id SET NOT NULL;

-- Задачи
ALTER TABLE tasks ADD COLUMN organization_id BIGINT REFERENCES organizations(id);
UPDATE tasks SET organization_id = 1;
ALTER TABLE tasks ALTER COLUMN organization_id SET NOT NULL;

-- Пайплайны
ALTER TABLE pipelines ADD COLUMN organization_id BIGINT REFERENCES organizations(id);
UPDATE pipelines SET organization_id = 1;
ALTER TABLE pipelines ALTER COLUMN organization_id SET NOT NULL;

-- Документы
ALTER TABLE documents ADD COLUMN organization_id BIGINT REFERENCES organizations(id);
UPDATE documents SET organization_id = 1;
ALTER TABLE documents ALTER COLUMN organization_id SET NOT NULL;

-- Счета
ALTER TABLE invoices ADD COLUMN organization_id BIGINT REFERENCES organizations(id);
UPDATE invoices SET organization_id = 1;
ALTER TABLE invoices ALTER COLUMN organization_id SET NOT NULL;

-- Уведомления — через user (у user есть org_id, этого достаточно)
-- Чат-сообщения — аналогично через sender/receiver
-- Audit log — через user
-- Курсы — если курсы общие (не per-org) — organization_id не нужен
--           если курсы создаются каждой фирмой отдельно — нужен
```

**Таблицы, которым `organization_id` НЕ нужен:**
- `refresh_tokens` (через user)
- `audit_logs` (через user)
- `chat_messages` (через sender/receiver которые имеют org_id)
- `notifications` (через user)
- `services` (это глобальный справочник услуг лендинга)

---

## Шаг 3 — PostgreSQL Row Level Security

RLS — второй рубеж защиты на уровне БД. Даже если в приложении баг — БД не отдаст чужие данные.

```sql
-- V112__Enable_RLS.sql

-- Включить RLS
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE pipelines ENABLE ROW LEVEL SECURITY;

-- Политика: видишь только свою организацию
-- app.current_org_id устанавливается приложением перед каждым запросом
CREATE POLICY org_isolation ON tasks
    USING (organization_id = current_setting('app.current_org_id')::BIGINT);

CREATE POLICY org_isolation ON users
    USING (organization_id = current_setting('app.current_org_id')::BIGINT);

-- Аналогично для остальных таблиц
```

```java
// TenantContext.java — хранит текущую организацию в ThreadLocal
public class TenantContext {
    private static final ThreadLocal<Long> currentOrg = new ThreadLocal<>();

    public static void setOrganizationId(Long orgId) {
        currentOrg.set(orgId);
    }

    public static Long getOrganizationId() {
        return currentOrg.get();
    }

    public static void clear() {
        currentOrg.remove();
    }
}
```

```java
// TenantFilter.java — Spring фильтр, устанавливает org_id из токена
@Component
public class TenantFilter extends OncePerRequestFilter {

    @Autowired
    private DataSource dataSource;

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain)
            throws ServletException, IOException {
        try {
            // После JwtAuthenticationFilter текущий user уже в SecurityContext
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            if (auth != null && auth.getPrincipal() instanceof UserPrincipal principal) {
                Long orgId = principal.getUser().getOrganizationId();
                TenantContext.setOrganizationId(orgId);
                // Установить в PostgreSQL сессию для RLS
                setPostgresSessionVar(orgId);
            }
            chain.doFilter(request, response);
        } finally {
            TenantContext.clear();
        }
    }

    private void setPostgresSessionVar(Long orgId) {
        // Через JDBC: SET LOCAL app.current_org_id = '42'
        // Реализация зависит от connection pool
    }
}
```

---

## Шаг 4 — Обновить репозитории

После добавления `organization_id` — ВСЕ запросы должны фильтровать по нему.

```java
// Было:
List<Task> findAll();

// Стало:
List<Task> findAllByOrganizationId(Long organizationId);

// Или через Spring Data Specification + TenantContext:
// Добавить @EntityListener или AuditorAware для автоматической подстановки
```

Альтернатива — `@Query` с `WHERE organization_id = :orgId` на всех методах репозитория.  
Это явно, читаемо, и не требует магии.

---

## Шаг 5 — Обновить UserPrincipal

```java
public class UserPrincipal implements UserDetails {
    private final User user;

    // Уже есть. Добавить:
    public Long getOrganizationId() {
        return user.getOrganizationId();
    }
}
```

---

## Порядок выполнения (критично)

```
1. Создать organizations таблицу → вставить текущую фирму (id=1)
2. Добавить organization_id к таблицам с UPDATE SET organization_id=1
3. Добавить NOT NULL constraint
4. Создать индексы на organization_id (горячее поле):
   CREATE INDEX idx_tasks_org_id ON tasks(organization_id);
   CREATE INDEX idx_users_org_id ON users(organization_id);
5. Обновить репозитории — добавить фильтр по org_id
6. Добавить TenantFilter в цепочку (после JwtAuthenticationFilter)
7. Включить RLS (опционально, но рекомендуется)
8. Протестировать: создать тестовую org_id=2, убедиться что данные не пересекаются
```

---

## Что ломается при переходе

| Что | Почему ломается | Как починить |
|-----|----------------|-------------|
| `taskService.getAllTasks()` | Возвращает все задачи | Добавить `.findAllByOrganizationId(orgId)` |
| `adminService.getUsers()` | Возвращает всех пользователей | Фильтр по `organizationId` текущего admin'а |
| Flyway миграции | Порядок важен | Сначала таблица, потом ALTER, потом NOT NULL |
| Тесты | `@Transactional` + RLS конфликтуют | В тестах отключить RLS или передавать org_id явно |

---

## Тест изоляции (обязательный перед запуском второго клиента)

```java
@Test
void tenantIsolation_OrgB_CannotSeeOrgA_Tasks() {
    // Создать две организации
    Organization orgA = createOrg("Firm A");
    Organization orgB = createOrg("Firm B");

    // Создать задачу в org A
    User adminA = createAdmin(orgA);
    Task taskA = taskService.createTask(buildRequest(), adminA);

    // Попытаться прочитать из org B
    User adminB = createAdmin(orgB);
    TenantContext.setOrganizationId(orgB.getId());
    List<Task> tasks = taskService.getAllTasks(null, null, null, null);

    // Задача org A не должна быть видна
    assertThat(tasks).noneMatch(t -> t.getId().equals(taskA.getId()));
}
```

Этот тест должен быть зелёным перед тем как пускать второго клиента.
