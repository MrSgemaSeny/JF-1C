# JF-1C — Testing Strategy

> Что тестировать, как тестировать, и почему именно так.  
> Основано на существующих тестах в проекте.

---

## Текущее состояние (честно)

В проекте уже есть:
- `AuthServiceUnitTests` — unit-тесты на Mockito
- `ApiSmokeTests`, `CourseApiSmokeTests` — end-to-end через MockMvc
- `TaskServiceIntegrationTests`, `PipelineIntegrationTests` — интеграционные
- `ContactRequestControllerTest` — контроллер-тесты
- `InvoiceServiceTest` — unit-тест биллинга

Это хорошая база. Проблема: покрытие неравномерное. Авторизационная логика (`CrmAccessService`) — без тестов. Биллинговые переходы статусов — без тестов. Фронтенд — 2 теста на весь проект.

---

## Пирамида тестирования для этого проекта

```
          /\
         /E2E\          ← 0 сейчас, не нужны пока (Playwright дорого)
        /------\
       / Integ  \       ← есть, расширять под новые модули
      /----------\
     /    Unit    \     ← основа, максимальное покрытие бизнес-логики
    /--------------\
```

**Стратегия:** максимум unit, минимум integration (они медленные), E2E — отложить до 10+ клиентов.

---

## Backend: что и как тестировать

### Unit-тесты — для сервисов с бизнес-логикой

Используй `@ExtendWith(MockitoExtension.class)`. Без Spring-контекста — быстро.

**Что покрываем unit-тестами:**

```
AuthService          ← регистрация, логин, дубликат email
RefreshTokenService  ← создание, verify, истечение
InvoiceService       ← переходы статусов DRAFT→ISSUED→PAID/CANCELED
TaskService          ← создание, смена стадии, архивация
CrmAccessService     ← assertCanReadTask, assertCanUpdateTask по ролям
```

**Пример паттерна (по образцу AuthServiceUnitTests):**

```java
@Test
void createTask_AsEmployee_AssignedToSelf_Success() {
    // arrange
    User employee = buildUser(Role.EMPLOYEE);
    TaskCreateRequest req = new TaskCreateRequest(...);
    when(taskRepository.save(any())).thenReturn(buildTask(employee));

    // act
    TaskDto result = taskService.createTask(req, employee);

    // assert
    assertThat(result.getAssignedToId()).isEqualTo(employee.getId());
}

@Test
void createTask_AsClient_ThrowsUnauthorized() {
    User client = buildUser(Role.CLIENT);
    assertThatThrownBy(() -> taskService.createTask(req, client))
        .isInstanceOf(UnauthorizedException.class);
}
```

**Правило именования тестов:** `метод_условие_ожидаемыйРезультат()`

```java
void login_WrongPassword_ThrowsBadCredentials()
void getTask_ClientAccessesOtherClientTask_ThrowsUnauthorized()
void invoice_TransitionToIssued_SendsEmailToClient()
```

### Интеграционные тесты — для сложных запросов к БД

`@SpringBootTest` + реальная тестовая БД (H2 in-memory или отдельный PostgreSQL через Testcontainers).

**Когда нужен интеграционный тест (не unit):**
- Логика использует `@EntityGraph` или JOIN FETCH — нужна реальная БД
- Проверяешь каскадные удаления / constraints
- Проверяешь `@Scheduled` задачи
- Проверяешь Flyway миграции

```java
@SpringBootTest
@Transactional // откатывает данные после каждого теста
class TaskServiceIntegrationTests {

    @Autowired TaskService taskService;
    @Autowired UserRepository userRepository;

    @Test
    void getAllTasks_WithClientFilter_ReturnsOnlyClientTasks() {
        // создаём реальные данные в тестовой БД
        User client = userRepository.save(buildUser(Role.CLIENT));
        // ...
    }
}
```

### Smoke-тесты — для критических API-путей

По образцу `ApiSmokeTests`. HTTP end-to-end через MockMvc.

**Что покрываем:**

```
POST /api/auth/register       → 200 + токен
POST /api/auth/login          → 200 + токен
POST /api/auth/refresh        → 200 + новый токен
GET  /api/crm/tasks           → 200 (EMPLOYEE)
GET  /api/crm/tasks           → 403 (неаутентифицированный)
GET  /api/crm/tasks/{id}      → 403 (CLIENT чужой задачи)
POST /api/billing/invoices    → 200 (ADMIN)
GET  /api/admin/users         → 403 (EMPLOYEE)
```

Smoke-тесты — не для логики. Для: «приложение стартует, эндпоинты отвечают, авторизация работает».

### Что НЕ тестировать

- Геттеры и сеттеры JPA-сущностей
- Конфигурационные классы (SecurityConfig, CorsConfig)
- Маппер если он делает только прямое поле→поле
- Репозитории без кастомных запросов (Spring Data сам протестирован)

---

## Frontend: что и как тестировать

Сейчас на фронте только `ContactForm.test.tsx` и `SolutionPicker.test.tsx` и `LoginPage.test.tsx`. Это мало.

### Инструменты (уже в проекте)

- Vitest — test runner
- React Testing Library — рендеринг компонентов

### Что тестировать на фронте

**Да — компоненты с логикой:**

```typescript
// SolutionPicker.test.tsx — хороший пример
// Тестируем: выбор опции → меняется вопрос → в конце показывается результат

// Что ещё добавить:
TaskKanbanBoard       ← drag-and-drop смена стадии
ClientTaskDetailsPage ← кнопки Принять/Отклонить (isPreFinal-логика)
InvoiceForm           ← валидация суммы, дедлайна
AuthContext           ← logout очищает токены
```

**Нет — не тестировать:**

```typescript
// Простые presentational-компоненты без логики
function UserAvatar({ name }: { name: string }) {
  return <img alt={name} />;
}
// Тест этого — потеря времени.
```

### Паттерн теста компонента

```typescript
import { render, screen, fireEvent } from '@testing-library/react';
import { TaskCard } from './TaskCard';

describe('TaskCard', () => {
  const mockTask = { id: 1, title: 'Test task', stageId: 2, isPreFinal: false };

  it('отображает название задачи', () => {
    render(<TaskCard task={mockTask} onStageChange={vi.fn()} />);
    expect(screen.getByText('Test task')).toBeInTheDocument();
  });

  it('показывает кнопки принять/отклонить если isPreFinal=true', () => {
    render(<TaskCard task={{ ...mockTask, isPreFinal: true }} onStageChange={vi.fn()} />);
    expect(screen.getByText('Принять')).toBeInTheDocument();
  });
});
```

---

## Приоритет: что написать прямо сейчас

| # | Тест | Почему важен | Сложность |
|---|------|-------------|-----------|
| 1 | `CrmAccessServiceTest` — CLIENT не видит чужие задачи | Баг = утечка данных клиента | Низкая |
| 2 | `InvoiceStatusTransitionTest` — нельзя перейти PAID→DRAFT | Финансовый инвариант | Низкая |
| 3 | `ClientTaskDetailsPage.test.tsx` — isPreFinal кнопки | Баг уже существует | Средняя |
| 4 | `RefreshTokenRotationTest` — использованный токен отклоняется | Безопасность | Низкая |
| 5 | `TaskService_pagination_test` — getAllTasks возвращает Page | После добавления пагинации | Средняя |

---

## Запуск тестов

```bash
# Backend
./mvnw test                          # все тесты
./mvnw test -Dtest=AuthServiceUnitTests  # конкретный класс
./mvnw test -pl . -Dsurefire.failIfNoSpecifiedTests=false  # без fail при 0 тестах

# Frontend
npm run test                         # watch mode
npm run test -- --run                # один прогон (CI)
npm run coverage                     # отчёт покрытия
```

---

## CI (GitHub Actions)

Тесты уже запускаются в pipeline. Правило:
- PR не мержится если тесты красные
- Coverage не обязан быть 100% — важно что критические пути покрыты
- Интеграционные тесты запускаются отдельным шагом (они медленнее)
