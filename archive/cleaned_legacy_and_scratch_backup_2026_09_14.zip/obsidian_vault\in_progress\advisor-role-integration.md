# ADVISOR Role Integration — ZhanFinance (JF-1C)

## Concept

ADMIN is God of the system — full access, full responsibility, full protection.
ADVISOR is the right hand of ADMIN — manages people and processes, cannot break the system.

The key distinction:
- ADMIN operates on the system (users, roles, billing config, system settings)
- ADVISOR operates with people (tasks, comments, clients, employees, approvals)

---

## What ADVISOR Can Do

### CRM
- Read all tasks across all pipelines
- Add comments to any task
- Change task stage (except WON/LOST — those require ADMIN or client confirmation)
- Confirm sending task to client review (pre-final stage approval)
- Confirm or reject task cancellation requests from employees
- Reassign tasks between employees
- View all client profiles and contact info

### Communication
- Send messages in any chat (employee-client, internal)
- Create internal notifications for employees
- View all notification history

### Reports (read-only)
- View finance summary
- View employee workload
- View audit log (read-only)
- View all documents and generated files

### What ADVISOR Cannot Do
- Create, edit, or delete users
- Change user roles
- Access billing settings or subscription management
- Delete tasks, pipelines, or stages
- Access system configuration
- Trigger any destructive operation

---

## Backend Implementation

### Step 1 — Add Role to Enum

File: `modules/auth/entity/Role.java`

```java
// Add after CURATOR
ADVISOR
```

### Step 2 — Flyway Migration V109

File: `db/migration/V109__Add_Advisor_Role.sql`

```sql
-- No schema change needed if Role is stored as VARCHAR
-- Add seed advisor account if needed
-- UPDATE users SET role = 'ADVISOR' WHERE email = 'advisor@zhanfinance.kz';
```

### Step 3 — CrmAccessService

Add ADVISOR branch to every access method.

```java
// canReadTask — ADVISOR reads everything
if (actor.getRole() == Role.ADVISOR) {
    return true;
}

// canUpdateTaskStage — ADVISOR can move stages except final
if (actor.getRole() == Role.ADVISOR) {
    if (newStage != null &&
        (newStage.getType() == StageType.WON || newStage.getType() == StageType.LOST)) {
        return false; // final stages: client or admin only
    }
    return true;
}

// canUpdateTaskDetails — ADVISOR can edit
if (actor.getRole() == Role.ADVISOR) {
    return true;
}

// canAssignTask — ADVISOR can reassign
if (actor.getRole() == Role.ADVISOR) {
    return true;
}

// canReadClient — ADVISOR reads all
if (actor.getRole() == Role.ADVISOR) {
    return true;
}
```

### Step 4 — SecurityConfig Permit Rules

ADVISOR uses the same authenticated endpoints as EMPLOYEE and ADMIN.
No new permitAll rules needed. Enforce via CrmAccessService, not URL patterns.

### Step 5 — @PreAuthorize on Destructive Endpoints

Endpoints that ADVISOR must never reach — lock them to ADMIN only:

```java
// AdminController — user management
@PreAuthorize("hasRole('ADMIN')")
@DeleteMapping("/users/{id}")
public ResponseEntity<Void> deleteUser(...) { ... }

@PreAuthorize("hasRole('ADMIN')")
@PatchMapping("/users/{id}/role")
public ResponseEntity<Void> updateRole(...) { ... }

// Billing config
@PreAuthorize("hasRole('ADMIN')")
@PostMapping("/subscriptions/plans")
public ResponseEntity<Void> createPlan(...) { ... }
```

### Step 6 — Audit Coverage

ADVISOR actions are already covered by HibernateAuditListener on Task, Invoice entities.
No extra audit config needed — every stage change and comment is logged with userId.

---

## Frontend Implementation

### Role Guard

File: `shared/lib/roles.ts` (or equivalent)

```typescript
export const ROLES = {
  ADMIN: 'ADMIN',
  ADVISOR: 'ADVISOR',
  EMPLOYEE: 'EMPLOYEE',
  CLIENT: 'CLIENT',
  CURATOR: 'CURATOR',
  LEARNER: 'LEARNER',
} as const;

export type Role = keyof typeof ROLES;

export const canManageSystem = (role: Role) => role === 'ADMIN';
export const canManagePeople = (role: Role) =>
  role === 'ADMIN' || role === 'ADVISOR';
export const canViewAllTasks = (role: Role) =>
  role === 'ADMIN' || role === 'ADVISOR' || role === 'EMPLOYEE';
```

### Dashboard Redirect

File: `pages/dashboard/DashboardRedirect.tsx`

```typescript
case 'ADVISOR':
  return <Navigate to="/dashboard/advisor/overview" />;
```

### Pages to Create

```
pages/dashboard/advisor/
  AdvisorOverviewPage.tsx     — task summary, employee workload, pending approvals
  AdvisorTasksPage.tsx        — full task list with reassign + stage controls
  AdvisorClientsPage.tsx      — client list, read-only profile + chat access
  AdvisorAuditPage.tsx        — audit log viewer (read-only)
```

### Hide Destructive Controls

In AdminOverviewPage and other admin-specific pages — gate with `canManageSystem(role)`:

```tsx
{canManageSystem(user.role) && (
  <Button onClick={handleDeleteUser}>Delete User</Button>
)}
```

---

## Migration Checklist

```
[BACKEND]
V109__Add_Advisor_Role.sql created
Role.java enum updated
CrmAccessService — all 8 methods updated with ADVISOR branch
@PreAuthorize('ADMIN') added to all destructive AdminController endpoints
JwtService — ADVISOR role included in token claims (already automatic)
Tests — CrmAccessServiceTest extended with ADVISOR scenarios

[FRONTEND]
roles.ts utility updated
DashboardRedirect updated
Advisor pages scaffold created
Destructive controls gated with canManageSystem()
React Query keys include ADVISOR context where needed

[FLYWAY]
V109 — only role assignment SQL, no schema change
V110+ reserved for future advisor-specific features
```

---

## Security Notes

[WARNING] ADVISOR sees all task data across all clients. If ADVISOR account is
compromised, attacker sees the full CRM. Mitigate: enforce 2FA for ADVISOR same
as ADMIN once 2FA is implemented.

[INFO] ADVISOR cannot trigger revokeAll, softDelete, or any RefreshToken
operations. These are locked to ADMIN via @PreAuthorize.

[INFO] ADVISOR actions appear in audit log with their userId — full traceability.
