# JF-1C — ZhanFinance: Мастер-отчёт

**Дата:** 29 июля 2026  
**Основа:** реальный код, git log (36+ коммитов), markdown-документация из архива  
**Метод:** анализ диффов, архитектурный review senior-уровня

---

## Стек

| Слой | Технологии |
|---|---|
| Backend | Spring Boot 3 · Java 17 · PostgreSQL · Flyway (V1–V108) |
| Frontend | React 19 · Vite · Tailwind v4 · FSD архитектура |
| Деплой | Fly.io · GitHub Actions CI/CD |
| Роли | ADMIN · EMPLOYEE · CLIENT · LEARNER · CURATOR |

---

## Готовность по направлениям

| Направление | Готовность | Комментарий |
|---|---|---|
| MVP для одной компании (single-tenant) | **90%** | Рабочий продакшн-инструмент с реальными данными |
| Архитектура кода | **78%** | 14 независимых модулей, FSD, 108 миграций |
| Безопасность (после сегодня) | **72%** | Rate limiting, CSP, path traversal — закрыты |
| DevOps / CI/CD (после сегодня) | **60%** | CI gate включён, мониторинг частичный |
| Тестовое покрытие (после сегодня) | **35%** | Unit-тесты на критические модули, нет integration |
| Multi-tenant SaaS | **8%** | Не начат, осознанно отложен |

---

## Ключевые метрики

| Метрика | Значение |
|---|---|
| Коммитов сегодня | 36+ |
| Backend классов | 223 |
| Frontend файлов | 191 |
| Flyway миграций | 108 |
| Тестовых классов (backend) | 11 |
| Тестовых файлов (frontend) | 7 |

---

## 5 блоков реализации — Walkthrough

### Блок 1 — Стабилизация памяти и кэширование

**Коммиты:** `26ee4d1`, `cf393db`, `894766c`

**Что сделано:**

- `ConcurrentHashMap` в `ApiRateLimitFilter` и `AuthRateLimitFilter` заменён на Caffeine Cache с `expireAfterAccess(30min)`, `maximumSize(10000)`. Без этого map рос бесконечно — на Fly.io с 512MB прямой путь к OOM kill.
- `CacheConfig` — Spring `CaffeineCacheManager` с `expireAfterWrite=60s`, `maximumSize=500` на все dashboard-кэши.
- PDF rendering вынесен из `@Transactional` в `DocumentGeneratorService`. Три чёткие фазы: `fetchGenerationData` (readOnly tx) → `renderDocx` (без tx) → `saveDocument` (tx). Hikari connection больше не держится на всё время CPU-bound рендеринга.
- HikariCP tuning, убраны медленные циклы в seeder — startup с 33s, приемлемо для health check.
- `VITE_USE_MOCK_SERVICES=false` — закрыт критический production bug: прод работал на моковых данных.
- `CF-Connecting-IP` приоритет над `X-Forwarded-For` — без этого за Cloudflare все запросы делили один IP и rate limit блокировал всех одновременно.

**Плюсы:**
- OOM risk устранён для rate-limit буферов
- Hikari connection pool не блокируется на PDF
- Production frontend переключён на реальный backend

**Минусы / технический долг:**
- Один глобальный Caffeine spec на все кэши — при разных TTL-требованиях нужен `registerCustomCache` per region
- 60s TTL означает задержку обновления dashboard после мутаций, если `@CacheEvict` не навешан на все мутации

---

### Блок 2 — CI/CD и защита деплоя

**Коммиты:** `26ee4d1`, `6626a55`, `ac80401`, `34978c4`

**Что сделано:**

- `-x test` убран из gradle команды. `./gradlew test bootJar` — сначала тесты, потом сборка. Деплой на Fly.io невозможен при красных тестах.
- `cache-dependency-path` для Gradle кэша — без этого каждый CI run скачивал зависимости заново (~2–3 минуты).
- Vitest добавлен во frontend pipeline — и бэк и фронт тесты блокируют деплой.

**Плюсы:**
- Quality Gate: защита продакшена от человеческого фактора
- Gradle кэш компенсирует добавленное время тестов
- Самое высокое соотношение impact/effort из всех блоков

**Минусы:**
- Увеличение времени CI/CD на ~1–2 минуты (компенсировано кэшем)
- Нет integration тестов в pipeline — только unit

---

### Блок 3 — API-контракты и финансовые инварианты

**Коммиты:** `81a18c1`, `cc548ee`, `8172c92`, `cf393db`

**Что сделано:**

- `validateStatusTransition` в `InvoiceService`: `PAID → *` и `CANCELED → *` выбрасывают `UnprocessableEntityException` (HTTP 422). Финансовый инвариант — без этого любой мог сбросить оплаченный счёт через прямой API вызов.
- `OVERDUE` статус добавлен в `Invoice.InvoiceStatus` enum. `InvoiceOverdueScheduler` — `@Scheduled(cron = "0 0 1 * * *")` помечает просроченные `ISSUED` счета.
- `FinanceSummaryDto` + `GET /api/admin/finance/summary` — выручка по статусам, totals.
- `ddl-auto=validate` в `cc548ee` — закрыт архитектурный конфликт Hibernate vs Flyway.
- `isPreFinal` в `StageDto` — логика прав CLIENT на перемещение задачи теперь на уровне данных, не hardcode.
- Swagger `@Tag` / `@Operation` на `TaskController`.
- React error 185 (`8172c92`) — infinite loop в useEffect из-за нестабильной ссылки в dependency array.

**Плюсы:**
- Финансовая целостность: нельзя откатить оплаченный счёт
- Автоматическая маркировка просроченных счетов
- ddl-auto конфликт закрыт

**Минусы / открытые вопросы:**
- `bb804a2` после `cc548ee` вернул `ddl-auto=update` в prod profile — **нужно проверить HEAD прямо сейчас**
- `InvoiceOverdueScheduler` использует `LocalDate.now()` без timezone — на Fly.io (UTC) задержка 5 часов для Алматы
- Scheduler загружает все Invoice в heap через JPA entities — нужен bulk `@Modifying` UPDATE
- `getFinanceSummaryByStatus` возвращает `List<Map<String, Object>>` — нестабильный контракт Hibernate, нужен projection interface
- `OVERDUE` в enum без проверки CHECK CONSTRAINT в БД

---

### Блок 4 — Тестовое покрытие (QA)

**Коммиты:** `bd51d27`, `90d4e22`, `10f31a3`, `4a9211b`, `d4522a9`, `093c5e5`, `81a18c1`

**Что сделано:**

**Backend:**
- `CrmAccessServiceTest` — новый кейс: нельзя вытащить задачу из WON/LOST в OPEN не-адмиом
- `InvoiceStatusTransitionTest` — `PAID → DRAFT` выбрасывает `UnprocessableEntityException`
- `RefreshTokenRotationTest` — создание токена, verify valid/expired/unknown, очистка старых токенов через `deleteAllByUserExceptId`
- `LocalStoragePathTraversalTest` — `../../../etc/passwd` в путях файлов. Реальная уязвимость была в `LocalStorageService` с локальным fallback
- `LessonProgressServiceTest` — sequential unlocking, 1-day rule, admin bypass, certificate issuance

**Frontend:**
- `TaskKanbanBoardRestrictions.test.tsx` — ограничения WON/LOST для EMPLOYEE/CLIENT

**Плюсы:**
- Security-critical кейсы покрыты: path traversal, access isolation, финансовые инварианты
- LMS бизнес-логика зафиксирована тестами
- `setId` в `BaseEntity`, `public` default constructor в `Task` — fixes для testability

**Минусы:**
- `TaskKanbanBoardRestrictions.test.tsx` тестирует локальные функции внутри тест-файла, а не реальный код компонента — если логика изменится, тест останется зелёным
- Нет integration тестов — все unit с моками. HTTP endpoint может вернуть 500 вместо 422 при реальном вызове
- Нет теста на token reuse detection (повторное использование украденного refresh token)
- `CANCELED → *` переход не покрыт тестом

---

### Блок 5 — Pre-enterprise инфраструктура

**Коммиты:** `597656f`, `031e88e`, `8db1259`, `3f8e562`, `c00acfe`

**Что сделано:**

- `pdfTaskExecutor` (`corePoolSize=4`, `maxPoolSize=16`, `queueCapacity=500`, `CallerRunsPolicy`) — тяжёлая генерация PDF изолирована от Tomcat thread pool
- Prometheus Actuator: `/actuator/prometheus`, `/actuator/health`, `/actuator/metrics`
- `031e88e` — Sequential lesson unlocking, 1-day-1-lesson rule, автовыдача сертификата. Единственная крупная бизнес-фича дня — LMS из "посмотрел видео" превратилась в полноценный learning flow
- `3f8e562` — пропуск регенерации DOCX шаблона на старте если файл уже есть — лишние секунды к startup убраны
- `c00acfe` — задокументировано решение по Cloudflare R2 + presigned URLs (статус: roadmap)
- Caddy + PgBouncer конфиги в `docker/` — заготовка для будущего VPS (не используются в текущем Fly.io проде)

**Плюсы:**
- `CallerRunsPolicy` даёт backpressure вместо RejectedExecutionException — при переполнении очереди запрос ждёт, не падает
- LMS learning flow полностью реализован
- Prometheus готов к подключению Grafana

**Минусы:**
- `management.endpoint.health.show-details=always` — детали о БД, диске, JVM heap публично без авторизации. **Нужно исправить на `when-authorized`**
- Caddy + PgBouncer не влияют на текущий прод (Fly.io имеет свой L7 proxy, PgBouncer нужен на VPS)
- `CallerRunsPolicy` при реальной нагрузке означает что Tomcat thread выполняет PDF — точка деградации

---

## Топ коммитов по production impact

| Хэш | Описание | Impact |
|---|---|---|
| `34978c4` | VITE_USE_MOCK_SERVICES=false | Критический: прод на моках → реальный бэкенд |
| `cf393db` | Rate limiting, CSP, PDF вне транзакции, overdue scheduler | Высокий: OOM защита + connection pool |
| `031e88e` | Sequential LMS unlocking + certificate issuance | Высокий: полноценный LMS flow |
| `07a3a9b` | Unproxy User entities — LazyInitializationException | Средний: 500 на генерации документов устранён |
| `cc548ee` | Flyway V108 FK fix + ddl-auto=validate | Средний: архитектурный конфликт закрыт |
| `90d4e22` | LocalStoragePathTraversalTest | Средний: path traversal зафиксирован контрактом |
| `bfb0235` | Kanban drag-and-drop stage persistence | Средний: основная рабочая поверхность EMPLOYEE |

---

## Открытые технические риски

### P0 — требуют действия до отчёта

**ddl-auto конфликт**  
`bb804a2` после `cc548ee` вернул `ddl-auto=update` в prod profile. Нужно проверить HEAD:
```bash
grep "ddl-auto" zhan-finance-backend/src/main/resources/application-prod.properties
```
Должно быть `validate` или `none`.

**health.show-details=always**  
Системная информация о БД, JVM heap, диске публично без авторизации. Исправить:
```properties
management.endpoint.health.show-details=when-authorized
```

### P1 — исправить в течение недели

**Self-invocation @Transactional**  
`fetchGenerationData` вызывается из `generateFromTemplate` того же бина. Spring AOP proxy не перехватывает self-invocation — `@Transactional(readOnly = true)` не сработает. Практический impact: нет readOnly оптимизации, чуть больше overhead. Решение: вынести в отдельный `@Service`.

**InvoiceOverdueScheduler timezone**  
`LocalDate.now()` без timezone. На Fly.io (UTC) задержка ~5 часов для Алматы. Исправить:
```java
LocalDate today = LocalDate.now(ZoneId.of("Asia/Almaty"));
```
Плюс bulk UPDATE вместо загрузки всех Invoice в память:
```java
@Modifying
@Query("UPDATE Invoice i SET i.status = 'OVERDUE' WHERE i.status = 'ISSUED' AND i.dueDate < :today")
int markOverdue(@Param("today") LocalDate today);
```

**FinanceSummary projection**  
`List<Map<String, Object>>` из JPQL — нестабильный контракт. Hibernate может вернуть позиционные ключи вместо именованных. Заменить на projection interface:
```java
public interface InvoiceStatusSummary {
    String getStatus();
    Long getCount();
    BigDecimal getTotalAmount();
}
```

**Token reuse detection**  
При краже refresh token система не инвалидирует всю цепочку при повторном использовании. Добавить `is_used BOOLEAN`, при reuse — инвалидировать все токены пользователя.

**Kanban restrictions тест**  
`TaskKanbanBoardRestrictions.test.tsx` тестирует локальные копии логики, не реальный код компонента. Вынести функции ограничений в утилиту, тестировать её.

### P2 — технический долг

**CSP unsafe-inline**  
`script-src 'self' 'unsafe-inline'` обнуляет XSS защиту. CSP с `unsafe-inline` в script-src — для галочки. Для React/Vite решается через `nonce` или `hash`.

**429 без Retry-After заголовка**  
Frontend хардкодит "подождите минуту". `ApiRateLimitFilter` не выставляет `Retry-After` заголовок. Добавить в фильтр + читать на фронте.

---

## Состояние emergency phases

| Фаза | Статус | Что было |
|---|---|---|
| Phase 1: Диагностика | ✅ Закрыта | 500 на логине, файлы, АВР, курсы — все диагностированы |
| Phase 2: Backend fixes | ✅ Закрыта | is_published, сортировка уроков, FK, curators |
| Phase 3: Файлы и документы | ✅ Закрыта | DatabaseStorageService, path traversal, аватарки |
| Phase 4: Коммит и деплой | ✅ Закрыта | JWT_SECRET, SPRING_PROFILES_ACTIVE=prod |
| Phase 5: Верификация | ✅ Закрыта | Приложение поднялось, DatabaseMigrationRunner прошёл |

---

## Roadmap — что дальше

### Сейчас (до отчёта)
- Проверить `ddl-auto` в HEAD production properties
- Исправить `health.show-details=when-authorized`
- Подтвердить создание задачи от CLIENT на живом проде

### После отчёта (~1 неделя)
- `InvoiceOverdueScheduler` — timezone + bulk UPDATE
- `FinanceSummary` projection interface
- Refresh token reuse detection
- `Retry-After` header в `ApiRateLimitFilter`

### Перед доменом (1–2 недели)
- SLA `@Scheduled` джоба — красная рамка на канбан-карточке
- Employee overload цветовые метки на `AdminOverviewPage`
- Invoice SENT кнопка → email с PDF
- Финансовый дашборд (данные уже есть, нужен UI)

### После физического сервера (3–4 недели)
- LMS квизы — таблицы `quizzes/questions/answers`, подсчёт на сервере
- Настоящие PDF сертификаты с номером и публичной верификацией
- Cloudflare R2 + presigned URLs для медиафайлов курсов
- Caddy + PgBouncer на физическом сервере

### Осознанно не в работе
Multi-tenancy, Teams, SUPERVISOR, 1С-интеграция, Kaspi Pay, Redis, White-label, SaaS onboarding wizard.

---

## Вывод

База проекта — одна из лучших частей: модульный монолит, 108 Flyway миграций, FSD архитектура, ролевая модель с row-level security. Сегодняшний день закрыл критические production баги (моковые данные, OOM risk, connection pool), ввёл CI/CD quality gate, добавил финансовые инварианты и полноценный LMS flow.

Главные открытые риски: `ddl-auto` конфликт в prod profile и публичный `health` endpoint без авторизации — оба исправляются за 5 минут. Остальное — технический долг, не блокеры.

---

*Сгенерировано на основе: git log 36 коммитов, `git show cf393db`, `git show HEAD -4`, markdown-документации из for_review.zip*
