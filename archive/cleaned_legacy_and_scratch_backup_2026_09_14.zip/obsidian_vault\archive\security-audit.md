# JF-1C — Security Audit

> Основано на анализе кодовой базы (июль 2026).  
> Приоритеты: P0 = блокирует запуск, P1 = исправить до первого внешнего клиента, P2 = в течение квартала.

---

## Что уже сделано правильно

Перед аудитом — честное признание того, что хорошо:

- JWT stateless аутентификация — правильный выбор для SaaS
- BCrypt для хешей паролей — ок
- `@PreAuthorize` на всех защищённых эндпоинтах
- `CrmAccessService` / `InvoiceAccessService` — проверка прав на уровне данных
- Rate limiting на auth-эндпоинтах (`AuthRateLimitFilter`)
- `GlobalExceptionHandler` — не выдаёт стек-трейсы клиенту
- Audit log через `HibernateAuditListener`
- Swagger доступен только для ADMIN
- Refresh-токены в БД, не в cookies

---

## P0 — Блокируют безопасный запуск

### P0-1: JWT в query-параметре для WebSocket

**Файл:** `JwtAuthenticationFilter.java`

```java
// Текущий код — токен читается из URL-параметра
} else if (request.getRequestURI().startsWith("/ws/") || ...) {
    token = request.getParameter("token");  // ← УЯЗВИМОСТЬ
}
```

**Проблема:** URL с токеном логируется в:
- Nginx / reverse proxy access logs
- Fly.io logs
- История браузера
- Реферер при переходе на другой сайт

Один скриншот или скопированная ссылка = утечка токена.

**Решение:** передавать JWT через первое сообщение после WebSocket-рукопожатия, а не в URL.

```javascript
// Frontend: после ws.onopen
ws.onopen = () => {
  ws.send(JSON.stringify({ type: 'AUTH', token: getAccessToken() }));
};
```

```java
// Backend: в WebSocket handler
@Override
public void afterConnectionEstablished(WebSocketSession session) {
    // ждём AUTH-сообщение, валидируем, сохраняем в атрибутах сессии
}
```

Или использовать STOMP с заголовком `Authorization` при CONNECT.

---

### P0-2: Нет multi-tenancy — данные не изолированы между организациями

**Проблема:** при подключении второго клиента они увидят данные первого.  
**Решение:** см. `multi-tenancy-plan.md` — это отдельный документ.  
**Здесь:** отметить как P0-security, а не только архитектурная задача.

---

### P0-3: `ddl-auto=update` в production

**Файл:** `application.properties`

Hibernate в режиме `update` может изменить схему БД при деплое с изменённой entity.  
Это может привести к потере данных (удаление колонки, изменение типа).

```properties
# Изменить немедленно
spring.jpa.hibernate.ddl-auto=validate
```

Flyway управляет схемой. Hibernate только валидирует соответствие.

---

## P1 — До первого внешнего клиента

### P1-1: Refresh token rotation — не инвалидируется старый токен

**Файл:** `RefreshTokenService.java`

Текущая логика: `create()` создаёт новый токен и удаляет старые (`deleteAllByUserExceptId`).  
Проблема: между `save(newToken)` и `deleteAllByUserExceptId()` — окно гонки.  
Если атакующий успел украсть refresh-токен и использовал его — оба токена (его и легитимный) будут валидны до следующего refresh.

**Нужно:** при использовании refresh-токена — немедленно инвалидировать именно его.

```java
// Добавить поле в RefreshToken
@Column(nullable = false)
private boolean used = false;
```

```java
// В RefreshTokenService.verify():
@Transactional
public RefreshToken verify(String token) {
    RefreshToken rt = refreshTokenRepository.findByToken(token)
        .orElseThrow(() -> new UnauthorizedException("Invalid refresh token"));

    if (rt.isUsed()) {
        // Потенциальная кража токена — инвалидируем ВСЕ токены пользователя
        refreshTokenRepository.deleteAllByUser(rt.getUser());
        throw new UnauthorizedException("Refresh token already used — possible theft detected");
    }

    if (rt.getExpiresAt().isBefore(Instant.now())) {
        throw new UnauthorizedException("Refresh token expired");
    }

    rt.setUsed(true);
    refreshTokenRepository.save(rt);
    return rt;
}
```

---

### P1-2: Rate limiting только на auth — не на остальных эндпоинтах

**Файл:** `SecurityConfig.java`, `AuthRateLimitFilter.java`

Текущий `AuthRateLimitFilter` применяется только к `/api/auth/**`.  
Любой другой эндпоинт можно спамить без ограничений.

**Решение:** добавить глобальный rate limit через Bucket4j.

```java
// GlobalRateLimitFilter.java
@Component
public class GlobalRateLimitFilter extends OncePerRequestFilter {
    // 100 запросов в минуту на IP
    private final Map<String, Bucket> buckets = new ConcurrentHashMap<>();

    @Override
    protected void doFilterInternal(...) {
        String ip = request.getRemoteAddr();
        Bucket bucket = buckets.computeIfAbsent(ip, k ->
            Bucket.builder()
                .addLimit(Bandwidth.classic(100, Refill.greedy(100, Duration.ofMinutes(1))))
                .build()
        );

        if (!bucket.tryConsume(1)) {
            response.setStatus(429);
            // write ErrorResponse
            return;
        }
        filterChain.doFilter(request, response);
    }
}
```

---

### P1-3: Отсутствие security headers

**Файл:** `WebMvcConfig.java`

```java
// Добавить в WebMvcConfigurer:
@Bean
public FilterRegistrationBean<OncePerRequestFilter> securityHeadersFilter() {
    return new FilterRegistrationBean<>(new OncePerRequestFilter() {
        @Override
        protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
                throws ServletException, IOException {
            res.setHeader("X-Content-Type-Options", "nosniff");
            res.setHeader("X-Frame-Options", "DENY");
            res.setHeader("X-XSS-Protection", "1; mode=block");
            res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
            res.setHeader("Content-Security-Policy",
                "default-src 'self'; " +
                "script-src 'self' 'unsafe-inline'; " +  // Tailwind inline styles
                "style-src 'self' 'unsafe-inline'; " +
                "img-src 'self' data: blob:; " +
                "connect-src 'self' wss:;");
            chain.doFilter(req, res);
        }
    });
}
```

---

### P1-4: Загрузка файлов без проверки типа на сервере

**Файл:** `DocumentController.java` (предположительно)

Сейчас проверка файла только по размеру (500MB — избыточно). Нет проверки MIME-типа.  
Атакующий может загрузить `.html` файл с JS-кодом или исполняемый файл.

```java
// DocumentService.validateFile()
private static final Set<String> ALLOWED_TYPES = Set.of(
    "application/pdf",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.ms-excel",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "image/jpeg", "image/png",
    "text/plain"
);

private static final long MAX_FILE_SIZE = 20 * 1024 * 1024; // 20MB

public void validateFile(MultipartFile file) {
    if (file.getSize() > MAX_FILE_SIZE) {
        throw new BadRequestException("Файл слишком большой. Максимум 20MB.");
    }
    // Проверять не Content-Type из запроса (он подделывается), а magic bytes файла
    String detectedType = detectMimeType(file);
    if (!ALLOWED_TYPES.contains(detectedType)) {
        throw new BadRequestException("Недопустимый тип файла: " + detectedType);
    }
}
```

---

### P1-5: CORS слишком широкий

**Файл:** `CorsConfig.java`

Проверить: не стоит ли `allowedOrigins("*")`. Для production должен быть конкретный origin:

```java
configuration.setAllowedOrigins(List.of(
    "https://zhanfinance.kz",
    "https://www.zhanfinance.kz"
));
// НЕ "*" в production
```

---

## P2 — В течение квартала

### P2-1: Пароль без требований сложности

Нет проверки силы пароля при регистрации. Добавить:
- Минимум 8 символов
- Хотя бы одна цифра или спецсимвол

```java
// RegisterRequest
@Pattern(
    regexp = "^(?=.*[0-9A-Za-z!@#$%^&*]).{8,}$",
    message = "Пароль должен быть не менее 8 символов"
)
private String password;
```

### P2-2: Нет механизма сброса пароля

Сейчас `UserController` имеет `PATCH /api/users/me` для смены пароля — только авторизованным.  
Нет `POST /api/auth/forgot-password` для незалогиненных.

```
POST /api/auth/forgot-password  { "email": "..." }
→ Создать PasswordResetToken (expires in 1h)
→ Отправить email со ссылкой /reset-password?token=...

POST /api/auth/reset-password  { "token": "...", "newPassword": "..." }
→ Проверить токен, сменить пароль, инвалидировать все refresh-токены
```

### P2-3: Audit log не покрывает billing

`HibernateAuditListener` уже есть. Убедиться что `Invoice` и `Subscription` под аудитом (`@EntityListeners`).  
Финансовые операции должны логироваться: кто создал счёт, кто изменил статус, кто удалил.

---

## Итого: приоритетный список

| # | Уязвимость | Приоритет | Сложность |
|---|-----------|-----------|-----------|
| 1 | `ddl-auto=validate` | P0 | 5 мин |
| 2 | Multi-tenancy (изоляция данных) | P0 | 1–2 недели |
| 3 | JWT в WebSocket URL → в заголовок | P0 | 1 день |
| 4 | Refresh token rotation | P1 | 2–3 часа |
| 5 | Global rate limiting | P1 | 2–3 часа |
| 6 | Security headers | P1 | 1–2 часа |
| 7 | Валидация типа файлов | P1 | 2–3 часа |
| 8 | CORS проверить и сузить | P1 | 30 мин |
| 9 | Требования к паролю | P2 | 1 час |
| 10 | Forgot password flow | P2 | 1 день |
| 11 | Audit log для billing | P2 | 1–2 часа |
