# Фаза 1 — Диагностика (БЕЗ изменений кода)

## Правило этой фазы
**Ты НЕ меняешь ни один файл. Ты НЕ делаешь git commit. Ты НЕ делаешь git push.**
Твоя задача — только собрать информацию и выдать отчёт.

## Контекст проекта
- Backend: Spring Boot 4.1 + Java 17 + PostgreSQL + Flyway
- Frontend: React 19 + Vite + TypeScript + FSD архитектура
- Деплой: Fly.io (app: `zhanfinance`, db: `zhanfinance-db`)
- CI/CD: GitHub Actions → автодеплой при пуше в `main`

## Известные баги (из логов и ручного тестирования)

### КРИТИЧЕСКИЕ (блокируют работу):
1. **500 на логине** — `POST /api/auth/login` возвращает 500
2. **Задачи не создаются** — `POST /api/crm/tasks` возвращает 500
3. **Файлы не загружаются** — документы есть в БД, но скачать нельзя
4. **АВР не генерируются** — `POST /api/crm/tasks/{id}/documents/generate` → 404
5. **Создание курса** → "Ошибка при сохранении курса"
6. **Создание урока** → "Ошибка при создании урока"
7. **Назначение куратора на курс** → 500 (`/api/admin/curators/{id}/courses/{id}`)

### НЕКРИТИЧЕСКИЕ:
8. **Сортировка модулей/уроков** — сортируется неправильно, нужно по `created_at ASC`
9. **Аватарки не работают**
10. **WebSocket** — `closed before connection is established`
11. **Swagger открыт в проде** — профиль `prod` не активирован

## Что нужно сделать в этой фазе

### Шаг 1 — Собери логи
```bash
fly logs -a zhanfinance 2>&1 | grep -E "ERROR|Exception|WARN|500" | tail -50
```

### Шаг 2 — Проверь secrets
```bash
fly secrets list -a zhanfinance
```

### Шаг 3 — Проверь файловое хранилище
Найди в коде как хранятся файлы:
- Ищи `FileStorageService` или аналог
- Проверь используется ли локальная папка (`uploads/`) или БД/S3
- Если локальная папка — это причина бага (Fly.io ephemeral disk)

### Шаг 4 — Проверь роутинг
```bash
grep -r "documents/generate" src/main/java --include="*.java" -l
grep -r "curators" src/main/java --include="*.java" -l | grep -i controller
```

### Шаг 5 — Проверь сортировку
```bash
grep -r "findByChapter\|findAllByChapter\|orderBy\|ORDER BY" src/main/java --include="*.java" | grep -i "lesson\|chapter"
```

## Формат отчёта (выдай в конце)

```
## ДИАГНОСТИКА JF-1C

### БАГ 1: [название]
- Файл: [путь]
- Причина: [объяснение]
- Нужное изменение: [что именно менять]

### БАГ 2: ...
```

**Стоп после отчёта. Ждёшь подтверждения перед Фазой 2.**
