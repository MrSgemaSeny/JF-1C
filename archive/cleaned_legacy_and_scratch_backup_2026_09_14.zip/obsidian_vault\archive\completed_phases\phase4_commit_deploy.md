# Фаза 4 — Коммит и деплой

## Правило этой фазы
Эта фаза выполняется ТОЛЬКО после того как я написал "ОК, пушим" по итогам Фаз 2 и 3.

## Чеклист перед коммитом

Выполни каждый пункт и покажи вывод:

### 1. Проверь что не сломал лишнего
```bash
git diff --stat
```
Покажи мне список изменённых файлов. Если там есть файлы которые мы НЕ обсуждали — 
объясни почему они изменились. Если не можешь объяснить — верни их:
```bash
git restore [файл]
```

### 2. Проверь кодировку Java файлов
```bash
file src/main/java/com/example/zhanfinancebackend/modules/courses/config/DatabaseMigrationRunner.java
```
Должно быть UTF-8. Если другое — пересохрани в UTF-8.

### 3. Убедись что gradlew исполняемый
```bash
ls -la gradlew
```
Должен быть `-rwxr-xr-x`. Если нет:
```bash
git update-index --chmod=+x gradlew
```

### 4. Коммит
```bash
git add [только файлы которые мы обсудили]
git commit -m "fix: [описание что именно починили]"
```

**Формат commit message:**
```
fix(backend): add is_published to course seed, fix lesson sort order
fix(docs): restore document generation endpoint  
fix(storage): fix file download from database storage
```

### 5. Пуш
```bash
git push origin main
```

### 6. Следи за деплоем
```bash
# В отдельном терминале:
fly logs -a zhanfinance
```

Жди строку:
```
Started ZhanFinanceBackendApplication in XX seconds
```

Если видишь `ERROR` или `OOM` — немедленно скажи мне, НЕ пытайся чинить сам.

### 7. Проверь после деплоя
```bash
curl https://zhanfinance.fly.dev/api/auth/login \
  -X POST \
  -H "Content-Type: application/json" \
  -d '{"email":"mrsgemaseny@gmail.com","password":"твой_пароль"}'
```

Если 200 — всё хорошо. Если 500 — покажи мне `fly logs`.

## Что НЕ делать в этой фазе

- НЕ менять Dockerfile
- НЕ менять fly.toml  
- НЕ трогать workflow файлы
- НЕ добавлять новые зависимости в build.gradle
- НЕ делать force push

Если возникает желание сделать что-то из этого списка — стоп, спроси меня.
