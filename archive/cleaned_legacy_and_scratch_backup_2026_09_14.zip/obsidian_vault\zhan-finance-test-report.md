# Zhan Finance — отчёт по тестированию (ручная трассировка кода)

## Как проводилось тестирование

Полноценно собрать и запустить проект не удалось: в присланных архивах есть только `src/`
(нет `pom.xml`, `application.yml`, `package.json`, `node_modules`) — то есть ни backend, ни
frontend физически нечем собрать, а сети для докачки зависимостей у меня тоже нет.

Поэтому вместо `mvn test` / `npm run dev` я прогнал систему "руками по коду" — взял ключевые
пользовательские сценарии и построчно проследил путь `Controller → Service → Repository`
(и то же самое на фронте: компонент → API-вызов → рендер), как будто это ручное тестирование.
Для каждого сценария ниже: **Дано → Действие → Ожидание → Что реально происходит → Вердикт**.

Часть проблем совпадает с уже присланным списком фиксов — они здесь только упомянуты (со
ссылкой), чтобы не дублировать код. Всё новое — расписано подробно, включая 2 критичные дыры в
безопасности.

---

## 🔴 Критично — новые находки

### Т1. Любой сотрудник может переназначить/забрать ЧУЖУЮ задачу

**Дано:** сотрудник А не имеет отношения к задаче №42 (она назначена сотруднику Б, клиент не его).
**Действие:** `PATCH /api/tasks/42/assign?assigneeId=<A>` от имени сотрудника А.
**Ожидание:** 403 — задача не его, брать её мимо пула нельзя.
**Реально:** запрос проходит успешно. Задача переназначается на А.

**Причина:**
```java
// TaskController.java
@PatchMapping("/{id}/assign")
@PreAuthorize("hasAnyRole('ADMIN', 'EMPLOYEE')")
public ApiResponse<TaskDto> assignTask(... @RequestParam(required = false) Long assigneeId) {
    accessService.assertCanAssignTask(principal.getUser());   // ← проверяет только РОЛЬ вызывающего
    return ApiResponse.success(taskService.assignTask(id, assigneeId, principal.getUser()));
}

// CrmAccessService.java
public boolean canAssignTask(User actor) {
    return actor.getRole() == Role.ADMIN || actor.getRole() == Role.EMPLOYEE;   // ← и всё, без привязки к задаче
}
```
Нет проверки, что вызывающий сотрудник как-то связан с задачей/клиентом. Любой сотрудник может:
- забрать чужую задачу себе (`assigneeId=<себя>`),
- отдать чужую задачу третьему сотруднику,
- снять назначение вообще (`assigneeId` не передан → `null`), выкинув задачу в общий пул.

**Исправление:**
```java
// CrmAccessService.java
public boolean canAssignTask(User actor, Task task) {
    if (actor.getRole() == Role.ADMIN) return true;
    if (actor.getRole() != Role.EMPLOYEE) return false;
    // сотрудник может брать задачу из пула (она ничья) или управлять задачей своего клиента /
    // задачей, которая уже назначена ему самому
    return task.getAssignedTo() == null
            || assignedToEmployee(actor, task.getClient())
            || sameUser(actor, task.getAssignedTo());
}

public void assertCanAssignTask(User actor, Task task) {
    if (!canAssignTask(actor, task)) {
        throw new org.springframework.security.access.AccessDeniedException("Assigning task denied");
    }
}
```
```java
// TaskController.java
@PatchMapping("/{id}/assign")
@PreAuthorize("hasAnyRole('ADMIN', 'EMPLOYEE')")
public ApiResponse<TaskDto> assignTask(..., @PathVariable Long id, @RequestParam(required = false) Long assigneeId) {
    Task task = taskService.getTaskEntity(id); // сделать метод package/public по необходимости
    accessService.assertCanAssignTask(principal.getUser(), task);
    return ApiResponse.success(taskService.assignTask(id, assigneeId, principal.getUser()));
}
```

---

### Т2. `/uploads/{storageKey}` отдаёт любой файл без проверки владельца — обход прав доступа к документам

**Дано:** клиент А видит в своём кабинете ссылку на документ вида `.../uploads/docs/2026/07/ab12cd34.pdf`.
**Действие:** клиент Б (или вообще любой авторизованный пользователь) подставляет/подсматривает
чужой `storageKey` и открывает `GET /uploads/<чужой-storageKey>`.
**Ожидание:** 403 — доступ к чужому документу должен проверяться, как в `DocumentController.downloadDocument(id)`,
где реально вызывается `documentAccessService`.
**Реально:** файл отдаётся. Единственная проверка — `@PreAuthorize("isAuthenticated()")`, то есть
"залогинен хоть кто-нибудь".

```java
// FileDownloadController.java
@GetMapping("/uploads/{storageKey:.+}")
@PreAuthorize("isAuthenticated()")                 // ← нет проверки владения файлом
public ResponseEntity<Resource> downloadFile(@PathVariable String storageKey) {
    Resource resource = storageService.loadAsResource(storageKey);
    ...
    return ResponseEntity.ok()...body(resource);
}
```
Получается два входа к одному и тому же файлу: "парадный" `/api/documents/{id}/download` — с
проверкой прав через `DocumentAccessService`, и "чёрный ход" `/uploads/{storageKey}` — вообще без
неё. Достаточно один раз узнать/угадать `storageKey` (он попадает в HTML как src/href у любого
документа, который пользователь легально видит), чтобы обратиться к нему напрямую в обход
проверки прав на конкретный документ.

**Исправление** — самый надёжный вариант: убрать прямую раздачу файлов по `storageKey` и отдавать
их **только** через `/api/documents/{id}/download`, который уже умеет проверять права:

```java
// DocumentController.java — эндпоинт уже есть и уже с проверкой доступа, см. присланный ранее файл
@GetMapping("/{id}/download")
public ResponseEntity<Resource> downloadDocument(@PathVariable Long id, @AuthenticationPrincipal UserPrincipal principal) {
    // тут уже вызывается documentAccessService — этот путь ок, использовать только его
}
```
```java
// FileDownloadController.java — если /uploads/** нужен по другой причине (например, публичные
// ассеты типа лендинга), явно ограничить его тем, что не является приватными документами клиента:
@GetMapping("/uploads/avatars/{storageKey:.+}")
@PreAuthorize("isAuthenticated()")  // аватарки — норм, не приватные документы
public ResponseEntity<Resource> downloadAvatar(...) { ... }

// а общий /uploads/{storageKey} для документов — удалить или как минимум прогонять через
// documentRepository.findByStorageKey(storageKey) + documentAccessService.assertCanRead(...)
// перед отдачей файла.
```
На фронте — заменить все места, где ссылка на документ строится как прямой `/uploads/...` URL, на
вызов защищённого `/api/documents/{id}/download`.

---

### Т3. У `LEARNER` полностью не работает проверка доступа к чату — может писать кому угодно

**Дано:** пользователь с ролью `LEARNER` (ученик курсов) открывает чат.
**Действие:** `GET /api/chat/{otherUserId}` или `POST /api/chat/{otherUserId}` с ID случайного
клиента/сотрудника, к которому LEARNER не должен иметь отношения.
**Ожидание:** 403 — как у клиента, LEARNER должен видеть только своего куратора/админов.
**Реально:** запрос проходит без ошибки — LEARNER может переписываться с кем угодно.

**Причина:**
```java
// ChatService.validateAccess()
if (currentUser.getRole() == Role.ADMIN) { return; }
if (currentUser.getRole() == Role.CLIENT) { ... }
else if (currentUser.getRole() == Role.EMPLOYEE) { ... }
// нет ветки для Role.LEARNER → метод просто доходит до конца без throw → доступ разрешён по умолчанию
```
Контроллер объявляет `LEARNER` как разрешённую роль
(`@PreAuthorize("hasAnyRole('ADMIN','EMPLOYEE','CLIENT','LEARNER')")`), но сервис про эту роль
"не знает" — в Java метод без `throw` в конце просто завершается успешно. Это классическая
"забытая ветка" в цепочке `if/else if` без `else { deny }`.

Похожая проблема и в `getContacts()`: для `LEARNER` код попадает в ветку `else`, написанную для
клиента (`currentUser.getAssignedEmployee()` + все админы) — для LEARNER это поле, скорее всего,
всегда `null` (у него нет "закреплённого сотрудника" в CRM-смысле), так что практической пользы
контактов нет, но сама переписка (`sendMessage`/`getHistory`) при этом не ограничена вообще.

**Исправление** — сделать проверку **allow-list**, а не набор `if` без финального `deny`:

```java
private void validateAccess(Long currentUserId, Long otherUserId) {
    User currentUser = ...;
    User otherUser = ...;

    if (currentUser.getRole() == Role.ADMIN) return;

    if (currentUser.getRole() == Role.CLIENT || currentUser.getRole() == Role.LEARNER) {
        if (otherUser.getRole() == Role.ADMIN) return;
        if (currentUser.getAssignedEmployee() != null
                && currentUser.getAssignedEmployee().getId().equals(otherUserId)) {
            return;
        }
        throw new AccessDeniedException("Access denied");
    }

    if (currentUser.getRole() == Role.EMPLOYEE) {
        if (otherUser.getRole() == Role.ADMIN || otherUser.getRole() == Role.EMPLOYEE) return;
        if (otherUser.getRole() == Role.CLIENT
                && otherUser.getAssignedEmployee() != null
                && otherUser.getAssignedEmployee().getId().equals(currentUserId)) {
            return;
        }
        throw new AccessDeniedException("Access denied");
    }

    // любая роль, которую забыли явно обработать выше — запрет по умолчанию
    throw new AccessDeniedException("Access denied");
}
```
Общий урок для ревью остального кода: искать все `if/else if` цепочки по `Role`, которые не
заканчиваются явным `else { deny }` — то же самое стоит перепроверить в `getContacts()` и вообще
везде, где `Role` разбирается через `if` вместо `switch` с обязательным `default`.

---

## 🟠 Важно — логические баги

### Т4. Задача, созданная САМИМ клиентом, не назначается на его закреплённого сотрудника

**Дано:** у клиента уже есть закреплённый сотрудник (`client.assignedEmployee` установлен).
**Действие:** клиент через личный кабинет создаёт задачу (`requestTask`, кнопка "запросить услугу").
**Ожидание:** задача сразу видна в "Списке задач" у закреплённого сотрудника — так же, как если бы
задачу создал сам сотрудник (`createTask`).
**Реально:** сотруднику приходит уведомление "Новая задача от клиента", но сама задача остаётся
**не назначенной** (`assignedTo = null`) — то есть висит в общем "Пуле задач" для всех, а не у
конкретного сотрудника, хотя уведомление создаёт впечатление, что она уже "его".

**Причина — сравнение двух методов в `TaskService.java`:**
```java
// createTask() — когда задачу создаёт сотрудник/админ
} else if (client.getAssignedEmployee() != null) {
    task.setAssignedTo(client.getAssignedEmployee());     // ← назначает автоматически
}
```
```java
// requestTask() — когда задачу создаёт сам клиент
// ...такого блока нет вообще, assignedTo остаётся null...
User employee = managedClient.getAssignedEmployee();
if (employee != null) {
    notificationService.createNotification(employee, "Новая задача от клиента", ..., "/dashboard/tasks");
    emailNotificationService.sendTaskAssignedEmail(employee, savedTask); // шлём "вам назначена задача", хотя не назначили
}
```
Письмо и уведомление буквально называются "вам назначена задача" (`sendTaskAssignedEmail`), но
по факту назначения не происходит — рассинхрон текста и реального состояния. Это отдельный, но
однотипный с уже найденным (пул vs список) источник путаницы: сотрудник получает письмо "вам
назначена задача", идёт искать её в "Списке задач" — а она там не появляется, потому что реально
лежит в пуле.

**Исправление:**
```java
// TaskService.requestTask()
task.setStage(defaultStage);

if (managedClient.getAssignedEmployee() != null) {
    task.setAssignedTo(managedClient.getAssignedEmployee());   // + добавить, как в createTask()
}
```

---

### Т5. Уведомление "Сотрудник запросил у вас документ" шлётся при создании ЛЮБОЙ задачи, а не только запроса документов

**Дано:** сотрудник создаёт клиенту обычную задачу (например, "Подготовить отчёт"), без всякого
запроса документов от клиента.
**Действие:** `POST /api/tasks` от сотрудника.
**Ожидание:** клиент получает нейтральное "вам создана новая задача", если это не про документы —
без слов "запросил у вас документ".
**Реально:** клиент **всегда** получает уведомление с заголовком "Новый запрос документов" и
текстом "Сотрудник запросил у вас документ по задаче: …", даже если задача вообще не про это.

**Причина:**
```java
// TaskService.createTask()
if (creator.getRole() != Role.CLIENT && client.getId().equals(savedTask.getClient().getId())) {
    notificationService.createNotification(client, "Новый запрос документов",
            "Сотрудник запросил у вас документ по задаче: " + savedTask.getTitle(), "/dashboard/client");
}
```
Второе условие (`client.getId().equals(savedTask.getClient().getId())`) сравнивает клиента самого
с собой — `savedTask` создан двумя строками выше как `new Task(title, client, creator)`, так что
`savedTask.getClient()` — это буквально тот же объект `client`. Условие математически всегда
истинно, то есть реально всё сводится к "если создатель — не клиент", и блок срабатывает на
**каждое** создание задачи сотрудником/админом, независимо от её сути.

**Исправление** — либо убрать этот блок вовсе (дублирует общее уведомление "Статус задачи
изменен" / создание задачи), либо привязать его к реальному признаку "это запрос документов",
если такой есть в модели (например, отдельный тип задачи или флаг):
```java
if (creator.getRole() != Role.CLIENT) {
    notificationService.createNotification(client, "Новая задача",
            "Вам создана новая задача: " + savedTask.getTitle(), "/dashboard/client");
}
// а "Новый запрос документов" слать отдельно, только когда это реально запрос документов —
// например, если у задачи есть services/subtasks с типом "предоставить документ"
```

---

### Т6. Сравнение сущностей по ссылке в `assignTask` (уже было в предыдущем файле)
См. отчёт `zhan-finance-fixes.md`, пункт 11.1 — `task.getAssignedTo() != assignee` вместо
сравнения по ID.

### Т7. Пул задач и список задач не совпадают (уже было)
См. `zhan-finance-fixes.md`, пункт 7 — двойное условие в `findAllByEmployeeWithDetails` против
`assignedTo IS NULL` в пуле. С учётом Т4 выше эффект ещё заметнее: задачи от `requestTask` вообще
никогда не попадают "персонально" сотруднику, только в общий пул, независимо от закрепления.

### Т8. Ссылка в уведомлении о новом документе не сохраняется (уже было)
См. `zhan-finance-fixes.md`, пункт 3.

### Т9. Регистрация без уведомления админу / без приветственного письма (уже было)
См. `zhan-finance-fixes.md`, пункты 1–2.

### Т10. `DatePicker`: `required` на `type="hidden"` не валидируется браузером (уже было)
См. `zhan-finance-fixes.md`, пункт 11.3.

### Т11. Слабая проверка типа файла при загрузке документов (уже было)
См. `zhan-finance-fixes.md`, пункт 11.2. Дополняется находкой Т2 — раз файлы можно скачать в обход
`DocumentController`, слабая проверка на входе (allow "любой .html под левым content-type") даёт
ещё один канал разместить произвольный контент, который потом отдаётся по прямой ссылке.

---

## 🟡 Небольшие несоответствия

### Т12. Одобрение сотрудника админом не отправляет уведомление/письмо сотруднику

**Дано:** новый сотрудник зарегистрировался, ждёт (`enabled = false`).
**Действие:** админ жмёт "Одобрить" (`POST /api/admin/employees/{id}/approve`).
**Реально:**
```java
// AdminService.approveEmployee()
user.setEnabled(true);
userRepository.save(user);
// ...и всё — ни email, ни in-app уведомления сотруднику не уходит
```
Сотрудник узнаёт, что его одобрили, только когда сам зайдёт и попробует залогиниться повторно.
**Исправление:** добавить `emailNotificationService.sendAccountApprovedEmail(user)` /
`notificationService.createNotification(user, "Аккаунт подтверждён", ..., "/login")` в конец метода.

### Т13. Асимметрия писем при закрытии задачи клиентом vs сотрудником

Когда **сотрудник/админ** переводит задачу в `WON` — клиенту уходит красивое письмо с документами
(`sendTaskCompletedEmailWithDocuments`). Когда **клиент сам** переводит свою задачу в `WON`
(это разрешено — см. `CrmAccessService.canUpdateTaskStage`, ветка `Role.CLIENT`, стадия
"На проверке" → `WON`/`OPEN`), сотруднику уходит только in-app уведомление, письмо — не уходит
(письмо шлётся сотруднику только при `LOST`, не при `WON`). Не критично, но несимметрично —
возможно, стоит либо унифицировать (слать письмо в обоих направлениях при закрытии), либо явно
задокументировать, что это осознанное решение.

---

## Итоговая таблица приоритетов

| № | Проблема | Серьёзность | Модуль |
|---|---|---|---|
| Т1 | Любой сотрудник переназначает чужие задачи (нет проверки владения) | 🔴 Критично (Broken Access Control) | crm/tasks |
| Т2 | `/uploads/{storageKey}` отдаёт файлы в обход прав на документ | 🔴 Критично (Broken Access Control) | documents |
| Т3 | `LEARNER` полностью обходит проверку доступа к чату | 🔴 Критично (Broken Access Control) | chat |
| Т4 | `requestTask` не назначает задачу на закреплённого сотрудника | 🟠 Важно | crm/tasks |
| Т5 | Ложное уведомление "запрос документов" на любую задачу | 🟠 Важно | crm/tasks |
| Т6 | Сравнение entity по ссылке в `assignTask` | 🟠 Важно | crm/tasks |
| Т7 | Пул задач ≠ список задач | 🟠 Важно | crm/tasks |
| Т8 | Ссылка в уведомлении о документе теряется | 🟠 Важно | notifications |
| Т9 | Нет уведомления админу / welcome-письма при регистрации | 🟠 Важно | auth |
| Т10 | `required` не работает на скрытом `<input>` в `DatePicker` | 🟡 Средне | frontend |
| Т11 | Слабая проверка типа загружаемого файла | 🟡 Средне (усиливает Т2) | documents |
| Т12 | Нет уведомления сотруднику при одобрении админом | 🟢 Мелко | admin |
| Т13 | Асимметрия писем при закрытии задачи клиентом/сотрудником | 🟢 Мелко | crm/tasks |

**Рекомендуемый порядок исправления:** сначала Т1–Т3 (это реальные дыры в правах доступа — ими
можно злоупотребить прямо сейчас, зная только API), затем Т4–Т9 (ломают ключевые сценарии,
которые вы и описывали в первом сообщении), потом всё остальное.

Код-фиксы для Т1–Т5 приведены выше целиком; для Т6–Т13 — в файле `zhan-finance-fixes.md` из
предыдущего ответа.
