# Недельный план JF-1C — продуктовое масштабирование

---

## Понедельник — критические дефекты

### 1. Фильтрация archived во всех `@Query`

`TaskRepository` — добавить `AND t.archived = false` в четыре метода:

```java
// TaskRepository.java
@Query("select t from Task t join fetch t.client c " +
       "left join fetch c.assignedEmployee left join fetch t.assignedTo " +
       "left join fetch t.createdBy left join fetch t.stage s " +
       "where t.archived = false")
List<Task> findAllWithDetails();

@Query("select t from Task t join fetch t.client c " +
       "left join fetch c.assignedEmployee left join fetch t.assignedTo " +
       "left join fetch t.createdBy left join fetch t.stage s " +
       "where (t.client.id = :clientId or t.createdBy.id = :clientId) " +
       "and t.archived = false")
List<Task> findAllByClientWithDetails(@Param("clientId") Long clientId);

@Query("select t from Task t join fetch t.client c " +
       "left join fetch c.assignedEmployee left join fetch t.assignedTo " +
       "left join fetch t.createdBy left join fetch t.stage s " +
       "where (c.assignedEmployee = :employee or t.assignedTo = :employee) " +
       "and t.archived = false")
List<Task> findAllByEmployeeWithDetails(@Param("employee") User employee);

@Query("select distinct t from Task t join fetch t.client c " +
       "left join fetch c.assignedEmployee left join fetch t.assignedTo " +
       "left join fetch t.createdBy left join fetch t.stage s left join fetch t.subtasks " +
       "where (lower(t.title) like lower(concat('%', :query, '%')) " +
       "or lower(t.description) like lower(concat('%', :query, '%'))) " +
       "and t.archived = false")
List<Task> searchTasks(@Param("query") String query);
```

Добавить специализированный метод для архивных страниц:

```java
@Query("select t from Task t join fetch t.client c " +
       "left join fetch c.assignedEmployee left join fetch t.assignedTo " +
       "left join fetch t.createdBy left join fetch t.stage s " +
       "where t.archived = true and s.type = :stageType")
List<Task> findArchivedByStageType(@Param("stageType") StageType stageType);
```

Добавить endpoint:

```java
// TaskController.java
@GetMapping
public ApiResponse<List<TaskDto>> getTasks(
    ...
    @RequestParam(required = false) Boolean archived,
    @RequestParam(required = false) StageType stageType
) { ... }
```

---

### 2. Фикс `navigate()` путей

Добавить в `routes.ts`:

```ts
CLIENT_TASK_DETAILS: '/client/tasks/:id',
```

Заменить во всех компонентах:

```tsx
// ClientTaskDetailsPage.tsx — две кнопки "Вернуться назад"
navigate('/dashboard/client')  →  navigate(ROUTES.CLIENT)

// ClientOverviewPage.tsx
navigate(`/dashboard/client/tasks/${task.id}`)
→ navigate(ROUTES.CLIENT_TASK_DETAILS.replace(':id', String(task.id)))
```

Обновить `App.tsx`:

```tsx
<Route path={ROUTES.CLIENT_TASK_DETAILS} element={<ClientTaskDetailsPage />} />
```

---

### 3. `closedAt` + idempotency + мёртвый код

**`TaskService.updateTaskStage`** — выставлять `closedAt` при финальных стадиях:

```java
if (newStage.getType() == StageType.WON || newStage.getType() == StageType.LOST) {
    task.setClosedAt(java.time.LocalDate.now());
}
```

**`TaskService.archiveTask`** — idempotency guard:

```java
public TaskDto archiveTask(Long taskId, User user) {
    Task task = getTaskEntity(taskId);
    if (task.isArchived()) {
        return taskMapper.mapToDto(task); // уже архивирована — ранний возврат
    }
    ...
}
```

**`ClientOverviewPage.tsx`** — удалить три блока:

```tsx
// удалить:
import { TaskDetailsModal } from '@/entities/task/ui/TaskDetailsModal';
const [selectedTask, setSelectedTask] = useState<TaskDto | null>(null);
const handleUpdateTask = async (updatedTask: TaskDto) => { ... };
```

---

## Вторник — клиентский онбординг

### 4. Welcome-экран при пустом дашборде

Условие: `tasks.length === 0` в `ClientOverviewPage`. Вместо пустого списка — отдельный блок:

- Что такое JF-1C и как работает процесс (3 шага)
- CTA «Заказать услугу» → `ROUTES.CLIENT_SERVICES`
- Контакт менеджера если назначен

```tsx
// ClientOverviewPage.tsx
if (!isLoading && tasks.length === 0) {
  return <ClientWelcomeScreen assignedEmployee={user?.assignedEmployee} />;
}
```

Компонент `ClientWelcomeScreen` — новый файл `/pages/dashboard/client/ClientWelcomeScreen.tsx`.

---

### 5. Русификация email-уведомлений

Текущие шаблоны: «Task Stage Updated», «Client X updated task Y to Z» — полностью на английском.

Переработать в `EmailNotificationService`:

```java
// sendTaskStatusUpdatedEmail — русский текст
"Статус вашей задачи «" + task.getTitle() + "» изменён на: " + newStageName

// sendTaskStatusUpdatedEmail для сотрудника при CLIENT-действии
"Клиент " + actor.getFullName() + " отказался от задачи «" + task.getTitle() + "»"
+ (lostReason != null ? "\nПричина: " + lostReason : "")
```

Также: при переходе в LOST отправлять `lostReason` в тело письма клиенту.

---

## Среда — конфигурируемые пайплайны

### 6. `isPreFinal` на `Stage` + убрать hardcode

Миграция:

```sql
-- V38__Add_Is_Pre_Final_To_Stages.sql
ALTER TABLE stages ADD COLUMN is_pre_final BOOLEAN DEFAULT FALSE;
```

Обновить `Stage.java`:

```java
@Column(name = "is_pre_final", nullable = false)
private boolean isPreFinal = false;
```

Обновить `CrmAccessService.canUpdateTaskStage`:

```java
// было:
return task.getStage() != null && "На проверке".equals(task.getStage().getName());

// стало:
return task.getStage() != null && task.getStage().isPreFinal();
```

Обновить сидер — выставить `isPreFinal = true` для предфинальной стадии.

---

### 7. UI управления стадиями для ADMIN

Новая страница `AdminPipelinePage` (или вкладка в Settings):

- Список стадий пайплайна с drag-and-drop сортировкой
- Редактирование: название, цвет, `isPreFinal`, тип (OPEN/WON/LOST)
- Создание и удаление стадий

Новые endpoints:

```
PATCH /api/crm/pipelines/{pipelineId}/stages/{stageId}
POST  /api/crm/pipelines/{pipelineId}/stages
DELETE /api/crm/pipelines/{pipelineId}/stages/{stageId}
```

---

### 8. Поддержка нескольких пайплайнов при создании задачи

```java
// TaskCreateRequest.java
Long pipelineId; // опционально — fallback на default pipeline
```

```java
// TaskService.createTask
Pipeline pipeline = request.getPipelineId() != null
    ? pipelineRepository.findById(request.getPipelineId()).orElseThrow(...)
    : pipelineRepository.findByIsDefaultTrue().orElseThrow(...);
```

На фронте — опциональный select в `TaskCreateModal` для ADMIN/EMPLOYEE.

---

## Четверг — аналитика для ADMIN

### 9. Виджет причин отказов + воронка

`countTasksByLostReason()` уже есть в `TaskRepository` — данные не выводятся нигде.

Добавить на `AdminOverviewPage`:

**Виджет «Топ причин отказов»** — горизонтальный bar chart (recharts или простые div-бары):

```tsx
// данные из GET /api/crm/dashboard/admin → поле lostReasons
{ reason: 'Слишком дорого', count: 12 },
{ reason: 'Нашел другого', count: 7 },
```

**Виджет «Воронка»** — количество задач по стадиям в порядке `orderIndex`. Показывает конверсию.

Добавить в `DashboardService` / `AdminDashboardDto`:

```java
List<Map<String, Object>> lostReasons;   // countTasksByLostReason()
List<Map<String, Object>> stageCounts;   // countTasksByStatus()
```

---

### 10. Среднее время закрытия по сотрудникам

`getAverageCompletionDays()` заработает после фикса `closedAt` (понедельник).

Добавить в `EmployeeDashboardDto`:

```java
Double avgCompletionDays;
```

Вывести на `AdminOverviewPage` в таблице сотрудников: колонка «Ср. время закрытия (дни)». На дашборде самого сотрудника — отдельная stat-карточка.

---

## Пятница — качество и стабильность

### 11. Унификация `lossReason` → `lostReason`

Сейчас: `TaskStageUpdateRequest.lossReason` (DTO) vs `Task.lostReason` (entity) vs `taskApi.ts lossReason`.

Привести к единому `lostReason`:

```java
// TaskStageUpdateRequest.java
public record TaskStageUpdateRequest(
    @NotNull Long stageId,
    String lostReason   // было lossReason
) {}
```

```ts
// taskApi.ts
body: JSON.stringify({ stageId, lostReason }),

// taskQueries.ts
mutationFn: ({ id, stageId, lostReason }) => updateTaskStage(id, stageId, lostReason),
```

---

### 12. Integration test: CLIENT reject flow

Добавить в `TaskServiceIntegrationTests`:

```java
@Test
void clientCanRejectTask_withLostReason() {
    // создать задачу для клиента
    // вызвать updateTaskStage с LOST stageId и lostReason
    // проверить: task.stage.type == LOST
    // проверить: task.lostReason == переданная строка
    // проверить: task.closedAt != null
    // проверить: уведомление сотруднику создано
}

@Test
void archiveTask_isIdempotent() {
    // архивировать дважды
    // проверить: history содержит ровно одну запись «архивирована»
}
```

---

### 13. AdminArchive страницы: переключить на `archived=true`

```tsx
// AdminArchiveDonePage.tsx
const { data: tasks } = useApiData(() => getTasks({ archived: true, stageType: 'WON' }));

// AdminArchiveCancelledPage.tsx
const { data: tasks } = useApiData(() => getTasks({ archived: true, stageType: 'LOST' }));
```

Убрать клиентскую фильтрацию `tasks?.filter(t => t.stage?.type === 'WON')` — данные приходят уже отфильтрованными.

---

## Итоговая карта недели

| День | Фокус | Файлы |
|------|-------|-------|
| Пн | P0 дефекты из ревью | `TaskRepository`, `TaskService`, `ClientTaskDetailsPage`, `ClientOverviewPage`, `routes.ts` |
| Вт | Клиентский онбординг | `ClientWelcomeScreen`, `EmailNotificationService` |
| Ср | Конфигурируемые пайплайны | `Stage`, `CrmAccessService`, `AdminPipelinePage`, `TaskCreateRequest`, `V38` |
| Чт | Аналитика ADMIN | `AdminOverviewPage`, `DashboardService`, `AdminDashboardDto`, `EmployeeDashboardDto` |
| Пт | Качество | `TaskStageUpdateRequest`, `taskApi.ts`, `taskQueries.ts`, `TaskServiceIntegrationTests`, `AdminArchive*Page` |
