# Фаза 3 — Файлы, документы, аватарки

## Правило этой фазы
**Показывай diff каждого файла до коммита. Не пушишь без моего ОК.**

## Контекст
24 июля был сделан коммит:
`fix(backend): use database storage to prevent file loss on ephemeral disk`

Это означает что файлы должны храниться в БД (bytea колонка или отдельная таблица),
а НЕ в папке `uploads/` на диске (Fly.io ephemeral disk сбрасывается при рестарте).

## Баги для исправления

### БАГ 1 — Файлы не загружаются / аватарки не работают
**Диагностика:**
```bash
# Найди сервис хранения файлов
grep -r "FileStorage\|uploadFile\|saveFile\|multipart" src/main/java --include="*.java" -l

# Проверь как читаются файлы
grep -r "getResource\|loadAsResource\|download" src/main/java --include="*.java" | head -20

# Проверь таблицу documents в БД
# (выполни через fly postgres connect -a zhanfinance-db)
# SELECT id, file_name, storage_key, LENGTH(content) as content_size FROM documents LIMIT 5;
```

**Вероятная причина:** после пересоздания app на Fly.io локальная папка `uploads/`
пустая. Если в `storage_key` хранится путь к файлу — файлы потеряны.
Если хранится UUID и контент в БД — нужно проверить что endpoint правильно читает из БД.

**Покажи мне:**
1. Код `FileStorageService` (или как он называется)
2. Как выглядит `storage_key` в таблице `documents` (из БД)
3. Endpoint который отдаёт файл (`GET /api/documents/{id}/download` или подобный)

Я скажу что именно менять после того как увижу код.

### БАГ 2 — АВР не генерируются (404)
**Диагностика:**
```bash
grep -r "documents/generate\|generateDocument\|DocumentGenerator" src/main/java --include="*.java" -l
```

Прочитай `DocumentGeneratorService` и покажи мне метод генерации.
Также проверь URL на фронте:
```bash
grep -r "documents/generate" src --include="*.ts" --include="*.tsx"
```

**Вероятная причина:** URL не совпадает между фронтом и бэком, или
шаблонный файл (.docx/.html) не находится потому что хранился на диске.

### БАГ 3 — Аватарки
**Диагностика:**
```bash
grep -r "avatar\|profilePicture\|photo" src/main/java --include="*.java" | grep -i "upload\|save\|get" | head -10
grep -r "avatar\|avatar_url" src --include="*.ts" --include="*.tsx" | grep "api\|fetch\|url" | head -10
```

Покажи мне как аватарки сохраняются и как URL формируется на фронте.

## После диагностики

Покажи мне весь собранный материал.
Я дам конкретные инструкции что менять.
Только после моего ОК делаешь изменения и показываешь diff.
