# Что делаем дальше: полный план

## Текущее состояние email-системы

### Что УЖЕ работает ✅
| Событие | Email | In-app уведомление |
|---|---|---|
| Назначена задача сотруднику | ✅ `sendTaskAssignedEmail` | нет |
| Дедлайн сегодня/завтра | ✅ `DeadlineAlertScheduler` (8:00) | нет |
| Статус задачи изменён | ✅ `sendTaskStatusUpdatedEmail` | нет |
| Любое уведомление через `createNotification()` | ✅ `sendEmailAsync` (plain text) | ✅ |

### Что НЕ сделано ❌
| Событие | Email | In-app |
|---|---|---|
| Новая заявка с сайта → админам | ❌ | ❌ |
| Клиенту: "заявка принята" | ❌ | — |
| Документ сгенерирован → клиенту | ❌ | ❌ |
| Новый комментарий в задаче | ❌ | ❌ |
| Дедлайн прошёл (просрочка) | ❌ | ❌ |

### Главная архитектурная дыра
`ContactRequest` не содержит `email` клиента. Даже если написать
`sendEmail(contactRequest.getEmail(), ...)` — поля нет в сущности и DTO.
Это нужно исправить первым делом.

---

## Приоритеты: что делать и в каком порядке

```
УРОВЕНЬ 1 — Критично (влияет на бизнес прямо сейчас)
  └── Email при новой заявке с лендинга

УРОВЕНЬ 2 — Важно (UX и доверие клиента)
  └── Email клиенту "заявка принята"
  └── Уведомления при новом комментарии в задаче

УРОВЕНЬ 3 — Полезно (автоматизация)
  └── Просрочка дедлайна (не только "скоро", но и "уже прошёл")
  └── Email клиенту при готовом документе

УРОВЕНЬ 4 — Красота (потом)
  └── HTML-шаблоны писем через Thymeleaf
  └── Настройки уведомлений в профиле пользователя
```

---

## УРОВЕНЬ 1: Email при новой заявке с лендинга

### Что нужно сделать

#### Бэкенд — 3 изменения

**1. Добавить `email` в `ContactRequest`**

```sql
-- V36__Add_Email_To_Contact_Requests.sql
ALTER TABLE contact_requests ADD COLUMN email VARCHAR(120);
```

```java
// ContactRequest.java — добавить поле:
@Column(length = 120)
private String email;

public String getEmail() { return email; }
public void setEmail(String email) { this.email = email; }

// Конструктор обновить:
public ContactRequest(String name, String phone, String email,
                      String message, String source) {
    this.name = name;
    this.phone = phone;
    this.email = email;
    this.message = message;
    if (source != null && !source.isBlank()) this.source = source;
}
```

```java
// ContactRequestCreateRequest.java:
public record ContactRequestCreateRequest(
    @NotBlank @Size(max = 120) String name,
    @NotBlank @Size(max = 40)  String phone,
    @Email   @Size(max = 120)  String email,    // ДОБАВИТЬ
    @Size(max = 600)           String message,
    @Size(max = 80)            String source
) {}
```

**2. Добавить email-методы в `EmailNotificationService`**

```java
// Клиенту: заявка принята
public void sendContactRequestConfirmation(ContactRequest cr) {
    if (cr.getEmail() == null || cr.getEmail().isBlank()) return;

    String html = String.format("""
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #047857;">Заявка получена ✓</h2>
          <p>Здравствуйте, <b>%s</b>!</p>
          <p>Мы получили вашу заявку и свяжемся с вами в ближайшее время.</p>
          <p><b>Ваш телефон:</b> %s</p>
          <hr style="border: 1px solid #e5e7eb; margin: 20px 0;"/>
          <p style="color: #6b7280; font-size: 13px;">
            Если у вас есть вопросы, позвоните нам.
          </p>
        </div>
        """,
        cr.getName(), cr.getPhone()
    );

    sendHtmlEmail(cr.getEmail(),
        "Ваша заявка принята — ZhanFinance", html);
}

// Всем админам: новая заявка
public void sendNewContactRequestAlert(ContactRequest cr, String adminEmail) {
    String html = String.format("""
        <div style="font-family: Arial, sans-serif; max-width: 600px;">
          <h2 style="color: #dc2626;">🔔 Новая заявка с сайта</h2>
          <table style="border-collapse: collapse; width: 100%%;">
            <tr><td style="padding: 8px; font-weight: bold;">Имя:</td>
                <td style="padding: 8px;">%s</td></tr>
            <tr style="background: #f9fafb;">
                <td style="padding: 8px; font-weight: bold;">Телефон:</td>
                <td style="padding: 8px;">%s</td></tr>
            <tr><td style="padding: 8px; font-weight: bold;">Email:</td>
                <td style="padding: 8px;">%s</td></tr>
            <tr style="background: #f9fafb;">
                <td style="padding: 8px; font-weight: bold;">Источник:</td>
                <td style="padding: 8px;">%s</td></tr>
            <tr><td style="padding: 8px; font-weight: bold;">Сообщение:</td>
                <td style="padding: 8px;">%s</td></tr>
          </table>
          <br/>
          <a href="%s/admin/leads"
             style="padding: 10px 20px; background: #047857; color: white;
                    text-decoration: none; border-radius: 5px;">
            Открыть заявки
          </a>
        </div>
        """,
        cr.getName(),
        cr.getPhone(),
        cr.getEmail() != null ? cr.getEmail() : "не указан",
        cr.getSource(),
        cr.getMessage() != null ? cr.getMessage() : "—",
        frontendUrl
    );

    sendHtmlEmail(adminEmail, "Новая заявка: " + cr.getName(), html);
}
```

**3. Вызвать из `ContactRequestService.create()`**

```java
@Service
public class ContactRequestService {

    private final ContactRequestRepository contactRequestRepository;
    private final EmailNotificationService emailNotificationService;
    private final UserRepository userRepository;  // для поиска всех ADMIN

    // конструктор обновить

    @Transactional
    public ContactRequestDto create(ContactRequestCreateRequest request) {
        ContactRequest cr = new ContactRequest(
            request.name(),
            request.phone(),
            request.email(),   // новое
            request.message(),
            request.source()
        );
        ContactRequest saved = contactRequestRepository.save(cr);

        // 1. Подтверждение клиенту (если есть email)
        emailNotificationService.sendContactRequestConfirmation(saved);

        // 2. Оповещение всех ADMIN
        userRepository.findByRole(Role.ADMIN).forEach(admin ->
            emailNotificationService.sendNewContactRequestAlert(
                saved, admin.getEmail())
        );

        return toDto(saved);
    }
}
```

#### Фронтенд — 1 изменение

Добавить поле email в форму SolutionPicker и ContactForm:

```tsx
// SolutionPicker.tsx — в финальном шаге с контактами:
<input
  type="email"
  placeholder="Email (необязательно)"
  value={contact.email}
  onChange={e => setContact(p => ({ ...p, email: e.target.value }))}
  className="..."
/>

// И в payload при отправке:
body: JSON.stringify({
  name: contact.name,
  phone: contact.phone,
  email: contact.email,   // добавить
  source: 'solution-picker',
  message: answers,
})
```

---

## УРОВЕНЬ 2: Уведомления при новом комментарии в задаче

Сейчас когда сотрудник пишет комментарий в задаче — никто не получает уведомление.

```java
// В TaskService.addComment() или где обрабатывается комментарий:

// Уведомить клиента если комментарий от сотрудника
if (actor.getRole() != Role.CLIENT && task.getClient() != null) {
    notificationService.createNotification(
        task.getClient(),
        "Новый комментарий по задаче: " + task.getTitle(),
        "Сотрудник оставил комментарий. Откройте задачу чтобы прочитать.",
        "/client/tasks/" + task.getId()
    );
}

// Уведомить сотрудника если комментарий от клиента
if (actor.getRole() == Role.CLIENT && task.getAssignedTo() != null) {
    notificationService.createNotification(
        task.getAssignedTo(),
        "Клиент ответил в задаче: " + task.getTitle(),
        task.getClient().getFullName() + " написал комментарий.",
        "/tasks/" + task.getId()
    );
}
```

---

## УРОВЕНЬ 3: Просроченные задачи

`DeadlineAlertScheduler` сейчас шлёт только за день/сегодня.
Добавить проверку просроченных:

```java
@Scheduled(cron = "0 0 9 * * *")  // 9 утра каждый день
public void checkOverdue() {
    List<Task> overdue = taskRepository
        .findByDueDateBeforeAndStageTypeNotIn(
            LocalDate.now(), List.of(StageType.WON, StageType.LOST)
        );

    for (Task task : overdue) {
        if (task.getAssignedTo() != null) {
            // email сотруднику
            emailNotificationService.sendTaskOverdueEmail(
                task.getAssignedTo(), task);
        }
        // in-app уведомление администраторам
        userRepository.findByRole(Role.ADMIN).forEach(admin ->
            notificationService.createNotification(
                admin,
                "Просрочена задача: " + task.getTitle(),
                "Клиент: " + (task.getClient() != null
                    ? task.getClient().getFullName() : "—"),
                "/admin/tasks"
            )
        );
    }
}
```

---

## УРОВЕНЬ 4: HTML-шаблоны через Thymeleaf (потом)

Сейчас HTML писать в `String.format(...)` — это больно.
Когда писем станет больше 5 штук, переходи на Thymeleaf templates:

```
resources/
  templates/
    emails/
      contact-request-confirmation.html
      new-lead-alert.html
      task-assigned.html
      deadline-alert.html
```

```java
// Вместо String.format:
Context ctx = new Context(new Locale("ru"));
ctx.setVariable("name", cr.getName());
ctx.setVariable("phone", cr.getPhone());
String html = templateEngine.process("emails/contact-request-confirmation", ctx);
```

Это не срочно — делай когда будет 6+ шаблонов.

---

## Итого: что делаем прямо сейчас

```
ШАГ 1 (20 мин, бэк):
  Миграция V36 + поле email в ContactRequest + DTO

ШАГ 2 (30 мин, бэк):
  sendContactRequestConfirmation() + sendNewContactRequestAlert()
  в EmailNotificationService

ШАГ 3 (15 мин, бэк):
  Вызов из ContactRequestService.create()

ШАГ 4 (15 мин, фронт):
  Поле email в SolutionPicker и ContactForm

ШАГ 5 (20 мин, бэк):
  Уведомления при новом комментарии в задаче

ИТОГО: ~1.5 часа → заявки работают от А до Я
```

---

## Что НЕ делаем сейчас

- **Telegram-бот** — появится желание, но это отдельная интеграция (telegraf/TelegramBots),
  добавит зависимостей и сложности. После MVP.
- **Настройки уведомлений в профиле** ("хочу получать email о X, но не о Y") —
  нужна таблица `user_notification_preferences`. После MVP.
- **Очередь сообщений (RabbitMQ/Kafka)** — для текущего масштаба
  `@Async` + JavaMail достаточно. Очередь нужна при 1000+ писем/день.
