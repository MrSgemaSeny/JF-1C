# Фича: Генерация документов по шаблону

## Суть
Сотрудник открывает задачу → выбирает шаблон → система подставляет данные из задачи
и профиля клиента → готовый `.docx` прикрепляется к задаче и виден клиенту.

---

## Стек

| Компонент | Выбор | Почему |
|---|---|---|
| Шаблонизатор | **poi-tl** (POI Template Language) | Создан именно для `.docx`-шаблонов. Синтаксис `{{placeholder}}` из коробки. Не надо вручную работать с XML, в отличие от чистого Apache POI |
| Хранение шаблонов | Та же файловая система / S3 что уже используется | Не изобретать второй механизм хранения |
| Хранение результатов | Прикреплять как `TaskDocument` — уже существующая сущность | Переиспользуем существующий механизм документов задачи |

---

## Поддерживаемые плейсхолдеры (реестр)

Единый список. Сотрудник видит его прямо в UI при загрузке шаблона.

### Данные клиента
| Тег | Значение | Если пусто |
|---|---|---|
| `{{CLIENT_NAME}}` | Полное имя клиента | `______` |
| `{{CLIENT_IIN}}` | ИИН / БИН | `______` |
| `{{CLIENT_EMAIL}}` | Email | `______` |
| `{{CLIENT_PHONE}}` | Телефон | `______` |
| `{{CLIENT_COMPANY}}` | Название компании | `______` |

### Данные задачи
| Тег | Значение | Если пусто |
|---|---|---|
| `{{TASK_TITLE}}` | Название задачи | `______` |
| `{{TASK_AMOUNT}}` | Сумма (тенге) | `______` (не `0` — юридически важно) |
| `{{TASK_DEADLINE}}` | Дедлайн | `______` |
| `{{TASK_DESCRIPTION}}` | Описание | `______` |
| `{{TASK_SERVICE}}` | Тип услуги (из pipeline) | `______` |

### Системные
| Тег | Значение |
|---|---|
| `{{DATE_TODAY}}` | Дата генерации: `20 июля 2025` |
| `{{DATE_TODAY_SHORT}}` | `20.07.2025` |
| `{{YEAR}}` | `2025` |
| `{{DOC_NUMBER}}` | Порядковый номер документа (автоинкремент) |

---

## Архитектура

```
Admin
  │  загружает шаблон (.docx с тегами {{...}})
  ▼
POST /api/document-templates
  │  сохраняет файл → возвращает templateId
  ▼
document_templates (таблица)
  id, name, description, file_path, created_at

─────────────────────────────────────────────

Employee
  │  открывает TaskDetailsModal → вкладка Документы
  │  нажимает "Сгенерировать по шаблону"
  │  выбирает шаблон из списка
  ▼
POST /api/tasks/{taskId}/documents/generate
  │  body: { templateId }
  ▼
DocumentGeneratorService
  │  1. Загружает шаблон (file_path)
  │  2. Собирает контекст: клиент + задача
  │  3. poi-tl подставляет все {{теги}}
  │  4. Сохраняет результат как файл
  │  5. Создаёт запись TaskDocument
  ▼
TaskDocument (уже существующая сущность)
  └── виден в задаче у сотрудника
  └── виден в ClientDocumentsPage у клиента
```

---

## Бэкенд: что создаём

### 1. Миграция БД
```sql
-- V35__Create_Document_Templates.sql
CREATE TABLE document_templates (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name        VARCHAR(200) NOT NULL,
    description VARCHAR(500),
    file_path   VARCHAR(500) NOT NULL,
    created_by  UUID REFERENCES users(id),
    created_at  TIMESTAMP DEFAULT NOW()
);

-- Счётчик для номеров документов
CREATE SEQUENCE doc_number_seq START 1000;
```

### 2. Зависимость в build.gradle
```gradle
implementation 'com.deepoove:poi-tl:1.12.2'
```

### 3. Сущность DocumentTemplate
```java
@Entity
@Table(name = "document_templates")
public class DocumentTemplate {
    @Id @GeneratedValue
    private UUID id;

    @Column(nullable = false)
    private String name;

    private String description;

    @Column(nullable = false)
    private String filePath;

    @ManyToOne(fetch = FetchType.LAZY)
    private User createdBy;

    private LocalDateTime createdAt;
}
```

### 4. DocumentGeneratorService (ключевая логика)
```java
@Service
@RequiredArgsConstructor
public class DocumentGeneratorService {

    private final DocumentTemplateRepository templateRepository;
    private final TaskRepository taskRepository;
    private final TaskDocumentRepository taskDocumentRepository;
    private final FileStorageService fileStorageService; // уже существует

    public TaskDocumentDto generateFromTemplate(UUID taskId, UUID templateId, User actor) {
        Task task = taskRepository.findById(taskId).orElseThrow();
        DocumentTemplate template = templateRepository.findById(templateId).orElseThrow();
        User client = task.getClient();

        // 1. Собрать контекст подстановки
        Map<String, Object> context = buildContext(task, client);

        // 2. Загрузить шаблон
        byte[] templateBytes = fileStorageService.load(template.getFilePath());

        // 3. Подставить теги через poi-tl
        XWPFTemplate xwpf = XWPFTemplate
            .compile(new ByteArrayInputStream(templateBytes))
            .render(context);

        // 4. Записать результат в байты
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        xwpf.write(out);
        xwpf.close();

        // 5. Сформировать имя файла
        String date = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        String clientName = client != null ? client.getFullName() : "Клиент";
        String fileName = template.getName() + " - " + clientName + " - " + date + ".docx";

        // 6. Сохранить файл
        String filePath = fileStorageService.save(out.toByteArray(), fileName);

        // 7. Привязать к задаче как TaskDocument
        TaskDocument doc = new TaskDocument();
        doc.setTask(task);
        doc.setFileName(fileName);
        doc.setFilePath(filePath);
        doc.setUploadedBy(actor);
        doc.setGeneratedFromTemplate(template); // новое поле
        return taskDocumentRepository.save(doc);
    }

    private Map<String, Object> buildContext(Task task, User client) {
        String blank = "______";
        Map<String, Object> ctx = new HashMap<>();

        // Клиент
        ctx.put("CLIENT_NAME",    safe(client.getFullName(), blank));
        ctx.put("CLIENT_IIN",     safe(client.getIin(), blank));
        ctx.put("CLIENT_EMAIL",   safe(client.getEmail(), blank));
        ctx.put("CLIENT_PHONE",   safe(client.getPhone(), blank));
        ctx.put("CLIENT_COMPANY", safe(client.getCompanyName(), blank));

        // Задача
        ctx.put("TASK_TITLE",       safe(task.getTitle(), blank));
        ctx.put("TASK_AMOUNT",      task.getAmount() != null
                                    ? task.getAmount().toString() : blank);
        ctx.put("TASK_DEADLINE",    task.getDeadline() != null
                                    ? task.getDeadline().toString() : blank);
        ctx.put("TASK_DESCRIPTION", safe(task.getDescription(), blank));

        // Системные
        ctx.put("DATE_TODAY",       LocalDate.now()
                                    .format(DateTimeFormatter.ofPattern("d MMMM yyyy",
                                    new Locale("ru"))));
        ctx.put("DATE_TODAY_SHORT", LocalDate.now()
                                    .format(DateTimeFormatter.ofPattern("dd.MM.yyyy")));
        ctx.put("YEAR",             String.valueOf(LocalDate.now().getYear()));
        ctx.put("DOC_NUMBER",       generateDocNumber());

        return ctx;
    }

    private String safe(String value, String fallback) {
        return (value != null && !value.isBlank()) ? value : fallback;
    }
}
```

### 5. Контроллер
```java
// Управление шаблонами (только ADMIN)
POST   /api/document-templates          — загрузить шаблон
GET    /api/document-templates          — список шаблонов
DELETE /api/document-templates/{id}     — удалить шаблон

// Генерация (ADMIN + EMPLOYEE)
POST   /api/tasks/{taskId}/documents/generate
       body: { "templateId": "uuid" }
       → возвращает TaskDocumentDto
```

---

## Фронтенд: что создаём

### 1. Страница AdminTemplatesPage
```
/admin/templates

┌─────────────────────────────────────────────┐
│  Шаблоны документов              [+ Загрузить]│
├─────────────────────────────────────────────┤
│  📄 Договор оказания услуг    [Скачать][Удалить]│
│  📄 Счёт на оплату            [Скачать][Удалить]│
│  📄 Акт выполненных работ     [Скачать][Удалить]│
└─────────────────────────────────────────────┘

При загрузке — показывать список доступных тегов {{...}}
чтобы сотрудник знал как оформить шаблон
```

### 2. Изменения в TaskDetailsModal (вкладка Документы)
```
┌──────────────────────────────────────────────────┐
│  Документы задачи                                │
│                                                  │
│  [↑ Загрузить файл]  [⚡ Сгенерировать по шаблону]│
│                              ↓ при нажатии       │
│                   ┌─────────────────────────┐   │
│                   │ Выберите шаблон:        │   │
│                   │ ○ Договор оказания услуг│   │
│                   │ ○ Счёт на оплату        │   │
│                   │ ○ Акт выполненных работ │   │
│                   │          [Сгенерировать]│   │
│                   └─────────────────────────┘   │
│                                                  │
│  📄 Договор - Иванов - 2025-07-20.docx  [↓][🗑] │
└──────────────────────────────────────────────────┘
```

### 3. Новые файлы
```
src/
  pages/dashboard/admin/
    AdminTemplatesPage.tsx        ← новый
  entities/document-template/
    api/documentTemplateApi.ts    ← новый
    model/types.ts                ← новый
  features/document-generate/
    GenerateDocumentButton.tsx    ← новый (дропдаун + вызов API)
```

---

## Роадмап

### MVP (реализуем сейчас)
- [ ] Миграция V35
- [ ] DocumentTemplate entity + repository
- [ ] DocumentGeneratorService с poi-tl
- [ ] 2 эндпоинта: upload template + generate
- [ ] AdminTemplatesPage (загрузка/список/удаление)
- [ ] GenerateDocumentButton в TaskDetailsModal
- [ ] Отображение сгенерированных документов у клиента

### Итерация 2 (потом)
- [ ] Preview сгенерированного документа прямо в браузере (конвертация в PDF)
- [ ] История генераций: кто, когда, по какому шаблону
- [ ] Шаблоны с условными блоками: `{{#if TASK_AMOUNT}}...{{/if}}`
- [ ] Подпись документа (электронная)

---

## Подводные камни

**1. poi-tl и сложное форматирование**
Таблицы, списки, вложенные стили в `.docx` — poi-tl обрабатывает их, но
если шаблон сложный (объединённые ячейки, колонтитулы) — могут быть нюансы.
Совет: начни с простых шаблонов, проверь на реальном `.docx`.

**2. Кодировка русских символов**
poi-tl с русским работает нормально, но проверь что сохранение файла идёт
в UTF-8 и что `Locale("ru")` подключён для форматирования дат.

**3. Параллельные генерации**
Если два сотрудника генерируют документ одновременно для одного клиента —
имена файлов могут совпасть. Решение: добавить UUID к имени файла
или timestamp с миллисекундами.

**4. Большие шаблоны**
Если шаблон > 5MB — генерация может быть медленной.
Решение (потом): вынести в `@Async` и уведомить через WebSocket когда готово.

**5. Клиент не привязан к задаче**
Если задача создана без клиента — `task.getClient()` вернёт null.
В коде уже учтено через `safe()`, но нужно показать предупреждение
в UI: "Клиент не указан — некоторые поля будут пустыми".
