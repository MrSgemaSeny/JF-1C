﻿# JF-1C вЂ” API Contract

> Р‘Р°Р·РѕРІС‹Р№ URL: `https://<fly-app>.fly.dev`  
> Р’СЃРµ Р·Р°С‰РёС‰С‘РЅРЅС‹Рµ СЌРЅРґРїРѕРёРЅС‚С‹ С‚СЂРµР±СѓСЋС‚ Р·Р°РіРѕР»РѕРІРѕРє `Authorization: Bearer <access_token>`  
> Р’СЃРµ РѕС‚РІРµС‚С‹ РѕР±С‘СЂРЅСѓС‚С‹ РІ `ApiResponse<T>` вЂ” СЃРј. СЃС‚СЂСѓРєС‚СѓСЂСѓ РЅРёР¶Рµ

---

## РћР±С‰Р°СЏ СЃС‚СЂСѓРєС‚СѓСЂР° РѕС‚РІРµС‚Р°

```json
// РЈСЃРїРµС…
{
  "success": true,
  "data": { ... }
}

// РћС€РёР±РєР°
{
  "status": 404,
  "code": "RESOURCE_NOT_FOUND",
  "message": "Task not found: 42",
  "path": "/api/v1/crm/tasks/42",
  "traceId": "uuid"
}
```

### РљРѕРґС‹ РѕС€РёР±РѕРє

| HTTP | Code | РљРѕРіРґР° |
|------|------|-------|
| 400 | `BAD_REQUEST` | РќРµРІР°Р»РёРґРЅС‹Р№ Р·Р°РїСЂРѕСЃ, РЅР°СЂСѓС€РµРЅРёРµ Р±РёР·РЅРµСЃ-РїСЂР°РІРёР»Р° |
| 401 | `UNAUTHORIZED` | РќРµС‚ С‚РѕРєРµРЅР° РёР»Рё С‚РѕРєРµРЅ РёСЃС‚С‘Рє |
| 403 | `FORBIDDEN` | РќРµС‚ РїСЂР°РІ РЅР° СЂРµСЃСѓСЂСЃ |
| 404 | `RESOURCE_NOT_FOUND` | Р—Р°РїРёСЃСЊ РЅРµ РЅР°Р№РґРµРЅР° |
| 409 | `CONFLICT` | Email СѓР¶Рµ Р·Р°РЅСЏС‚, РґСѓР±Р»РёСЂРѕРІР°РЅРёРµ |
| 422 | `UNPROCESSABLE_ENTITY` | РќРµРІР°Р»РёРґРЅС‹Р№ РїРµСЂРµС…РѕРґ СЃРѕСЃС‚РѕСЏРЅРёСЏ |
| 429 | `RATE_LIMIT_EXCEEDED` | РЎР»РёС€РєРѕРј РјРЅРѕРіРѕ Р·Р°РїСЂРѕСЃРѕРІ |
| 500 | `INTERNAL_ERROR` | РќРµРїСЂРµРґРІРёРґРµРЅРЅР°СЏ РѕС€РёР±РєР° |

---

## Auth `/api/v1/auth`

### POST /api/v1/auth/register
РџСѓР±Р»РёС‡РЅС‹Р№. Р РµРіРёСЃС‚СЂР°С†РёСЏ РЅРѕРІРѕРіРѕ РїРѕР»СЊР·РѕРІР°С‚РµР»СЏ.

**Request:**
```json
{
  "fullName": "РРІР°РЅ РџРµС‚СЂРѕРІ",
  "email": "ivan@example.com",
  "password": "SecurePass123",
  "role": "CLIENT",
  "phone": "+77001234567",
  "companyName": "РўРћРћ Р РѕРјР°С€РєР°"
}
```

**Roles:** `CLIENT`, `LEARNER` (ADMIN/EMPLOYEE вЂ” С‚РѕР»СЊРєРѕ С‡РµСЂРµР· AdminController)

**Response 200:**
```json
{
  "success": true,
  "data": {
    "accessToken": "eyJ...",
    "refreshToken": "uuid-string",
    "user": { "id": 1, "email": "ivan@example.com", "role": "CLIENT", "fullName": "РРІР°РЅ РџРµС‚СЂРѕРІ" }
  }
}
```

**Errors:** `409 CONFLICT` вЂ” email Р·Р°РЅСЏС‚

---

### POST /api/v1/auth/login
РџСѓР±Р»РёС‡РЅС‹Р№.

**Request:**
```json
{ "email": "ivan@example.com", "password": "SecurePass123" }
```

**Response 200:** Р°РЅР°Р»РѕРіРёС‡РЅРѕ `/register`

**Errors:** `401` вЂ” РЅРµРІРµСЂРЅС‹Р№ РїР°СЂРѕР»СЊ; `429` вЂ” rate limit (auth СЌРЅРґРїРѕРёРЅС‚С‹ РѕРіСЂР°РЅРёС‡РµРЅС‹)

---

### POST /api/v1/auth/refresh
РџСѓР±Р»РёС‡РЅС‹Р№. РћР±РЅРѕРІР»РµРЅРёРµ access-С‚РѕРєРµРЅР°.

**Request:**
```json
{ "refreshToken": "uuid-string" }
```

**Response 200:**
```json
{
  "success": true,
  "data": { "accessToken": "eyJ...", "refreshToken": "new-uuid" }
}
```

**Errors:** `401` вЂ” С‚РѕРєРµРЅ РЅРµ РЅР°Р№РґРµРЅ РёР»Рё РёСЃС‚С‘Рє

---

### POST /api/v1/auth/google
РџСѓР±Р»РёС‡РЅС‹Р№. OAuth С‡РµСЂРµР· Google.

**Request:**
```json
{ "idToken": "google-id-token" }
```

---

## Users `/api/v1/users`

### GET /api/v1/users/me
Р РѕР»Рё: РІСЃРµ Р°СѓС‚РµРЅС‚РёС„РёС†РёСЂРѕРІР°РЅРЅС‹Рµ.

**Response 200:**
```json
{
  "id": 1,
  "email": "ivan@example.com",
  "fullName": "РРІР°РЅ РџРµС‚СЂРѕРІ",
  "role": "CLIENT",
  "phone": "+77001234567",
  "companyName": "РўРћРћ Р РѕРјР°С€РєР°",
  "avatarUrl": "/uploads/avatars/1.jpg",
  "isProfileComplete": true
}
```

### PATCH /api/v1/users/me
Р РѕР»Рё: РІСЃРµ. РћР±РЅРѕРІР»РµРЅРёРµ РїСЂРѕС„РёР»СЏ.

### POST /api/v1/users/me/avatar
Р РѕР»Рё: РІСЃРµ. Р—Р°РіСЂСѓР·РєР° Р°РІР°С‚Р°СЂР°. `multipart/form-data`, РїРѕР»Рµ `file`.

---

## Admin `/api/v1/admin`

> Р’СЃРµ СЌРЅРґРїРѕРёРЅС‚С‹: СЂРѕР»СЊ `ADMIN` РѕР±СЏР·Р°С‚РµР»СЊРЅР°.

### GET /api/v1/admin/users
РЎРїРёСЃРѕРє РІСЃРµС… РїРѕР»СЊР·РѕРІР°С‚РµР»РµР№.

**Query params:** `role=CLIENT|EMPLOYEE|ADMIN|LEARNER`

### POST /api/v1/admin/employees
РЎРѕР·РґР°РЅРёРµ СЃРѕС‚СЂСѓРґРЅРёРєР° (С‚РѕР»СЊРєРѕ admin).

**Request:**
```json
{ "fullName": "РњР°СЂРёСЏ РЎРёРґРѕСЂРѕРІР°", "email": "maria@firm.kz", "password": "TempPass123", "phone": "+77009876543" }
```

### PATCH /api/v1/admin/users/{id}/approve
РџРѕРґС‚РІРµСЂР¶РґРµРЅРёРµ РїРѕР»СЊР·РѕРІР°С‚РµР»СЏ.

### PATCH /api/v1/admin/users/{id}/role
РЎРјРµРЅР° СЂРѕР»Рё.

**Request:** `{ "role": "EMPLOYEE" }`

### GET /api/v1/admin/dashboard
РЎС‚Р°С‚РёСЃС‚РёРєР°: РєРѕР»-РІРѕ РїРѕР»СЊР·РѕРІР°С‚РµР»РµР№ РїРѕ СЂРѕР»СЏРј, Р°РєС‚РёРІРЅС‹Рµ Р·Р°РґР°С‡Рё, СЃС‚Р°С‚РёСЃС‚РёРєР° РїРѕ СЃРѕС‚СЂСѓРґРЅРёРєР°Рј.

---

## CRM Tasks `/api/v1/crm/tasks`

### GET /api/v1/crm/tasks
Р РѕР»Рё: `ADMIN`, `EMPLOYEE` вЂ” РІСЃРµ Р·Р°РґР°С‡Рё; `CLIENT` вЂ” С‚РѕР»СЊРєРѕ СЃРІРѕРё.

**Query params (С‚РѕР»СЊРєРѕ РґР»СЏ ADMIN/EMPLOYEE):**
- `clientId=42` вЂ” Р·Р°РґР°С‡Рё РєРѕРЅРєСЂРµС‚РЅРѕРіРѕ РєР»РёРµРЅС‚Р°
- `assignedToId=5` вЂ” Р·Р°РґР°С‡Рё СЃРѕС‚СЂСѓРґРЅРёРєР°
- `stageId=3` вЂ” Р·Р°РґР°С‡Рё РІ СЃС‚Р°РґРёРё
- `unassigned=true` вЂ” Р·Р°РґР°С‡Рё Р±РµР· РёСЃРїРѕР»РЅРёС‚РµР»СЏ

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "title": "РџРѕРґРіРѕС‚РѕРІРєР° РљРџРќ Р·Р° Q1",
      "description": "...",
      "stageId": 2,
      "stageName": "Р’ СЂР°Р±РѕС‚Рµ",
      "isPreFinal": false,
      "clientId": 10,
      "clientName": "РўРћРћ Р РѕРјР°С€РєР°",
      "assignedToId": 5,
      "assignedToName": "РњР°СЂРёСЏ РЎРёРґРѕСЂРѕРІР°",
      "dueDate": "2026-04-30",
      "tags": ["РќР”РЎ", "СЃСЂРѕС‡РЅРѕ"],
      "subtasks": [],
      "createdAt": "2026-03-01T10:00:00"
    }
  ]
}
```

### POST /api/v1/crm/tasks
Р РѕР»Рё: `ADMIN`, `EMPLOYEE`.

**Request:**
```json
{
  "title": "РџРѕРґРіРѕС‚РѕРІРєР° РљРџРќ Р·Р° Q1",
  "description": "РћРїРёСЃР°РЅРёРµ Р·Р°РґР°С‡Рё",
  "clientId": 10,
  "assignedToId": 5,
  "stageId": 1,
  "dueDate": "2026-04-30",
  "tags": ["РљРџРќ"],
  "serviceIds": [2, 3]
}
```

### PATCH /api/v1/crm/tasks/{id}/stage
Р РѕР»Рё: `ADMIN`, `EMPLOYEE`, `CLIENT` (С‚РѕР»СЊРєРѕ РґР»СЏ `isPreFinal` СЃС‚Р°РґРёР№).

**Request:** `{ "stageId": 3 }`

**Errors:** `403` вЂ” CLIENT РїС‹С‚Р°РµС‚СЃСЏ СЃРјРµРЅРёС‚СЊ РЅРµ preР¤РёРЅР°Р»СЊРЅСѓСЋ СЃС‚Р°РґРёСЋ; `422` вЂ” РЅРµРІР°Р»РёРґРЅС‹Р№ РїРµСЂРµС…РѕРґ

### POST /api/v1/crm/tasks/request
Р РѕР»Рё: `CLIENT`. РљР»РёРµРЅС‚ СЃРѕР·РґР°С‘С‚ Р·Р°СЏРІРєСѓ РЅР° СѓСЃР»СѓРіСѓ.

---

## CRM Clients `/api/v1/crm/clients`

### GET /api/v1/crm/clients
Р РѕР»Рё: `ADMIN`, `EMPLOYEE`.

### GET /api/v1/crm/clients/{id}
Р РѕР»Рё: `ADMIN`, `EMPLOYEE`, `CLIENT` (С‚РѕР»СЊРєРѕ СЃРІРѕР№ РїСЂРѕС„РёР»СЊ).

### GET /api/v1/crm/clients/{id}/dashboard
Р”Р°С€Р±РѕСЂРґ РєР»РёРµРЅС‚Р°: Р°РєС‚РёРІРЅС‹Рµ Р·Р°РґР°С‡Рё, РґРѕРєСѓРјРµРЅС‚С‹, СЃС‡РµС‚Р°, СѓРІРµРґРѕРјР»РµРЅРёСЏ.

---

## Billing `/api/v1/billing`

### GET /api/v1/billing/invoices
Р РѕР»Рё: `ADMIN` вЂ” РІСЃРµ СЃС‡РµС‚Р°; `CLIENT` вЂ” С‚РѕР»СЊРєРѕ СЃРІРѕРё.

**Query params:** `status=DRAFT|ISSUED|PAID|CANCELED`, `clientId=10`

### POST /api/v1/billing/invoices
Р РѕР»Рё: `ADMIN`.

**Request:**
```json
{
  "clientId": 10,
  "title": "РЈСЃР»СѓРіРё Р·Р° РјР°СЂС‚ 2026",
  "amount": 150000.00,
  "dueDate": "2026-04-15",
  "taskId": 42
}
```

### PATCH /api/v1/billing/invoices/{id}/status
Р РѕР»Рё: `ADMIN`.

**Request:** `{ "status": "ISSUED" }`

**Р”РѕРїСѓСЃС‚РёРјС‹Рµ РїРµСЂРµС…РѕРґС‹:** `DRAFTв†’ISSUED`, `ISSUEDв†’PAID`, `ISSUEDв†’CANCELED`

**Errors:** `422` вЂ” РЅРµРІР°Р»РёРґРЅС‹Р№ РїРµСЂРµС…РѕРґ (РЅРµР»СЊР·СЏ PAIDв†’DRAFT)

---

## Documents `/api/v1/documents`

### GET /api/v1/documents
Р РѕР»Рё: `ADMIN`, `EMPLOYEE` вЂ” РІСЃРµ; `CLIENT` вЂ” С‚РѕР»СЊРєРѕ СЃРІРѕРё.

**Query params:** `clientId=10`, `type=CONTRACT|ACT|REPORT`

### POST /api/v1/documents/upload
`multipart/form-data`. РџРѕР»СЏ: `file`, `title`, `clientId`, `type`.

**РћРіСЂР°РЅРёС‡РµРЅРёСЏ:** max 20MB (TODO: РїРѕРєР° 500MB РЅР° Р±РµРєРµРЅРґРµ вЂ” Р±Р°Рі)

### GET /api/v1/documents/{id}/download
РЎРєР°С‡Р°С‚СЊ С„Р°Р№Р». РћС‚РґР°С‘С‚ Р±РёРЅР°СЂРЅРёРє СЃ `Content-Disposition: attachment`.

### GET /api/v1/documents/download-zip?ids=1,2,3
(TODO: РЅРµ СЂРµР°Р»РёР·РѕРІР°РЅ) Bulk-СЃРєР°С‡РёРІР°РЅРёРµ ZIP.

---

## Notifications `/api/v1/notifications`

### GET /api/v1/notifications
Р РѕР»Рё: РІСЃРµ. РЈРІРµРґРѕРјР»РµРЅРёСЏ С‚РµРєСѓС‰РµРіРѕ РїРѕР»СЊР·РѕРІР°С‚РµР»СЏ.

**Query params:** `unread=true`

### PATCH /api/v1/notifications/{id}/read
### PATCH /api/v1/notifications/read-all

---

## WebSocket `/ws`

РџРѕРґРєР»СЋС‡РµРЅРёРµ: `ws://.../ws?token=<access_token>`

**РўРѕРїРёРєРё (subscribe):**
```
/user/queue/notifications     в†ђ Р»РёС‡РЅС‹Рµ СѓРІРµРґРѕРјР»РµРЅРёСЏ
/user/queue/chat              в†ђ РІС…РѕРґСЏС‰РёРµ СЃРѕРѕР±С‰РµРЅРёСЏ С‡Р°С‚Р°
/topic/admin/dashboard        в†ђ (TODO) РѕР±РЅРѕРІР»РµРЅРёСЏ РґР°С€Р±РѕСЂРґР° РІ СЂРµР°Р»СЊРЅРѕРј РІСЂРµРјРµРЅРё
```

**РћС‚РїСЂР°РІРєР°:**
```
/app/chat/send               в†ђ РѕС‚РїСЂР°РІРёС‚СЊ СЃРѕРѕР±С‰РµРЅРёРµ
```

---

## Versioning

РЎРµР№С‡Р°СЃ API Р±РµР· РІРµСЂСЃРёРё. РљРѕРіРґР° РїРѕСЏРІРёС‚СЃСЏ РІС‚РѕСЂРѕР№ РІРЅРµС€РЅРёР№ РєР»РёРµРЅС‚ (РјРѕР±РёР»РєР° / РёРЅС‚РµРіСЂР°С†РёСЏ) вЂ” РґРѕР±Р°РІРёС‚СЊ `/api/v1/` РїСЂРµС„РёРєСЃ. Р”Рѕ СЌС‚РѕРіРѕ РјРѕРјРµРЅС‚Р° вЂ” РїСЂРµР¶РґРµРІСЂРµРјРµРЅРЅРѕ.

---

## Swagger UI

Р”РѕСЃС‚СѓРїРµРЅ С‚РѕР»СЊРєРѕ РґР»СЏ `ADMIN`:  
`https://<fly-app>.fly.dev/swagger-ui.html`

Р“РµРЅРµСЂРёСЂСѓРµС‚СЃСЏ Р°РІС‚РѕРјР°С‚РёС‡РµСЃРєРё РёР· Р°РЅРЅРѕС‚Р°С†РёР№ OpenAPI. РџСЂРё РґРѕР±Р°РІР»РµРЅРёРё РЅРѕРІРѕРіРѕ СЌРЅРґРїРѕРёРЅС‚Р° вЂ” РґРѕР±Р°РІРёС‚СЊ `@Operation(summary = "...")` РЅР° РјРµС‚РѕРґ.

