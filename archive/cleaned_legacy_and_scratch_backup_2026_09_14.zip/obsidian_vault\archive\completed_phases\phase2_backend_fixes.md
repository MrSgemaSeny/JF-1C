# Фаза 2 — Исправление бэкенда (только показать diff)

## Правило этой фазы
**Ты делаешь изменения в файлах локально.**
**Ты НЕ делаешь git commit и НЕ делаешь git push до подтверждения.**
После каждого изменения выполни `git diff [файл]` и покажи мне вывод.
Я должен одобрить каждый diff перед тем как ты перейдёшь к следующему файлу.

## Баги для исправления в этой фазе

### БАГ 1 — DatabaseMigrationRunner (is_published NOT NULL)
**Симптом:** при старте приложения в логах:
```
ERROR: null value in column "is_published" of relation "courses" violates not-null constraint
```
**Файл:** `src/main/java/com/example/zhanfinancebackend/modules/courses/config/DatabaseMigrationRunner.java`

**Исправление:** В INSERT в таблицу `courses` добавить поле `is_published = true`.
Также убедиться что строки в SQL написаны в UTF-8 (не в latin1/windows-1251).

### БАГ 2 — Профиль prod не активирован (Swagger в проде)
**Симптом:** в логах `WARN: SpringDoc /swagger-ui.html endpoint is enabled by default`
**Проверь:** есть ли secret `SPRING_PROFILES_ACTIVE=prod` в Fly.io
```bash
fly secrets list -a zhanfinance | grep PROFILES
```
Если нет:
```bash
fly secrets set SPRING_PROFILES_ACTIVE=prod -a zhanfinance
```
Это не требует изменения кода — только secret.

### БАГ 3 — Сортировка уроков и модулей
**Симптом:** модули и уроки отображаются в неправильном порядке
**Найди репозитории:**
```bash
grep -r "findByChapter\|findAllByChapter" src/main/java --include="*.java"
grep -r "findByCourse\|findAllByCourse" src/main/java --include="*.java" | grep -i chapter
```
**Исправление:** добавить `@Query` с `ORDER BY created_at ASC` или использовать
`List<Lesson> findByChapterOrderByCreatedAtAsc(Chapter chapter)`

### БАГ 4 — 404 на /api/crm/tasks/{id}/documents/generate
**Проверь:**
```bash
grep -r "documents/generate" src/main/java --include="*.java"
```
Если метод есть — значит URL неправильный на фронте или маппинг сбился.
Если метода нет — он был удалён или никогда не существовал.
Покажи мне вывод grep — я скажу что делать.

### БАГ 5 — 500 на /api/admin/curators/{id}/courses/{id}
**Найди контроллер:**
```bash
grep -r "curators" src/main/java --include="*.java" -l | grep -i controller
```
Прочитай метод и покажи мне — вероятно проблема в том что `course_curators`
таблица не создана или `assigned_by` не передаётся.

## Порядок работы

1. Исправляешь БАГ 1
2. Выполняешь `git diff` этого файла
3. Показываешь мне
4. Ждёшь "ОК" от меня
5. Переходишь к БАГ 2
6. И так далее

**Стоп после всех diff'ов. Ждёшь команды на Фазу 3.**
