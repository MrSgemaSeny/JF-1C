# Zhan Finance — аудит i18n (где нет перевода)

Проверено 165 файлов фронта: 80 используют `useTranslation`, у 76 при этом остался
захардкоженный русский текст. Ниже — реально проблемные места (тестовые файлы и обычные
комментарии в коде из списка исключены).

## Что уже есть

`shared/i18n/locales/{ru,en}/` содержит только **3 неймспейса**: `auth.json`, `common.json`,
`crm.json`. То есть у лендинга, курсов и чата i18n-неймспейса нет вообще — переводить там
нечем, даже если расставить `t()`.

---

## 1. Публичный лендинг — самая большая дыра, контент захардкожен на 100%

Рендерится напрямую на `/`, `/about`, `/services` (подтверждено: `ServicesFaqContact.tsx` и
`AboutProcess.tsx` импортируют эти файлы как есть, без прогона через `t()`):

- `shared/config/content/faq.ts` — вопросы-ответы
- `shared/config/content/pricing-plans.ts` — тарифы и цены
- `shared/config/content/reviews.ts` — отзывы клиентов
- `shared/config/content/services.ts` — карточки услуг
- `shared/config/content/stats.ts` — цифры на главной
- `shared/config/content/team.ts` — команда (ФИО, должности)
- `shared/config/content/work-process.ts` — этапы работы (длинные тексты)
- `features/solution-picker/questions.ts` — квиз-подборщик решений на лендинге

**Итог:** переключатель RU/EN переключает шапку/сайдбар, но весь контент лендинга — тарифы,
отзывы, FAQ, команда, квиз — остаётся русским при любом выбранном языке.

**Что сделать:** завести неймспейс `landing.json` (ru/en), перенести тексты туда, а
`shared/config/content/*.ts` превратить в файлы с ключами вида:
```ts
// было
export const faqs = [
  { q: 'Как начать работу?', a: 'Оставьте заявку на сайте...' },
];

// стало
export const faqs = [
  { qKey: 'landing.faq.start.q', aKey: 'landing.faq.start.a' },
];
```
и в компоненте рендерить `t(item.qKey)` / `t(item.aKey)`.

---

## 2. Чат — 100% захардкожен (видно прямо на присланном скриншоте)

`widgets/chat/ChatDrawer.tsx`:
```tsx
<h3 className="font-bold text-sm">{otherUserName || 'Чат'}</h3>
...
<p className="text-sm">Нет сообщений</p>
<p className="text-xs">Напишите первым!</p>
...
placeholder="Введите сообщение..."
```
Именно эти строки видны на скрине с "Клиент 3" ("Нет сообщений / Напишите первым!"). Ни одного
`t()` во всём компоненте.

**Что сделать:** добавить неймспейс `chat.json`:
```json
{ "title": "Чат", "empty": "Нет сообщений", "emptyHint": "Напишите первым!", "placeholder": "Введите сообщение..." }
```
```tsx
<h3 className="font-bold text-sm">{otherUserName || t('chat.title')}</h3>
<p className="text-sm">{t('chat.empty')}</p>
<p className="text-xs">{t('chat.emptyHint')}</p>
...
placeholder={t('chat.placeholder')}
```

---

## 3. Модуль курсов — без i18n, плюс `alert()` вместо тостов

- `pages/dashboard/admin/components/CourseCurriculumTab.tsx` — "Глава", "Урок",
  `alert('Ошибка при создании главы')`, `alert('Ошибка при создании урока')`
- `pages/dashboard/admin/components/LessonEditorFullScreen.tsx` — "Назад к курсу", "Редактор
  урока", "Сохранение...", "Сохранить изменения", "Видео урока",
  `alert('Ошибка при сохранении урока')`
- `pages/dashboard/learner/components/CourseCertificate.tsx` — весь текст сертификата
  ("СЕРТИФИКАТ", "об успешном окончании курса", "успешно завершил(а) обучение по программе...")
  зашит намертво в JSX/inline-стили

**Что сделать:** неймспейс `courses.json` + заменить `alert(...)` на существующий toast/уведомление
в UI (у `alert()` два самостоятельных недостатка — не переводится и блокирует поток выполнения
JS до закрытия диалога браузером, что на мобильных выглядит особенно плохо).

---

## 4. Сайдбар — переводится, но на честном слове (хрупкая конструкция)

`widgets/dashboard-shell/nav-config.ts` вперемешку хранит английские (`'Overview'`, `'Chat'`) и
русские (`'Лиды'`, `'Список задач'`, `'Мои задачи'`) лейблы напрямую как значения. А
`DashboardSidebar.tsx` "переводит" их так:
```tsx
const icon = NAV_ICONS[item.label] ?? <ChevronRight size={16} />;   // ключ = сам текст лейбла
...
switch (item.label) {
  case 'Лиды': i18nKey = 'nav.leads'; break;
  case 'Список задач': i18nKey = 'nav.tasks'; break;
  ...
  default: i18nKey = item.label;   // не нашли соответствие — показываем как есть, без перевода
}
const translatedLabel = i18nKey.startsWith('nav.') ? t(i18nKey) : item.label;
```
Сейчас это работает только потому, что кто-то вручную завёл `case` на каждую конкретную строку
лейбла. Любое переименование пункта меню в `nav-config.ts` тихо сломает и перевод (упадёт в
`default`, покажет нетронутый лейбл), и иконку (`NAV_ICONS[item.label]` не найдёт ключ).

**Что сделать** — завести стабильные id вместо текста-как-ключа:
```ts
// nav-config.ts
export interface NavItem {
  id: string;       // 'overview' | 'leads' | 'tasks' | ...
  href: string;
}

export const navConfig: Record<UserRole, NavItem[]> = {
  ADMIN: [
    { id: 'overview', href: ROUTES.ADMIN },
    { id: 'leads', href: ROUTES.ADMIN_LEADS },
    { id: 'tasks', href: ROUTES.ADMIN_TASKS },
    ...
  ],
  ...
};
```
```tsx
// DashboardSidebar.tsx
const icon = NAV_ICONS[item.id] ?? <ChevronRight size={16} />;
const translatedLabel = t(`nav.${item.id}`);
```
Так и иконка, и перевод берутся по одному и тому же стабильному id, а не по тексту, который
может когда-нибудь поменяться.

---

## 5. По мелочи

`entities/document-template/ui/GenerateDocumentButton.tsx`:
```tsx
Сгенерировать
<h4 ...>Выберите шаблон</h4>
<div ...>Нет доступных шаблонов</div>
```
Без `t()`. Небольшой компонент, но раз его текст виден клиенту/сотруднику при генерации
документов — тоже стоит вынести в `common.json` или `documents.json`.

---

## Итоговая таблица

| № | Область | Что не переведено | Масштаб |
|---|---|---|---|
| 1 | Публичный лендинг | FAQ, тарифы, отзывы, услуги, команда, квиз | 🔴 Огромный — вся публичная часть сайта |
| 2 | Чат | Заголовок, заглушки, плейсхолдер | 🟠 Средний, но заметный (видно на скрине) |
| 3 | Курсы (админ + ученик) | Редактор курса/урока, сертификат, alert-ошибки | 🟠 Средний |
| 4 | Сайдбар | Технически переводится, но хрупко (текст как ключ) | 🟡 Риск регрессии, не баг прямо сейчас |
| 5 | Кнопка генерации документа | 3 строки текста | 🟢 Мелочь |

**Рекомендуемый порядок:** сначала лендинг (пункт 1) — это первое, что видит любой посетитель
сайта, и переключатель языка там сейчас откровенно не работает; затем чат и курсы; сайдбар
можно поправить попутно, когда будете трогать `nav-config.ts` по другому поводу.
