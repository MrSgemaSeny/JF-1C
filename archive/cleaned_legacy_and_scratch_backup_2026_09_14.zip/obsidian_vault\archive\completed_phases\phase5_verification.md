# Фаза 5 — Проверка после деплоя

## Правило этой фазы
Никаких изменений кода. Только проверка что всё работает.
Если что-то не работает — фиксируешь баг и сообщаешь мне. НЕ чинишь сам.

## Smoke тесты

Выполни каждый тест и отметь статус: ✅ работает / ❌ не работает / ⚠️ частично.

### AUTH
```bash
# Логин
curl -s -X POST https://zhanfinance.fly.dev/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"mrsgemaseny@gmail.com","password":"PASSWORD"}' \
  | python3 -c "import json,sys; d=json.load(sys.stdin); print('OK:', d.get('accessToken','')[:20]+'...' if 'accessToken' in d else 'FAIL:', d)"
```
Сохрани токен в переменную TOKEN для следующих тестов.

### CRM — Задачи
```bash
# Получить список задач
curl -s https://zhanfinance.fly.dev/api/crm/tasks \
  -H "Authorization: Bearer $TOKEN" | python3 -c "import json,sys; d=json.load(sys.stdin); print('Tasks count:', len(d) if isinstance(d,list) else d)"

# Создать задачу
curl -s -X POST https://zhanfinance.fly.dev/api/crm/tasks \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"title":"Тест задача","serviceIds":[1]}' \
  | python3 -c "import json,sys; d=json.load(sys.stdin); print('Created task id:', d.get('id','FAIL'))"
```

### Курсы
```bash
# Список курсов
curl -s https://zhanfinance.fly.dev/api/courses \
  -H "Authorization: Bearer $TOKEN" | python3 -c "import json,sys; d=json.load(sys.stdin); print('Courses:', len(d) if isinstance(d,list) else d)"

# Создать курс
curl -s -X POST https://zhanfinance.fly.dev/api/admin/courses \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"title":"Тест курс","description":"Тест","isPublished":false}' \
  | python3 -c "import json,sys; d=json.load(sys.stdin); print('Created course id:', d.get('id','FAIL'), d.get('message',''))"
```

### Документы
```bash
# Список документов
curl -s https://zhanfinance.fly.dev/api/documents \
  -H "Authorization: Bearer $TOKEN" | python3 -c "import json,sys; d=json.load(sys.stdin); print('Docs:', len(d) if isinstance(d,list) else d)"
```

### WebSocket
Открой браузер на https://zhanfinance.fly.dev, залогинься, открой DevTools → Network → WS.
Проверь что соединение устанавливается (статус 101).

## Итоговый отчёт

Выдай таблицу:

| Фича | Статус | Примечание |
|------|--------|------------|
| Логин | ✅/❌ | |
| Список задач | ✅/❌ | |
| Создание задачи | ✅/❌ | |
| Список курсов | ✅/❌ | |
| Создание курса | ✅/❌ | |
| Создание урока | ✅/❌ | |
| Загрузка файла | ✅/❌ | |
| Скачивание файла | ✅/❌ | |
| АВР генерация | ✅/❌ | |
| Аватарки | ✅/❌ | |
| WebSocket/Chat | ✅/❌ | |
| Назначение куратора | ✅/❌ | |
| Сортировка модулей | ✅/❌ | |

Для каждого ❌ — укажи HTTP статус и сообщение об ошибке.
Передай отчёт мне — я определю что чинить следующим.

## Важно

Если в процессе проверки видишь в логах:
- `OOM` / `Out of memory` → немедленно сообщи мне
- `HikariPool` connection errors → немедленно сообщи мне  
- `FlywayException` → немедленно сообщи мне

НЕ пытайся чинить эти проблемы самостоятельно.
