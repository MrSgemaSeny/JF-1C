# P0 Implementation Plan — ZhanFinance JF-1C
> Основан на анализе реального кода (backend.zip + frontend.zip, 27.07.2026)

---

## Статус проекта (что работает сейчас)

- ✅ Spring Boot запускается, подключается к Fly Postgres
- ✅ Flyway миграции применяются (V1–V107)
- ✅ Фронтенд деплоится на GitHub Pages
- ✅ `server.address=0.0.0.0` — Fly proxy видит приложение
- ⚠️ CORS не пропускает `mrsgemaseny.github.io` (нужен секрет)
- ❌ `V107__Seed_1C_Course` падает каждый рестарт (баг `is_published`)
- ❌ `isPreFinal` отсутствует в `StageDto` на фронтенде
- ❌ `ddl-auto=update` вместо `validate` (риск в проде)

---

## Задача 1 — Исправить баг `is_published` в миграции (КРИТИЧНО)

**Причина:** `V107` делает `INSERT INTO courses` без колонки `is_published`,  
а в таблице `courses` есть `NOT NULL` колонка `is_published` которую создал Hibernate через `ddl-auto=update` раньше.  
Entity `Course` не имеет поля `is_published` — только `status` (`VARCHAR`).  
Значит `is_published` — это мусорная колонка которую Hibernate добавил когда-то давно.

**Решение:** Создать миграцию `V108` которая дропает эту колонку.

```sql
-- V108__Remove_Orphan_Is_Published_From_Courses.sql
ALTER TABLE courses DROP COLUMN IF EXISTS is_published;
```

**Файл:** `zhan-finance-backend/src/main/resources/db/migration/V108__Remove_Orphan_Is_Published_From_Courses.sql`

---

## Задача 2 — Переключить `ddl-auto` на `validate`

**Файл:** `zhan-finance-backend/src/main/resources/application.properties`

**Изменить строку:**
```properties
# БЫЛО:
spring.jpa.hibernate.ddl-auto=update

# СТАЛО:
spring.jpa.hibernate.ddl-auto=validate
```

**Почему важно:** `update` может добавлять/удалять колонки при рестарте.  
В проде это опасно — именно так появилась `is_published`. Flyway управляет схемой, Hibernate только проверяет.

**⚠️ Важно:** сделать ПОСЛЕ того как `V108` применится. Порядок: сначала деплой с `V108` + `update`, потом меняешь на `validate` и деплоишь снова.

---

## Задача 3 — Добавить `isPreFinal` в `StageDto` на фронтенде

**Причина:** Бэкенд возвращает `isPreFinal` в StageDto (поле есть в `V38__Add_Is_Pre_Final_To_Stages.sql`), но фронтенд не знает об этом поле → кнопки принятия/отклонения у клиента не работают корректно.

**Файл:** `zhan-finance-frontend/src/entities/task/model/types.ts`

**Изменить `StageDto`:**
```typescript
export interface StageDto {
  id: number;
  pipelineId: number;
  name: string;
  nameEn?: string;
  orderIndex: number;
  color?: string;
  type: StageType;
  isDefault: boolean;
  slaHours?: number;
  isPreFinal?: boolean;  // ← ДОБАВИТЬ ЭТУ СТРОКУ
}
```

---

## Задача 4 — Исправить CORS на Fly.io

**Причина:** Фронтенд живёт на `https://mrsgemaseny.github.io` (origin без `/JF-1C`),  
но дефолт в `application.properties` содержит только `https://mrsgemaseny.github.io` без trailing slash.  
Проблема в том что Fly.io не подхватывает дефолт — нужен явный секрет.

**Выполнить в терминале:**
```bash
fly secrets set CORS_ALLOWED_ORIGINS="https://mrsgemaseny.github.io,https://mrsgemaseny.github.io/JF-1C" -a zhanfinance
```

---

## Задача 5 — Kanban: убрать `stage_position` из DnD логики

**Анализ кода:** `TaskKanbanBoard.tsx` использует `arrayMove` для сортировки внутри колонки,  
но бэкенд не сохраняет `stage_position` при drag-and-drop. Значит после F5 порядок сбрасывается.  
Поле `stage_position` в БД существует но не используется — мёртвый код.

**Решение:** Оставить DnD только для смены колонки (статуса). Убрать внутриколоночную сортировку.

**Файл:** `zhan-finance-frontend/src/widgets/task-board/TaskKanbanBoard.tsx`

Найти функцию `onDragEnd` и убрать блок с `arrayMove` для случая когда `activeContainer === overContainer`:

```typescript
// БЫЛО (примерно):
function onDragEnd(event: DragEndEvent) {
  const { active, over } = event;
  if (!over) { setActiveTask(null); return; }
  
  const activeContainer = findContainer(active.id);
  const overContainer = findContainer(over.id);
  
  if (activeContainer === overContainer) {
    // ← УБРАТЬ ЭТОТ БЛОК (arrayMove внутри колонки)
    setColumns(prev => ({
      ...prev,
      [activeContainer]: arrayMove(...)
    }));
  } else {
    // Смена колонки — ОСТАВИТЬ
    updateTaskStage(...)
  }
  setActiveTask(null);
}
```

---

## Задача 6 — Пагинация для табличного вида (НЕ для Kanban)

**Контекст:** Бэкенд уже имеет метод `getAllTasksPaged()` в `TaskService`.  
`TaskController` на `GET /api/crm/tasks` возвращает `List<TaskDto>` (не пагинированный).

**Шаг 6.1 — Бэкенд:** Обновить эндпоинт `GET /api/crm/tasks` чтобы поддерживал параметры `page` и `size`.

**Файл:** `zhan-finance-backend/src/main/java/.../crm/controller/TaskController.java`

```java
@GetMapping
public ResponseEntity<ApiResponse<Page<TaskDto>>> getAllTasks(
    @RequestParam(required = false) Long clientId,
    @RequestParam(required = false) Long assignedToId,
    @RequestParam(required = false) Long stageId,
    @RequestParam(required = false) Boolean unassigned,
    @RequestParam(defaultValue = "0") int page,
    @RequestParam(defaultValue = "500") int size,  // 500 = дефолт для Kanban
    CustomUserPrincipal principal
) {
    return ResponseEntity.ok(ApiResponse.success(
        taskService.getAllTasksPaged(clientId, assignedToId, stageId, unassigned, page, size)
    ));
}
```

**Шаг 6.2 — Фронтенд:** Добавить тип `PageResponse` и обновить `taskApi.ts`.

**Файл:** `zhan-finance-frontend/src/entities/task/model/types.ts`

```typescript
// Добавить в конец файла:
export interface PageResponse<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  number: number;      // текущая страница
  size: number;
}
```

**Файл:** `zhan-finance-frontend/src/entities/task/api/taskApi.ts`

```typescript
// Обновить функцию getTasks:
export async function getTasks(filter?: TaskFilter & { page?: number; size?: number }): Promise<PageResponse<TaskDto>> {
  const query = new URLSearchParams();
  if (filter?.stageId) query.append('stageId', filter.stageId.toString());
  if (filter?.clientId) query.append('clientId', filter.clientId.toString());
  if (filter?.assignedToId) query.append('assignedToId', filter.assignedToId.toString());
  if (filter?.unassigned) query.append('unassigned', 'true');
  if (filter?.page !== undefined) query.append('page', filter.page.toString());
  if (filter?.size !== undefined) query.append('size', filter.size.toString());

  const queryString = query.toString() ? `?${query.toString()}` : '';
  return apiRequest<PageResponse<TaskDto>>(`/api/crm/tasks${queryString}`);
}
```

**Шаг 6.3 — Компоненты:** Все страницы которые вызывают `getTasks` нужно обновить чтобы брали `.content`.

Файлы для обновления:
- `src/pages/dashboard/admin/AdminTasksPage.tsx`
- `src/pages/dashboard/employee/EmployeeTasksPage.tsx`  
- `src/pages/dashboard/shared/task-pool/TaskPoolPage.tsx`
- `src/widgets/task-board/TaskKanbanBoard.tsx` (уже получает `initialTasks: TaskDto[]` — родитель передаёт `.content`)

Паттерн обновления (везде одинаковый):
```typescript
// БЫЛО:
const tasks = await getTasks(filter);
// tasks — это TaskDto[]

// СТАЛО:
const response = await getTasks(filter);
const tasks = response.content;
// response.totalElements — для отображения "Всего: N задач"
```

---

## Задача 7 — Автоархивация завершённых задач (Scheduler)

**Когда делать:** После того как задачи 1-6 стабильно работают.

**Файл (новый):** `zhan-finance-backend/src/main/java/.../crm/service/TaskArchiveScheduler.java`

```java
@Component
@RequiredArgsConstructor
public class TaskArchiveScheduler {

    private final TaskRepository taskRepository;

    // Каждую ночь в 02:00
    @Scheduled(cron = "0 0 2 * * *")
    @Transactional
    public void archiveOldDoneTasks() {
        LocalDate threshold = LocalDate.now().minusDays(7);
        List<Task> toArchive = taskRepository.findDoneTasksOlderThan(threshold);
        toArchive.forEach(task -> task.setArchived(true));
        taskRepository.saveAll(toArchive);
    }
}
```

**Добавить в `TaskRepository`:**
```java
@Query("SELECT t FROM Task t WHERE t.status = 'DONE' AND t.closedAt < :threshold AND t.archived = false")
List<Task> findDoneTasksOlderThan(@Param("threshold") LocalDate threshold);
```

**Включить scheduling в главном классе:**
```java
@SpringBootApplication
@EnableScheduling  // ← ДОБАВИТЬ
public class ZhanFinanceBackendApplication { ... }
```

---

## Порядок выполнения

```
1. [СРОЧНО] fly secrets set CORS_ALLOWED_ORIGINS (задача 4)
2. Создать V108 миграцию (задача 1) → закоммитить → деплой
3. application.properties: ddl-auto=update → validate (задача 2) → деплой
4. frontend: добавить isPreFinal в StageDto (задача 3) → пуш
5. frontend: убрать arrayMove внутри колонки (задача 5) → пуш
6. backend: обновить TaskController на Page<> (задача 6.1) → деплой
7. frontend: добавить PageResponse тип + обновить getTasks + компоненты (задача 6.2, 6.3) → пуш
8. [ПОТОМ] TaskArchiveScheduler (задача 7)
```

---

## Подводные камни

**`ddl-auto=validate` может упасть** если Hibernate видит поле в Entity которого нет в БД или наоборот.  
Перед переключением проверь локально: подними локальный Postgres с той же схемой и запусти бэкенд.

**Пагинация сломает Kanban** если не передать `size=500` дефолтно.  
Kanban получает `initialTasks` от родителя — родитель должен передавать `size=500` при запросе для Kanban и `size=20` для таблиц.

**`@Scheduled` требует `@EnableScheduling`** — без этого крон-джоба просто не запустится и ошибки не будет.

**`stage_position` в БД** — поле остаётся, просто не используется фронтом. Не трогать — удаление потребует миграции и ничего не даст.
