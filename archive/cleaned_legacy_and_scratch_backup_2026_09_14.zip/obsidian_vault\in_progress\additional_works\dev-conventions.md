# JF-1C — Dev Conventions

> Стек: Spring Boot 3 + PostgreSQL + React 19 / FSD + Tailwind v4  
> Документ для нового члена команды и для себя через 3 месяца

---

## Зачем читать это первым

Кодовая база — это не только код. Это договорённости о том, как код пишется.
Нарушение этих договорённостей не сломает билд — но сделает поддержку болью.
Этот документ описывает как есть и как должно быть.

---

## Backend (Spring Boot 3)

### Структура модулей

Каждый модуль живёт в `modules/<name>/` и содержит строго:
```
modules/
  crm/
    controller/   ← только HTTP: маппинг запроса → сервис → ответ
    service/      ← бизнес-логика, @Transactional здесь
    repository/   ← только JPA-запросы
    entity/       ← JPA-сущности
    dto/          ← request/response объекты
    mapper/       ← конвертация entity ↔ dto
```

**Правило:** контроллер не содержит бизнес-логики. Сервис не знает о HTTP.  
Если сервис принимает `HttpServletRequest` — это ошибка архитектуры.

### Нейминг

| Что | Пример |
|-----|--------|
| Контроллер | `TaskController`, `InvoiceController` |
| Сервис | `TaskService`, `InvoiceService` |
| Access-сервис | `CrmAccessService`, `InvoiceAccessService` |
| Репозиторий | `TaskRepository` |
| DTO (запрос) | `TaskCreateRequest`, `TaskStageUpdateRequest` |
| DTO (ответ) | `TaskDto`, `ClientDto` |
| Mapper | `TaskMapper` |
| Entity | `Task`, `Invoice` (без суффикса `Entity`, кроме `ServiceEntity` — исторически) |

### Access-сервисы — отдельный слой авторизации

В проекте есть `CrmAccessService`, `InvoiceAccessService`, `DocumentAccessService`.  
Это паттерн «проверка прав на уровне данных» в дополнение к `@PreAuthorize` на роли.

**Правило:** `@PreAuthorize` проверяет роль (ADMIN/EMPLOYEE/CLIENT).  
Access-сервис проверяет: «этот конкретный пользователь имеет право на эту конкретную запись?»

```java
// Правильно: оба уровня
@GetMapping("/{id}")
@PreAuthorize("hasAnyRole('ADMIN', 'EMPLOYEE', 'CLIENT')")
public ApiResponse<TaskDto> getTask(@PathVariable Long id, @AuthenticationPrincipal UserPrincipal principal) {
    Task task = taskService.getTaskEntity(id);
    accessService.assertCanReadTask(principal.getUser(), task); // ← не пропускать
    return ApiResponse.success(taskMapper.mapToDto(task));
}
```

### ApiResponse — обёртка всех ответов

Все эндпоинты возвращают `ApiResponse<T>`. Никаких голых `ResponseEntity` без крайней необходимости.

```java
// Правильно
return ApiResponse.success(taskMapper.mapToDto(task));

// Неправильно
return ResponseEntity.ok(task);
```

### Обработка ошибок

Используй typed exceptions из `common/exception/`:

```java
throw new ResourceNotFoundException("Task not found: " + id);
throw new UnauthorizedException("Access denied");
throw new BadRequestException("Invalid stage transition");
throw new ConflictException("Email already registered");
```

`GlobalExceptionHandler` перехватит их и вернёт правильный HTTP-статус + `ErrorResponse`.  
Не бросай `RuntimeException` напрямую и не пиши `try/catch` в контроллерах.

### Транзакции

`@Transactional` только на сервисах. На репозиториях — только `readOnly = true` для select-методов.

```java
// Правильно
@Transactional(readOnly = true)
public List<TaskDto> getAllTasks(...) { ... }

@Transactional
public TaskDto createTask(...) { ... }
```

### Миграции базы данных

Flyway. Формат имени файла строгий:

```
V{номер}__{Описание_через_underscores}.sql
```

Примеры: `V101__Add_SLA_to_stages.sql`, `V102__Add_Teams.sql`

**Правила:**
- Номер монотонно растёт, пропуски допустимы
- Никогда не редактировать уже примененную миграцию
- Если ошибся — создаёшь новую миграцию с фиксом
- `CREATE INDEX CONCURRENTLY` — только в отдельной миграции (не в транзакции)
- `ddl-auto=validate` в prod — Hibernate только проверяет схему, не трогает её

### Тесты

Три уровня, все существуют в проекте:

| Тип | Пример | Запуск |
|-----|--------|--------|
| Unit | `AuthServiceUnitTests` — Mockito, без Spring | Быстро, < 1с |
| Integration | `TaskServiceIntegrationTests` — `@SpringBootTest` + реальная БД | Медленно, ~ 5с |
| Smoke | `ApiSmokeTests` — HTTP через MockMvc end-to-end | Средне, ~ 3с |

**Правило:** новая публичная бизнес-логика в сервисе → unit-тест обязателен.  
Новый эндпоинт с нетривиальной авторизацией → integration-тест.

---

## Frontend (React 19 + FSD + Tailwind v4)

### Feature-Sliced Design — слои и правила

```
src/
  shared/       ← утилиты, общие типы, http-клиент. Не знает о features.
  entities/     ← модели данных + API. Не знает о features/pages.
  features/     ← бизнес-логика + UI-фичи. Может использовать entities.
  pages/        ← страницы = сборка из features + entities.
  app/          ← роутинг, глобальные провайдеры.
  widgets/      ← (если появятся) крупные переиспользуемые блоки.
```

**Главное правило FSD:** импорт только вниз по слоям.  
`pages` → `features` → `entities` → `shared`. Никогда вверх.

```typescript
// Правильно: entities импортирует из shared
import { http } from '@/shared/api/http';

// Неправильно: entities импортирует из features
import { useTaskFilter } from '@/features/task/...'; // ← нарушение FSD
```

### Нейминг файлов

| Что | Формат | Пример |
|-----|--------|--------|
| Компонент | `PascalCase.tsx` | `TaskKanbanBoard.tsx` |
| Хук | `camelCase.ts` | `useTaskFilter.ts` |
| API-слой | `camelCaseApi.ts` | `taskApi.ts` |
| Типы | `types.ts` | `entities/task/model/types.ts` |
| Запросы | `camelCaseQueries.ts` | `pipelineQueries.ts` |

### API-слой

Все запросы к бекенду — через `shared/api/http.ts`. Никаких прямых `fetch` или `axios` в компонентах.

```typescript
// entities/task/api/taskApi.ts
import { http } from '@/shared/api/http';
import type { TaskDto } from '../model/types';

export const taskApi = {
  getAll: () => http.get<TaskDto[]>('/api/crm/tasks'),
  getById: (id: number) => http.get<TaskDto>(`/api/crm/tasks/${id}`),
  create: (data: TaskCreateRequest) => http.post<TaskDto>('/api/crm/tasks', data),
};
```

### Типы — всегда в `model/types.ts`

Если у сущности есть `entities/task/` — её типы в `entities/task/model/types.ts`.  
Не дублировать типы между `entities` и `features`.

```typescript
// entities/task/model/types.ts
export interface TaskDto {
  id: number;
  title: string;
  stageId: number;
  isPreFinal: boolean; // ← это поле ОБЯЗАНО быть здесь (сейчас его нет — баг)
  // ...
}
```

### Компоненты

- Один компонент = один файл
- Не писать компоненты > 300 строк. Если больше — декомпозируй
- Props interface над компонентом, не инлайн

```typescript
interface TaskCardProps {
  task: TaskDto;
  onStageChange: (taskId: number, stageId: number) => void;
}

export function TaskCard({ task, onStageChange }: TaskCardProps) {
  // ...
}
```

### Tailwind v4

- Утилитарные классы прямо в JSX — это нормально
- Не создавать кастомные CSS-файлы для одиночных компонентов
- Если стиль повторяется 3+ раза — выноси в `@apply` или в компонент

---

## Git и PR

### Ветки

```
main          ← только через PR, деплоится на Fly.io автоматически
feature/...   ← новая функциональность
fix/...       ← баг-фикс
refactor/...  ← рефакторинг без изменения поведения
chore/...     ← зависимости, конфиг, документация
```

### Коммиты

Формат: `<тип>: <описание на русском или английском>`

```
feat: добавить SLA-таймер на стадии
fix: исправить N+1 в TaskMapper.mapToDto
refactor: перенести логику доступа из TaskController в CrmAccessService
chore: обновить Flyway до 10.x
```

### Чеклист перед PR

- [ ] Тесты написаны или обновлены
- [ ] Миграция создана (если менялась схема БД)
- [ ] `isPreFinal` и другие DTO-поля синхронизированы с бекендом
- [ ] Нет `console.log` в коде фронтенда
- [ ] Нет закомментированного кода (удали или создай TODO с тикетом)

---

## Переменные окружения

Все секреты — только в `.env` (локально) или в Fly.io secrets (прод).  
Никогда не коммитить `.env` в репозиторий.

```bash
# Что должно быть в Fly.io secrets
JWT_SECRET
JWT_ACCESS_TOKEN_EXPIRATION_MS
JWT_REFRESH_TOKEN_EXPIRATION_MS
DB_URL
DB_USERNAME
DB_PASSWORD
MAIL_USERNAME
MAIL_PASSWORD
GOOGLE_CLIENT_ID
```

Для фронтенда: переменные с префиксом `VITE_` попадают в бандл — не клади туда секреты.
