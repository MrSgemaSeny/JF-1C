# План обучения и внедрения 1С в JF-1C (ZhanFinance)

> **Стек:** Spring Boot 3 / Java 17 / PostgreSQL / Flyway · React 19 / FSD · Fly.io + GitHub Actions CI/CD  
> **Профиль:** соло-разработчик, нет опыта 1С, есть опыт REST API, JWT, WebSocket, Docker  
> **Цель MVP:** двусторонняя синхронизация `ClientProfile` ↔ `Контрагент` + `InvoiceService` → `СчетНаОплату` в 1С

---

## Фазы плана

```
ФАЗА 0 → ФАЗА 1 → ФАЗА 2 → ФАЗА 3 → ФАЗА 4
Среда     Язык    API 1С   Spring   Прод-прод
(3 дня)  (3 дня) (4 дня)  (3 дня)  (2 дня)
```

Итого: **~15 рабочих дней** (не календарных, считая по 4–5 ч/день вечерами)

---

## ФАЗА 0 — Локальная среда (3 дня)

**Цель:** 1С запущена, опубликована на Apache, отвечает на HTTP-запросы.

### День 1 — Установка платформы

- [ ] Скачать **1С:Предприятие 8.3 учебная версия** с `https://v8.1c.ru/platforma/`  
  _(бесплатно, не требует ключа защиты, лимит базы 1 ГБ — для MVP хватит)_
- [ ] Установить платформу; запустить ярлык **«1С:Предприятие»**
- [ ] Создать **новую файловую базу** без конфигурации (пустую):  
  `Добавить → Создание новой ИБ → Создание ИБ без конфигурации → путь на диске`
- [ ] Убедиться, что база открывается в режиме **Конфигуратор**

### День 2 — Apache + публикация

- [ ] Установить **Apache 2.4** (Windows: [Apache Lounge](https://www.apachelounge.com/download/))
- [ ] Проверить, что `http://localhost` открывается (страница Apache)
- [ ] Открыть базу в **Конфигураторе от имени Администратора**
- [ ] `Администрирование → Публикация на веб-сервере`:
  - Имя: `jfbase`
  - Каталог Apache: путь до `htdocs`
  - ✅ «Публиковать стандартный интерфейс OData»
  - ✅ «Публиковать HTTP-сервисы»
  - Нажать **Опубликовать**
- [ ] Перезапустить Apache (`services.msc → Apache2.4 → Restart`)
- [ ] Smoke-тест в браузере / Postman:
  ```
  GET http://localhost/jfbase/odata/standard.odata/$metadata
  Authorization: Basic YWRtaW46  (admin:пустой пароль, base64)
  ```
  Ожидаемый ответ: огромный XML со структурой базы → среда готова.

### День 3 — Базовая навигация в Конфигураторе

- [ ] Изучить дерево метаданных слева:  
  `Справочники / Документы / Регистры накопления / Регистры сведений / HTTP-сервисы`
- [ ] Добавить пустой **Справочник** `Тест` через правый клик → Добавить → убедиться, что он появился в OData:  
  ```
  GET http://localhost/jfbase/odata/standard.odata/Catalog_Тест?$format=json
  ```
- [ ] Удалить тестовый справочник. Дерево метаданных — понятно.

---

## ФАЗА 1 — Язык 1С (3 дня)

**Цель:** читать и писать код на встроенном языке 1С на уровне, достаточном для HTTP-сервисов.

### Что нужно знать (и только это — для задачи интеграции)

| Конструкция 1С | Аналог в Java/JS |
|---|---|
| `Новый Структура` | `new HashMap<>()` / `{}` |
| `Структура.Вставить("key", val)` | `map.put("key", val)` |
| `Если ... Тогда ... КонецЕсли` | `if (...) { }` |
| `Для Каждого Эл Из Коллекция Цикл` | `for (var el : collection)` |
| `Справочники.Контрагенты.НайтиПоРеквизиту("Код", "123")` | `repo.findByCode("123")` |
| `Запрос = Новый Запрос; Запрос.Текст = "ВЫБРАТЬ ..."` | `EntityManager.createQuery(...)` |
| `ЗаписьJSON / ЧтениеJSON` | `ObjectMapper` |
| `HTTPСервисОтвет(200)` | `ResponseEntity.ok(...)` |

### День 4 — Синтаксис и типы

- [ ] Открыть конфигуратор → **Общие → Общие модули** → добавить модуль `ЮнитТест`
- [ ] Написать и выполнить (`F5` или через меню Отладка) простейший код:
  ```bsl
  // Переменные и типы
  Строка = "ZhanFinance";
  Число  = 42;
  Флаг   = Истина;
  
  // Структура (аналог Map)
  Данные = Новый Структура;
  Данные.Вставить("name", Строка);
  Данные.Вставить("amount", Число);
  
  // Массив
  Список = Новый Массив;
  Список.Добавить("client_1");
  Список.Добавить("client_2");
  
  // Условие и цикл
  Для Каждого Элемент Из Список Цикл
      Если Элемент = "client_1" Тогда
          Сообщить("Нашли: " + Элемент);
      КонецЕсли;
  КонецЦикла;
  ```
- [ ] Убедиться в выводе сообщений в окне сообщений конфигуратора.

### День 5 — JSON в 1С (критично для интеграции)

- [ ] Изучить сериализацию:
  ```bsl
  // Сериализация структуры в JSON-строку
  Данные = Новый Структура;
  Данные.Вставить("clientId", "uuid-123");
  Данные.Вставить("amount", 15000);
  
  ЗаписьJSON = Новый ЗаписьJSON;
  ЗаписьJSON.УстановитьСтроку();
  ЗаписатьJSON(ЗаписьJSON, Данные);
  СтрокаJSON = ЗаписьJSON.Закрыть();
  // → {"clientId":"uuid-123","amount":15000}
  ```
- [ ] Изучить десериализацию (входящий запрос от Spring Boot):
  ```bsl
  // Входящая строка JSON → Структура
  ТелоЗапроса = "{""clientId"":""uuid-123"",""amount"":15000}";
  
  ЧтениеJSON = Новый ЧтениеJSON;
  ЧтениеJSON.УстановитьСтроку(ТелоЗапроса);
  Данные = ПрочитатьJSON(ЧтениеJSON);
  ЧтениеJSON.Закрыть();
  
  Сообщить(Данные.clientId);   // uuid-123
  Сообщить(Данные.amount);     // 15000
  ```
- [ ] Обратить внимание: строки в 1С экранируются удвоением кавычек `""`, не `\"`

### День 6 — Запросы к базе 1С

- [ ] Создать справочник **Контрагенты** с реквизитом `ИдентификаторCRM` (Строка, 36):
  ```
  Справочники → Правый клик → Добавить
  Имя: Контрагенты
  Реквизиты → Добавить: ИдентификаторCRM (Тип: Строка, 36)
  ```
- [ ] Добавить тестовый элемент в базе (режим «1С:Предприятие», не Конфигуратор)
- [ ] Написать и выполнить запрос:
  ```bsl
  // Запрос к справочнику (аналог JPQL/HQL)
  Запрос = Новый Запрос;
  Запрос.Текст =
      "ВЫБРАТЬ
      |   Контрагенты.Наименование КАК Наименование,
      |   Контрагенты.ИдентификаторCRM КАК CrmId
      |ИЗ
      |   Справочник.Контрагенты КАК Контрагенты
      |ГДЕ
      |   Контрагенты.ИдентификаторCRM = &CrmId";
  
  Запрос.УстановитьПараметр("CrmId", "uuid-123");
  Результат = Запрос.Выполнить();
  Выборка  = Результат.Выбрать();
  
  Пока Выборка.Следующий() Цикл
      Сообщить(Выборка.Наименование);
  КонецЦикла;
  ```
- [ ] Язык 1С для задач интеграции — освоен.

---

## ФАЗА 2 — Кастомные HTTP-сервисы в 1С (4 дня)

**Цель:** создать API, идентичное тому, что ожидает `OneCIntegrationService` в Spring Boot.

### Структура API (контракт между Spring Boot и 1С)

```
POST /hs/jf/v1/clients        ← создать/обновить Контрагента
POST /hs/jf/v1/invoices       ← создать СчетНаОплату и провести его
GET  /hs/jf/v1/ping           ← health-check
```

`/hs/` — фиксированный префикс 1С для HTTP-сервисов. `jf` — корневой URL сервиса.

### День 7 — Создание HTTP-сервиса и Ping

- [ ] В конфигураторе: `Общие → HTTP-сервисы → Правый клик → Добавить`
  - Имя: `JFApi`
  - Корневой URL: `jf`
- [ ] Внутри сервиса: `Шаблоны URL → Добавить`
  - Имя: `Ping`, Шаблон: `/v1/ping`
- [ ] В шаблоне: `Методы → Добавить`, HTTP-метод: `GET`
- [ ] В свойствах метода: `Обработчик` → нажать лупу → создать обработчик:
  ```bsl
  Функция PingGET(Запрос)
      Ответ = Новый HTTPСервисОтвет(200);
      Ответ.Заголовки.Вставить("Content-Type", "application/json");
      Ответ.УстановитьТелоИзСтроки(
          "{""status"":""ok"",""service"":""jf-1c""}",
          КодировкаТекста.UTF8,
          ИспользованиеByteOrderMark.НеИспользовать
      );
      Возврат Ответ;
  КонецФункции
  ```
- [ ] `F7` (обновить конфигурацию БД) → переопубликовать Apache
- [ ] Проверить в Postman:
  ```
  GET http://localhost/jfbase/hs/jf/v1/ping
  Authorization: Basic YWRtaW46
  → {"status":"ok","service":"jf-1c"}
  ```

### День 8 — Эндпоинт `POST /clients`

Принимает JSON от Spring Boot, создаёт или обновляет Контрагента в 1С.

- [ ] Добавить шаблон URL `/v1/clients`, метод `POST`, обработчик:
  ```bsl
  Функция ClientsPOST(Запрос)
      // 1. Десериализация
      ЧтениеJSON = Новый ЧтениеJSON;
      ЧтениеJSON.УстановитьСтроку(Запрос.ПолучитьТелоКакСтроку(КодировкаТекста.UTF8));
      Данные = ПрочитатьJSON(ЧтениеJSON);
      ЧтениеJSON.Закрыть();
      
      Если НЕ ЗначениеЗаполнено(Данные.crmId) Тогда
          Возврат НовыйОтветОшибки(400, "crmId обязателен");
      КонецЕсли;
      
      // 2. Upsert: ищем по crmId, создаём если не найден
      СсылкаКА = Справочники.Контрагенты.НайтиПоРеквизиту("ИдентификаторCRM", Данные.crmId);
      
      Если СсылкаКА.Пустая() Тогда
          ОбъектКА = Справочники.Контрагенты.СоздатьЭлемент();
      Иначе
          ОбъектКА = СсылкаКА.ПолучитьОбъект();
      КонецЕсли;
      
      // 3. Заполняем реквизиты
      ОбъектКА.Наименование        = Данные.fullName;
      ОбъектКА.ИдентификаторCRM    = Данные.crmId;
      ОбъектКА.Записать();
      
      // 4. Возвращаем GUID созданного объекта
      Ответ = Новый HTTPСервисОтвет(201);
      Ответ.Заголовки.Вставить("Content-Type", "application/json");
      Ответ.УстановитьТелоИзСтроки(
          "{""onecGuid"":""" + ОбъектКА.Ссылка.УникальныйИдентификатор() + """}",
          КодировкаТекста.UTF8,
          ИспользованиеByteOrderMark.НеИспользовать
      );
      Возврат Ответ;
  КонецФункции
  
  // Хелпер для ошибочных ответов
  Функция НовыйОтветОшибки(КодСтатуса, Сообщение)
      Ответ = Новый HTTPСервисОтвет(КодСтатуса);
      Ответ.Заголовки.Вставить("Content-Type", "application/json");
      Ответ.УстановитьТелоИзСтроки(
          "{""error"":""" + Сообщение + """}",
          КодировкаТекста.UTF8,
          ИспользованиеByteOrderMark.НеИспользовать
      );
      Возврат Ответ;
  КонецФункции
  ```
- [ ] Проверить в Postman:
  ```json
  POST http://localhost/jfbase/hs/jf/v1/clients
  Authorization: Basic YWRtaW46
  Content-Type: application/json
  
  { "crmId": "550e8400-e29b-41d4-a716-446655440000", "fullName": "ООО Тест" }
  ```
  Ожидаемый ответ `201` с `onecGuid`.

### День 9 — Эндпоинт `POST /invoices`

- [ ] Создать справочник **Услуги** (если нет в конфигурации). В реальной 1С:УНФ он уже есть.
- [ ] Добавить пустой Документ **СчетНаОплату** (если база пустая):
  ```
  Документы → Добавить
  Имя: СчетНаОплату
  Реквизиты: Контрагент (тип: СправочникСсылка.Контрагенты), Сумма (Число)
  Реквизиты: ИдентификаторCRM (Строка, 36) — для idempotency
  ```
- [ ] Шаблон `/v1/invoices`, метод `POST`:
  ```bsl
  Функция InvoicesPOST(Запрос)
      ЧтениеJSON = Новый ЧтениеJSON;
      ЧтениеJSON.УстановитьСтроку(Запрос.ПолучитьТелоКакСтроку(КодировкаТекста.UTF8));
      Данные = ПрочитатьJSON(ЧтениеJSON);
      ЧтениеJSON.Закрыть();
      
      // Idempotency: не создавать дубль, если уже есть
      СуществующийСчет = Документы.СчетНаОплату.НайтиПоРеквизиту("ИдентификаторCRM", Данные.invoiceId);
      Если НЕ СуществующийСчет.Пустая() Тогда
          Ответ = Новый HTTPСервисОтвет(200);
          Ответ.УстановитьТелоИзСтроки(
              "{""onecGuid"":""" + СуществующийСчет.УникальныйИдентификатор() + """,""duplicate"":true}",
              КодировкаТекста.UTF8, ИспользованиеByteOrderMark.НеИспользовать
          );
          Возврат Ответ;
      КонецЕсли;
      
      // Находим контрагента по crmId
      СсылкаКА = Справочники.Контрагенты.НайтиПоРеквизиту("ИдентификаторCRM", Данные.crmId);
      Если СсылкаКА.Пустая() Тогда
          Возврат НовыйОтветОшибки(404, "Контрагент не найден: " + Данные.crmId);
      КонецЕсли;
      
      // Создаём и проводим счёт
      НовыйСчет = Документы.СчетНаОплату.СоздатьДокумент();
      НовыйСчет.Дата            = ТекущаяДата();
      НовыйСчет.Контрагент      = СсылкаКА;
      НовыйСчет.Сумма           = Данные.amount;
      НовыйСчет.ИдентификаторCRM = Данные.invoiceId;
      НовыйСчет.Записать(РежимЗаписиДокумента.Проведение);
      
      Ответ = Новый HTTPСервисОтвет(201);
      Ответ.Заголовки.Вставить("Content-Type", "application/json");
      Ответ.УстановитьТелоИзСтроки(
          "{""onecGuid"":""" + НовыйСчет.Ссылка.УникальныйИдентификатор() + """}",
          КодировкаТекста.UTF8, ИспользованиеByteOrderMark.НеИспользовать
      );
      Возврат Ответ;
  КонецФункции
  ```

### День 10 — Отладка HTTP-сервисов

- [ ] Включить отладчик 1С: `Отладка → Подключиться к отладчику` → выбрать базу
- [ ] Поставить breakpoint в `ClientsPOST`, выполнить запрос из Postman → войти в пошаговый дебаг
- [ ] Проверить обработку некорректных запросов (пустое тело, несуществующий `crmId`)
- [ ] API 1С — полностью готово к подключению Spring Boot

---

## ФАЗА 3 — Интеграция со Spring Boot (3 дня)

**Цель:** `OneCIntegrationService` в Spring Boot стучится в локальную 1С, всё работает end-to-end.

### День 11 — `application-local.yml` и `OneCProperties`

```yaml
# application-local.yml
onec:
  base-url: http://localhost/jfbase/hs/jf/v1
  username: admin
  password: ""         # пустой пароль учебной версии
  enabled: true
```

```java
// config/OneCProperties.java
@ConfigurationProperties(prefix = "onec")
@Validated
public record OneCProperties(
    @NotBlank String baseUrl,
    @NotBlank String username,
    String password,
    boolean enabled
) {}
```

```java
// config/OneCWebClientConfig.java
@Configuration
@EnableConfigurationProperties(OneCProperties.class)
public class OneCWebClientConfig {

    @Bean
    public WebClient oneCWebClient(OneCProperties props) {
        String credentials = Base64.getEncoder().encodeToString(
            (props.username() + ":" + props.password()).getBytes(StandardCharsets.UTF_8)
        );
        return WebClient.builder()
            .baseUrl(props.baseUrl())
            .defaultHeader(HttpHeaders.AUTHORIZATION, "Basic " + credentials)
            .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .build();
    }
}
```

### День 12 — `OneCIntegrationService`

```java
// integration/onec/dto/OneCClientDto.java
public record OneCClientDto(String crmId, String fullName) {}

// integration/onec/dto/OneCInvoiceDto.java
public record OneCInvoiceDto(
    String invoiceId,   // UUID из JF-1C — для idempotency
    String crmId,       // UUID клиента из ClientProfile
    BigDecimal amount,
    String description
) {}

// integration/onec/dto/OneCCreatedDto.java
public record OneCCreatedDto(String onecGuid, Boolean duplicate) {}
```

```java
// integration/onec/OneCIntegrationService.java
@Service
@RequiredArgsConstructor
@Slf4j
public class OneCIntegrationService {

    private final WebClient oneCWebClient;
    private final OneCProperties props;

    // Upsert контрагента: вызывается из ClientService при регистрации/обновлении CLIENT
    public Optional<String> syncClient(OneCClientDto dto) {
        if (!props.enabled()) return Optional.empty();

        return oneCWebClient.post()
            .uri("/clients")
            .bodyValue(dto)
            .retrieve()
            .onStatus(status -> status.is4xxClientError(), resp ->
                resp.bodyToMono(String.class)
                    .flatMap(body -> Mono.error(new OneCClientException("4xx от 1С: " + body)))
            )
            .bodyToMono(OneCCreatedDto.class)
            .map(OneCCreatedDto::onecGuid)
            .doOnError(e -> log.error("1С syncClient error: {}", e.getMessage()))
            .onErrorReturn(null)
            .blockOptional();
    }

    // Создать счёт: вызывается из InvoiceService.createInvoice()
    public Optional<String> pushInvoice(OneCInvoiceDto dto) {
        if (!props.enabled()) return Optional.empty();

        return oneCWebClient.post()
            .uri("/invoices")
            .bodyValue(dto)
            .retrieve()
            .onStatus(status -> !status.is2xxSuccessful(), resp ->
                resp.bodyToMono(String.class)
                    .flatMap(body -> Mono.error(new OneCClientException("Ошибка 1С: " + body)))
            )
            .bodyToMono(OneCCreatedDto.class)
            .map(OneCCreatedDto::onecGuid)
            .doOnSuccess(guid -> log.info("Invoice pushed to 1С, guid={}", guid))
            .doOnError(e -> log.error("1С pushInvoice error: {}", e.getMessage()))
            .onErrorReturn(null)
            .blockOptional();
    }
}
```

### День 13 — Подключение к существующим сервисам JF-1C

**Точка 1: `ClientService` или `AuthService`**

```java
// В ClientService.createOrUpdateProfile() — добавить после сохранения в PostgreSQL:
Optional<String> onecGuid = oneCIntegrationService.syncClient(
    new OneCClientDto(client.getId().toString(), client.getFullName())
);
onecGuid.ifPresent(guid -> {
    client.setOnecGuid(guid);
    clientRepository.save(client);
});
```

Добавить миграцию Flyway:
```sql
-- V110__add_onec_guid_to_client_profiles.sql
ALTER TABLE client_profiles ADD COLUMN onec_guid VARCHAR(36);
```

**Точка 2: `InvoiceService.createInvoice()`**

```java
// После invoice = invoiceRepository.save(invoice):
oneCIntegrationService.pushInvoice(new OneCInvoiceDto(
    invoice.getId().toString(),
    invoice.getClient().getId().toString(),
    invoice.getAmount(),
    invoice.getDescription()
));
```

**Финальный тест:**
- [ ] Запустить Spring Boot локально (`./mvnw spring-boot:run -Dspring.profiles.active=local`)
- [ ] Зарегистрировать нового CLIENT через React UI
- [ ] В 1С (режим Предприятие) открыть список Контрагентов → новый контрагент появился
- [ ] Создать счёт через Billing-модуль → документ появился в 1С

---

## ФАЗА 4 — Прод-конфигурация (2 дня)

**Цель:** интеграция работает на Fly.io против облачной 1С.

### День 14 — Туннель для разработки (ngrok)

Пока 1С локальная, а Spring Boot на Fly.io:

```bash
# Установить ngrok: https://ngrok.com/download
ngrok http 80   # пробрасываем Apache наружу
# Получаем: https://xxxx.ngrok-free.app
```

В Fly.io secrets:
```bash
flyctl secrets set ONEC_BASE_URL=https://xxxx.ngrok-free.app/jfbase/hs/jf/v1
flyctl secrets set ONEC_USERNAME=admin
flyctl secrets set ONEC_PASSWORD=
flyctl secrets set ONEC_ENABLED=true
```

В `application.yml` (прод):
```yaml
onec:
  base-url: ${ONEC_BASE_URL}
  username: ${ONEC_USERNAME}
  password: ${ONEC_PASSWORD:}
  enabled: ${ONEC_ENABLED:false}
```

### День 15 — Отказоустойчивость

Добавить `Resilience4j` для retry при временной недоступности 1С:

```xml
<!-- pom.xml -->
<dependency>
    <groupId>io.github.resilience4j</groupId>
    <artifactId>resilience4j-spring-boot3</artifactId>
</dependency>
```

```yaml
# application.yml
resilience4j:
  retry:
    instances:
      onecSync:
        max-attempts: 3
        wait-duration: 2s
        retry-exceptions:
          - org.springframework.web.reactive.function.client.WebClientRequestException
```

```java
@Retry(name = "onecSync")
public Optional<String> syncClient(OneCClientDto dto) { ... }
```

---

## JSON-контракт (финальный)

### `POST /hs/jf/v1/clients`

```json
// Request (Spring Boot → 1С)
{ "crmId": "uuid", "fullName": "ООО Альфа" }

// Response 201
{ "onecGuid": "1c-uuid" }

// Response 404
{ "error": "Контрагент не найден" }
```

### `POST /hs/jf/v1/invoices`

```json
// Request
{ "invoiceId": "uuid", "crmId": "uuid", "amount": 50000, "description": "Услуга бухгалтера" }

// Response 201
{ "onecGuid": "1c-uuid", "duplicate": false }

// Response 200 (idempotent repeat)
{ "onecGuid": "1c-uuid", "duplicate": true }
```

---

## Чеклист MVP (Definition of Done)

- [ ] Фаза 0: `GET /ping` возвращает 200 из локальной 1С
- [ ] Фаза 1: умею читать/писать код на языке 1С, JSON туда-обратно работает
- [ ] Фаза 2: Postman-тесты `POST /clients` и `POST /invoices` — зелёные
- [ ] Фаза 3: новый CLIENT в React → появляется в 1С; счёт в Billing → проводится в 1С
- [ ] Фаза 4: `onec.enabled=false` переключает интеграцию без ошибок; retry работает
- [ ] Добавлена Flyway-миграция `V110__add_onec_guid_to_client_profiles.sql`
- [ ] CI/CD не сломан после добавления новых env-переменных

---

## Что оставить на после MVP

- Webhook из 1С → Spring Boot при изменении статуса оплаты счёта
- Синхронизация налогового календаря 1С → задачи в Kanban
- Полная двусторонняя модификация данных клиента
- Перенос исторических данных из 1С в PostgreSQL
