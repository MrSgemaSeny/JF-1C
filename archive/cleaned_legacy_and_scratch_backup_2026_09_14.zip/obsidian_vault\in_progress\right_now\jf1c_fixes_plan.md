# Архитектурный план исправлений — Валидация, i18n, Загрузка файлов и Строгие статусы регистрации

---

## 1. Валидация Email (Frontend & Backend)

### Теория и уязвимости текущего подхода
Текущая ошибка в браузере (*"В адресе "new_user" отсутствует символ "@"..."*) вызывается нативным валидатором браузера HTML5 или самописным проверщиком строк.
- **Проблема нативного HTML5 / кастомных regex**: Браузерное браузерное поле `<input type="email">` или простые регуляторные выражения ломаются на корректных RFC 5322 адресах (например, `user+tag@domain.com`, unicode-домены), либо пропускают некорректные адреса вида `user@domain..com`.
- **Правило безопасности**: Frontend-валидация служит исключительно для улучшенного UX (моментальный отклик без запроса на сервер). Единственной гарантией безопасности является **Backend-валидация**.

### Реализация
1. **Frontend**:
   - Использовать схему **Zod** (`z.string().email("Некорректный формат email")`).
   - Сообщение об ошибке должно быть простым и локализованным: `"Некорректный адрес электронной почты"`.
2. **Backend**:
   - На DTO [RegisterRequest.java](file:///c:/Users/murat/IdeaProjects/JF-1C/zhan-finance-backend/src/main/java/com/example/zhanfinancebackend/modules/auth/dto/RegisterRequest.java) и [LoginRequest.java](file:///c:/Users/murat/IdeaProjects/JF-1C/zhan-finance-backend/src/main/java/com/example/zhanfinancebackend/modules/auth/dto/LoginRequest.java) добавить аннотации:
     ```java
     @NotBlank(message = "{email.required}")
     @Email(message = "{email.invalid}")
     String email
     ```

---

## 2. Локализация (i18n) и исправление шаблонов JSX

### Теория и баг с `${user?.fullName || 'Гость'}`
Из предоставленного скриншота видно, что на странице дашборда рендерится невычисленная строка `${user?.fullName || 'Гость'}`. Это происходит, когда шаблонные строки JS (`${...}`) по ошибке попадают в код обычным текстом JSX без фигурных скобок `{...}` или перевода `t(...)`.

### Реализация
1. **Исправление JSX**:
   Заменить невычисленный текст в компоненте приветствия на вызов React-i18next:
   ```tsx
   {t('dashboard.welcomeUser', { name: user?.fullName || t('common.guest') })}
   ```
2. **Единая система i18n**:
   - Использовать `react-i18next`.
   - Вынести все тексты из JSX в словари `/locales/ru/common.json`, `/locales/kk/common.json`, `/locales/en/common.json`.

---

## 3. Ограничение типов файлов при загрузке (Проводник + Drag & Drop + Backend)

### Теория и уровень защиты
Атрибут `accept` у `<input type="file">` указывает диалоговому окну операционной системы, какие файлы отображать по умолчанию. Однако пользователь может переключить фильтр в проводнике на *"Все файлы (*.*)"* или перетащить запрещенный файл мышью (Drag & Drop).

### Реализация
1. **Проводник (Explorer Filter)**:
   В компонент загрузчика передать точный атрибут `accept`:
   ```html
   <input type="file" accept=".pdf,.docx,.xlsx,.png,.jpg,.jpeg,.zip,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,image/png,image/jpeg,application/zip" />
   ```
   Это принудительно скрывает из диалога проводника все остальные типы файлов.
2. **Drag & Drop / Change Validation (Frontend UX)**:
   При событии `drop` или `change` выполнять клиентскую проверку расширения и MIME-типа. Если файл не входит в белый список — сразу предотвращать загрузку и выводить тостер: `"Формат файла не поддерживается. Разрешены: PDF, DOCX, XLSX, PNG, JPG, ZIP"`.
3. **Backend Security Guard**:
   На бэкенде в [DocumentService.java](file:///c:/Users/murat/IdeaProjects/JF-1C/zhan-finance-backend/src/main/java/com/example/zhanfinancebackend/modules/documents/service/DocumentService.java):
   - Проверять сигнатуру файлов (Magic Bytes через Apache Tika / MIME detector).
   - Вести жесткий белый список MIME-типов и расширений.

---

## 4. UI просмотра пароля ("Глазок")

### Реализация
В компонент поля ввода пароля [Input.tsx](file:///c:/Users/murat/IdeaProjects/JF-1C/zhan-finance-frontend/src/shared/ui/Input.tsx) или формы [LoginPage.tsx](file:///c:/Users/murat/IdeaProjects/JF-1C/zhan-finance-frontend/src/pages/auth/login/LoginPage.tsx) / [RegisterPage.tsx](file:///c:/Users/murat/IdeaProjects/JF-1C/zhan-finance-frontend/src/pages/auth/register/RegisterPage.tsx):
- Добавить локальное состояние `const [showPassword, setShowPassword] = useState(false)`.
- Использовать иконки Lucide `Eye` и `EyeOff`.
- Рендерить `<input type={showPassword ? "text" : "password"} autoComplete="current-password" />`.

---

## 5. Система статусов регистрации и строгая безопасность входа (Fail-Closed Architecture)

### [CRITICAL] Архитектура безопасности и защита от перечисления пользователей (User Enumeration)

При обработке входа пользователя порядок верификации **КРИТИЧЕСКИ ВАЖЕН**:

```mermaid
graph TD
    A[Запрос на входа: Email + Password] --> B{1. Найти пользователя по Email}
    B -- Не найден --> E[Ответ 401: Неверный email или пароль]
    B -- Найден --> C{2. Проверить пароль через BCrypt}
    C -- Пароль НЕ совпадает --> E
    C -- Пароль ВЕРЕН --> D{3. Проверить статус регистрации}
    D -- PENDING --> F[Ответ 403: REGISTRATION_PENDING<br/>'Ваша заявка на рассмотрении. Ожидайте одобрения.']
    D -- REJECTED --> G[Ответ 403: REGISTRATION_REJECTED<br/>'Заявка отклонена. Обратитесь к администратору.']
    D -- APPROVED --> H[Выдать JWT Access + Refresh токены<br/>200 OK]
```

#### Почему нельзя проверять статус ДО проверки пароля:
Если бэкенд будет проверять статус `PENDING` до сверки пароля, злоумышленник сможет отправить любой случайный пароль и по ответу сервера *"Ваша заявка на рассмотрении"* точно узнать, что данный email зарегистрирован в системе.
**Принцип наименьшего раскрытия**: Сообщение о статусе заявки выдается **СТРОГО ПОСЛЕ** успешного ввода правильного пароля!

---

### Детали реализации статусов

1. **Модель данных и Enum**:
   В БД добавляется статус заявки регистрации `registration_status` (Enum: `PENDING`, `APPROVED`, `REJECTED`).
   - Для роли `CLIENT` по умолчанию ставится `APPROVED`.
   - Для роли `EMPLOYEE` при публичной регистрации ставится `PENDING` и `enabled = false`.

2. **Экран после отправки заявки на регистрацию**:
   Когда сотрудник отправляет форму регистрации:
   - Сервер возвращает ответ со статусом `registrationStatus: "PENDING"` и **БЕЗ токенов**.
   - Фронтенд скрывает форму и показывает специальный информационный экран:
     > **Заявка успешно отправлена!**
     > Ваша учетная запись сотрудника находится на рассмотрении администратора. После одобрения вы сможете войти в систему.

3. **Логика входа на бэкенде**:
   При вызове `POST /api/v1/auth/login`:
   - Выполняется `authenticationManager.authenticate(...)` (проверка логина и BCrypt-пароля).
   - Если пароль некорректен — сервер возвращает `401 Unauthorized` ("Неверный email или пароль").
   - Если пароль верен, проверяется `user.getRegistrationStatus()`:
     - `PENDING` -> Возвращается HTTP 403 Forbidden с кодом ошибки `REGISTRATION_PENDING` и сообщением *"Ваша заявка на рассмотрении, ожидайте одобрения"*.
     - `REJECTED` -> Возвращается HTTP 403 Forbidden с кодом ошибки `REGISTRATION_REJECTED` и сообщением *"Ваша заявка отклонена"*.
     - `APPROVED` -> Выдаются Access & Refresh токены.

4. **Логика на фронтенде при попытке входа**:
   Если сотрудник пытается войти до одобрения админом (вводит правильный email и пароль):
   - Фронтенд получает код `REGISTRATION_PENDING` и отображает специальное уведомление/экран:
     > **Ваша заявка находится в работе**
     > Администратор ещё не утвердил ваш аккаунт. Ожидайте уведомления.
   - Когда администратор одобряет заявку в панели `/admin/employees`, статус меняется на `APPROVED`, и при следующем входе сотрудник успешно попадает в свой кабинет:
     > **Вас успешно приняли!** Добро пожаловать в систему.
