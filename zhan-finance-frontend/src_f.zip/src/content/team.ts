export interface TeamMember {
  name: string;
  role: string;
  photo: string;
  highlight?: boolean;
}

export const teamRows: TeamMember[][] = [
  [
    {
      name: 'ЖАРИЛКАГАНОВ АМАНКЕЛЬДИ НАКМАДИНОВИЧ',
      role: 'Руководитель компании',
      photo: '',
      highlight: true,
    },
  ],
  [
    { name: 'Имя Фамилия', role: 'Главный бухгалтер',       photo: '' },
    { name: 'Имя Фамилия', role: 'Налоговый консультант',   photo: '' },
    { name: 'Имя Фамилия', role: 'Кадровый учет',           photo: '' },
    { name: 'Имя Фамилия', role: 'Финансовый аналитик',     photo: '' },
  ],
  [
    { name: 'Имя Фамилия', role: 'Первичная документация',  photo: '' },
    { name: 'Имя Фамилия', role: 'Сверки и отчётность',     photo: '' },
    { name: 'Имя Фамилия', role: 'Клиентский менеджер',     photo: '' },
    { name: 'Имя Фамилия', role: 'Восстановление учета',    photo: '' },
    { name: 'Имя Фамилия', role: 'Проверка контрагентов',   photo: '' },
  ],
];
